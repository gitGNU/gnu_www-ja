/* This file is part of GNU Libraries and Engines for Games  -*- c++ -*-

   $Id: event.cc,v 1.5 2004/06/19 11:15:35 jd Exp $

   Created 04/15/04 by Jean-Dominique Frattini <zionarea@free.fr>
   
   Copyright (c) 2004 Free Software Foundation
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.
   
   You should have received a copy of the GNU General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/
/*! \file support/window/event.cc
 * \brief base event handlings.
*/

#include "leg/support/window/window.h"

namespace leg
{
namespace support
{
namespace window
{
   BaseEvent::BaseEvent(): current_key ((key::Key)0),
			   current_string_key (""),
			   current_mouse_button (0),
			   mouse_origin (upper_left_corner),
			   gl_mouse_origin (lower_left_corner),
			   win_width (0),
			   win_height (0),
			   save_string_key (false)
   {
   }

   BaseEvent::~BaseEvent()
   {
   }
}
}
}
