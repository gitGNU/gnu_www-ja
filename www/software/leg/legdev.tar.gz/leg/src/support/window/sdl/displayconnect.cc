#include "leg/support/window/sdl/displayconnect.h"

namespace leg
{
namespace support
{
namespace window
{

bool sdl_is_init = false;

void
SDLDisplayConnect::Open()
{
   if (!sdl_is_init){
      SDL_Init (SDL_INIT_VIDEO);
      sdl_is_init = true;
   }

   CheckThreadSupport();
}

}
}
}
