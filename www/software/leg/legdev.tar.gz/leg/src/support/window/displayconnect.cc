/* This file is part of GNU Libraries and Engines for Games  -*- c++ -*-

   $Id: displayconnect.cc,v 1.3 2004/05/09 23:36:09 jd Exp $

   $Log: displayconnect.cc,v $
   Revision 1.3  2004/05/09 23:36:09  jd
   directory support for all the project, best windowing support, best interactivity support...

   Revision 1.2  2004/04/30 20:15:54  jechk
   Big merge.  See ChangeLog for details.

   Revision 1.1  2004/03/22 03:24:04  jd
   glx 1.2 and 1.3 support



 
   Created 02/18/04 by Jean-Dominique Frattini <zionarea@free.fr>
   
   Copyright (c) 2004 Free Software Foundation
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.
   
   You should have received a copy of the GNU General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/
/*! \file support/window/displayconnect.cc
 * \brief display connections and glx versions.
*/

#include "leg/support/window/displayconnect.h"
#include "leg/support/utils/errors.h"

namespace leg
{
namespace support
{
namespace window
{
   DisplayConnect::DisplayConnect(): display (0)
   {
   }

   DisplayConnect::~DisplayConnect()
   {
   }
/*
   void DisplayConnect::CheckThreadSupport()
   {
      using leg::support::utils::Error;
      using leg::support::utils::Warning;
      
      #ifdef _REENTRANT
	 if ((int)XInitThreads()){
	    #ifndef LEG_WINDOWING_IS_THREADED
	       #define LEG_WINDOWING_IS_THREADED 1
	    #endif
	 }
	 else{
	    #ifdef LEG_WINDOWING_IS_THREADED
	       #undef LEG_WINDOWING_IS_THREADED
	    #endif
	    Error (  "No windowing multithread support found.",
		     "leg::support::window::DisplayConnect::CheckThreadSupport()");
	 }
      #else
	    Warning ("Leg is running in single thread mode.",
		     "leg::support::window::DisplayConnect::CheckThreadSupport()");
      #endif
   }
*/
}
}
}

