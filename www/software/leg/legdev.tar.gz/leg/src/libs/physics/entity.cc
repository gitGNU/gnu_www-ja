/* This file is part of GNU Libraries and Engines for Games  -*- c++ -*-

   $Id: entity.cc,v 1.3 2004/07/15 23:28:23 jd Exp $

   Created 06/28/04 by Jean-Dominique Frattini <zionarea@free.fr>
   
   Copyright (c) 2004 Free Software Foundation
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.
   
   You should have received a copy of the GNU General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/
/*! \file libs/physics/entity.cc
  \brief An entity for physics.
*/

#include "leg/libs/physics/entity.h"
#include "leg/support/utils/errors.h"

namespace leg
{
namespace libs
{
namespace physics
{
   using leg::support::utils::Warning;
   using leg::support::utils::Error;

   Entity::Entity()
   {
   }

   Entity::Entity (const Entity& e)
   {
      //Copy (e);
   }
   
   const Entity& 
   Entity::operator = (const Entity& e)
   {
      //Copy (e);
      return *this;
   }

   Entity::~Entity()
   {
   }

   real Entity::distance_precision = .05;
}
}
}

