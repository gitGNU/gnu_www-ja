/* This file is part of GNU Libraries and Engines for Games  -*- c++ -*-

   $Id: threads.h,v 1.3 2004/03/03 03:50:02 jechk Exp $
   $Log: threads.h,v $
   Revision 1.3  2004/03/03 03:50:02  jechk
   Changed some names, comments and other things for consistency.

   Revision 1.1  2004/03/03 02:05:22  jechk
   Merged many changes.  See ChangeLog for details.


   Created 01/23/04 by Jean-Dominique Frattini <zionarea@free.fr>
   
   Copyright (c) 2004 Free Software Foundation
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.
   
   You should have received a copy of the GNU General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/
/*! \file support/threads/threads.h
  \brief full threads support
*/

#ifndef LEG_SUPPORT_THREADS_THREADS_H
#define LEG_SUPPORT_THREADS_THREADS_H

#include "thread.h"
#include "cond.h"
#include "mutex.h"
#include "condmutex.h"

#endif

