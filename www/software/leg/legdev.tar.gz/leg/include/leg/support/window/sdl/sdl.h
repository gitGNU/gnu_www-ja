#include "displayconnect.h"
#include "firsttypes.h"
#include "sdlevent.h"
#include "sdlkeymap.h"
#include "sdltext.h"
#include "sdlwindow.h"

namespace leg
{
namespace support
{
namespace window
{

typedef SDLWindow OSWindow;

}
}
}
