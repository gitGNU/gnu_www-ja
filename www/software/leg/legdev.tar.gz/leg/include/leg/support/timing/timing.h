/* This file is part of GNU Libraries and Engines for Games  -*- c++ -*-

   $Id: timing.h,v 1.4 2004/06/22 22:15:56 jd Exp $
   $Log: timing.h,v $
   Revision 1.4  2004/06/22 22:15:56  jd
   several changes

   Revision 1.3  2004/05/13 04:16:02  jechk
   Split timing into two parts; moved message to libs.

   Revision 1.2  2004/03/03 03:50:02  jechk
   Changed some names, comments and other things for consistency.

   Revision 1.1  2004/03/03 02:05:22  jechk
   Merged many changes.  See ChangeLog for details.


   Created 2/18/04 by Jeff Binder <bindej@rpi.edu>
   
   Copyright (c) 2004 Free Software Foundation
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.
   
   You should have received a copy of the GNU General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/
/*! \file support/timing/timing.h
  \brief Classes involving time.
*/

// TODO:
// 
// Utilities for managing minutes, hours, days, etc.
// Serialization (we need to decide about this).

#ifndef LEG_SUPPORT_TIMING_TIMING_H
#define LEG_SUPPORT_TIMING_TIMING_H

#include <cmath>
#include <ctime>
#include <list>

#include <sys/time.h>

namespace leg
{
namespace support
{
namespace timing
{

typedef double game_time;

typedef game_time GameTime;

struct timeval operator + (const struct timeval &x, const struct timeval &y);
struct timeval operator - (const struct timeval &x, const struct timeval &y);

}
}
}

#include "timing-class.h"

#endif // LEG_SUPPORT_TIMING_TIMING_H
