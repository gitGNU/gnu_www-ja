/* This file is part of GNU Libraries and Engines for Games  -*- c++ -*-

   $Id: maths.h,v 1.5 2004/06/20 02:24:03 jechk Exp $
   $Log: maths.h,v $
   Revision 1.5  2004/06/20 02:24:03  jechk
   Added first support for volumes.

   Revision 1.4  2004/03/08 22:33:02  jechk
   Removed reference to nonexistent complex.h.

   Revision 1.3  2004/03/08 22:26:36  jechk
   Maths update.  Mainly, added Polynomial class.

   Revision 1.2  2004/03/03 03:50:02  jechk
   Changed some names, comments and other things for consistency.

   Revision 1.1  2004/03/03 02:05:22  jechk
   Merged many changes.  See ChangeLog for details.


   Created 12/16/03 by Jeff Binder <bindej@rpi.edu>
   
   Copyright (c) 2003, 2004 Free Software Foundation
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.
   
   You should have received a copy of the GNU General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/
/*! \file leg/support/maths/maths.h
  \brief Main maths header file
*/

#ifndef LEG_SUPPORT_MATHS_H
#define LEG_SUPPORT_MATHS_H

#include "real.h"
#include "vector.h"
#include "matrix.h"
#include "quaternion.h"
#include "polynomial.h"

#endif

