/* This file is part of GNU Libraries and Engines for Games  -*- c++ -*-

   $Id: threads.h,v 1.2 2004/05/31 23:14:22 jd Exp $

   $Log: threads.h,v $
   Revision 1.2  2004/05/31 23:14:22  jd
   some doc for some files

   Revision 1.1  2004/05/31 20:40:56  jd
   first release


 
   Created 05/21/04 by Jean-Dominique Frattini <zionarea@free.fr>
   
   Copyright (c) 2004 Free Software Foundation
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.
   
   You should have received a copy of the GNU General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/
/*!\file libs/threads/threads.h
  \brief whole libs/threads.
*/

#ifndef LEG_LIBS_THREADS_THREADS_H
#define LEG_LIBS_THREADS_THREADS_H


#include "defaultsettingpolicy.h"
#include "sync.h"
#include "threader.h"
#include "threadablecell.h"
#include "threadercell.h"

/*
#include "leg/support/threads/threads.h"
#include "inputs.h"
#include "states.h"
#include "actorpolicy.h"
#include "reactorpolicy.h"
*/

namespace leg
{
namespace libs
{
//! Second layering for threads.
/*!
 * This layer provides higher abstract generic means to manipulate threads.
 */
namespace threads
{
/*
typedef support::threads::Mutex	    Mutex;
typedef support::threads::Condition Cond;
typedef support::threads::CondMutex CondMutex;
   
template
<
   template <class> class Host
>
class ThreaderCell: public HostInheritedStateMachine<
			      Host<CondMutex>,
			      Input,
			      State,
			      libs::threads::Sync<>,
			      ActorPolicy,
			      ReactorPolicy>
{
   protected:

   typedef HostInheritedStateMachine<
	    Host<CondSync>, Input, State,
	    libs::threads::Sync<>, ActorPolicy, ReactorPolicy>

	 Parent;
   
   ThreaderCell ():  Parent()
   {
   }

   ThreaderCell (const ThreaderCell& c): Set (dynamic_cast<TCellSync&> (*this))
   {
   }

   const ThreaderCell& operator = (const ThreaderCell& tc)
   {
      Set::operator = (tc);
      return *this;
   }
   
   ~ThreaderCell()
   {
   }

   inline void*
   Go (void *args)
   {
      Set::PreRun ();
      void *ret = Set::Run (args);
      Set::PostRun ();
      return ret;
   }
};*/
   
}
}
}
#endif
