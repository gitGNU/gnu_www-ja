/* This file is part of GNU Libraries and Engines for Games  -*- c++ -*-

   $Id: physics.h,v 1.1 2004/07/15 23:26:02 jd Exp $

   Created 06/23/04 by Jean-Dominique Frattini <zionarea@free.fr>
   
   Copyright (c) 2004 Free Software Foundation
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.
   
   You should have received a copy of the GNU General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/
/*! \file libs/physics/physics.h
  \brief physics first layer.

TODO:

   * Maybe we could do the collision detection in physics. This is because we
   * will need vertex data for some stuffs here, like knowing the good height
   * (y value from the default opengl system coordinates) of an object that is
   * on another (generally the relief or another object) one - we speak here of
   * scene objects.
*/

#ifndef LEG_LIBS_PHYSICS_PHYSICS_H
#define LEG_LIBS_PHYSICS_PHYSICS_H

#include "entity.h"
#include "simpleentity.h"
#include "gravitron.h"
#include "boundingentity.h"

#endif
