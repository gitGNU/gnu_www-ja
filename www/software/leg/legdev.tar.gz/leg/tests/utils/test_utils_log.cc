#ifndef LEG_USE_LOG
#define LEG_USE_LOG 1
#endif

#include "leg/support/utils/errors.h"

using namespace leg::support::utils;
using namespace std;

int main (int argc, char **argv)
{
   Log ("hello world");

   Message<Warning,Log> ("test message with logs");
   Message<Warning,NoLog> ("test message with NO logs");

   Info ("hello world !","main");

   Warning ("test new warnings");

   return 0;
}

