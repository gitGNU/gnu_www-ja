#define LEG_USE_SUPPORT
#define LEG_USE_SUPPORT_GUILE
#define LEG_USE_SUPPORT_THREADS
#define LEG_USE_SUPPORT_TIMING
#define LEG_USE_SUPPORT_WINDOW

#include <iostream>
#include <leg/leg.h>

using namespace std;
using namespace leg::support::guile;

int
main (int argc, char *argv[])
{
  EvalExpression<void>
    ("(use-modules (ice-9 readline)) (activate-readline)");
  CallVoidFunction0 ("scm-style-repl");
}
