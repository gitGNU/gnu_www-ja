#include <leg/support/states/states.h>
#include <leg/support/threads/mutex.h>
#include <iostream>
#include <leg/support/states/defaultstateactorpolicy.h>
#include <leg/support/states/defaultstatereactorpolicy.h>

using namespace leg;

class A
{
   int a;
   public:
   A():a(0){}
};

int main (int argc, char **argv)
{
   typedef support::states::HostInheritedStateMachine< A,
					  std::string,
					  unsigned int,
					  support::threads::Mutex,
					  support::states::DefaultStateActorPolicy,
					  support::states::DefaultStateReactorPolicy>
	       StatyA;

   StatyA *staty_a = new StatyA (0);

   staty_a->Act ("hello");
   
   staty_a->React();

   staty_a->Act ("destruct");

   staty_a->React();

   staty_a->Act ("not really");
   
   return 0;
}
