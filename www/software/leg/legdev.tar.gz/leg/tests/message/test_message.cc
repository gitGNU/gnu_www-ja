#include <iostream>
#include <leg/libs/message/message.h>

using namespace leg::libs::message;
//using namespace leg::libs::timing;
using namespace std;

/*class MyReceiver : public Receiver
{
public:
  MyReceiver (Timing& timing)
    : Receiver (timing)
  {
  }
  
protected:
  virtual void
  MessageFunc (const Message& message, void *data = NULL)
  {
    cout << message << endl;
    if (message == "c")
      {
	exit (0);
      }
  }
};*/

int
main()
{
  Timing timing;
  /*MyReceiver r (timing);

  r.ReceiveMessage ("a");
  r.ReceiveMessageIn (1, "b");
  r.ReceiveMessageAt (3, "c");

  for (;;);*/

  return 0;
}
