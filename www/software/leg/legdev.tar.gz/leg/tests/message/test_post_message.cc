#include <leg/libs/message/message.h>
#include <iostream>

using namespace leg::libs::message;
using namespace std;

class AClass
{
   public:

   AClass(){}

   ~AClass(){}

   void
   ReceiveMessage (const Message& msg)
   {
      cout << "destination object received message: " << msg << endl;
   }
};

int main (int argc, char **argv)
{
   AClass a;

   PostOffice::Send ("hello world !",a);

   PostOffice::SendIn (2,"I like a",a);
   PostOffice::SendIn (1,"one",a);
   PostOffice::SendIn (2,"two",a);
   PostOffice::SendIn (1,"I like both",a);
   PostOffice::SendIn (3,"I like b",a);
   
   while (1)
      PostOffice::Actualize();
  
   return 0;
}
