/* This file is part of GNU Libraries and Engines for Games  -*- c++ -*-

   $Id: template.h,v 1.2 2004/03/03 02:05:12 jechk Exp $
   $Log: template.h,v $
   Revision 1.2  2004/03/03 02:05:12  jechk
   Merged many changes.  See ChangeLog for details.


   Created (DATE) by (CREATOR) <(EMAIL)>
   
   Copyright (c) 2004 Free Software Foundation
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.
   
   You should have received a copy of the GNU General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/
/*! \file replace.h
  \brief Description.
*/

#ifndef LEG_REPLACE_H
#define LEG_REPLACE_H

namespace leg
{
namespace layer_name_replace
{
namespace module_name_replace
{


	
}
}
}

#endif // LEG_REPLACE_H
