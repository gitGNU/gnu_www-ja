Note that some machines want labels to have leading underscores,
while others (e.g. System V) do not.  Thus, several labels appear
duplicated except for the leading underscore, e.g.

	_qt_cswap:
	qt_cswap:

