/*
 * QuickThreads -- Threads-building toolkit.
 * Copyright (c) 1993 by David Keppel
 *
 * Permission to use, copy, modify and distribute this software and
 * its documentation for any purpose and without fee is hereby
 * granted, provided that the above copyright notice and this notice
 * appear in all copies.  This software is provided as a
 * proof-of-concept and for demonstration purposes; there is no
 * representation about the suitability of this software for any
 * purpose.
 */

char const qtmd_rcsid[] = "$Header: /local/users/pardo/local/resch/thread/qt/qt/md/RCS/null.c,v 1.2 1993/12/22 20:46:04 pardo Exp $";
