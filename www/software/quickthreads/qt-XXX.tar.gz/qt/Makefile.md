
#
# `Normal' configuration.
#
CC	      = gcc -ansi -Wall -pedantic

