#ifndef B_H
#define B_H	"$Header: /var/a/gar/u1/pardo/local/resch/thread/qt/qt/RCS/b.h,v 1.2 1993/12/22 20:28:26 pardo Exp $"

#include "copyright.h"

extern void b_call_reg (int n);
extern void b_call_imm (int n);
extern void b_add (int n);
extern void b_load (int n);

#endif /* ndef B_H */
