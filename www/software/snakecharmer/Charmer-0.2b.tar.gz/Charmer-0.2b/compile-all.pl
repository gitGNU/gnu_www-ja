use File::Find;

print 
  q(
    
    This script tries to help over the absence of a real installation routine.
    It compiles things in place: the generated class files will be in the same
    directory as the source files.
    
    We are aware that this is not GNU conformant, 
    and we will change this in the near future.
    
    (Wolfgang M�ller is responsible for this "pseudo installation")
    
   );

$ENV{CLASSPATH}="$ENV{PWD}/charmer/client:.:$ENV{CLASSPATH}";

$inDir = shift || ".";
$JAVAC = shift || "javac";

print "compiling SAXDriver using $JAVAC\n";
system("$JAVAC com/microstar/xml/SAXDriver.java");
print "compiling Charmer using $JAVAC\n";
system("$JAVAC charmer/client/Charmer.java");



#find(\&wanted,$inDir);


# sub wanted{
#   my $lFullName=$File::Find::name;
#   if(m/\.java$/){
#     print "found: $lFullName\n";

#     system("$JAVAC $_\n");


#   }
# }

#system ("find $inDir -name \"*.java\" -exec $JAVAC \{\} \\; -exec echo \{\} \\;");

