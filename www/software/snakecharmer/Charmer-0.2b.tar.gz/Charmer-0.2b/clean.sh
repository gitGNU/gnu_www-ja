#! /bin/sh
find ./charmer -name "*.class" -print -exec rm -f \{\} \;
