// -*- mode: java -*- 
/* 

   Viper, a flexible content based image retrieval system.
   Copyright (C) 1998-1999 CUI, University of Geneva

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer;

import java.net.*;
import java.util.*;
import java.io.*;
import charmer.mrml.*;
import charmer.client.*;


/** <h1> CharmerConnectionMRML</h1>
 * This class is used to establish a connection to the server and execute similarity based queries.
 * The functions allow search on a combination of color, layout and texture similarity with a set of 
 * relevant iamges. Further a color composition of a searched for image can be specified and the images
 * with such compositions can be retrieved. Other methods allow to monitor and change some connection 
 * parameters. The search metods are blocking, but should be rather fast on local networks.
 *
 * @author Zoran Pecenovic
 * @version 1.1
 */

class internalClient extends Object {
    Socket mSocket;
    DataOutputStream out;
    
    String mHost;
    int    mPort = 1234;

    
    internalClient(String  inHost,
		   Integer inPort){
        setPort(inPort);
        setHost(inHost);
    }

    public void setPort(Integer inPort){
        mPort=inPort.intValue();
    }
    public void setHost(String inHost){
        mHost=inHost;
    }

    public int connect(String inHost) {
        setHost(inHost);
        try {
            System.out.println("connect: mHost = [" + mHost + "], mPort = [" + mPort+"]");
	    System.out.println("IF the line \"Connected: ...\" is not ");
	    System.out.println("printed in the next few seconds");
	    System.out.println("THEN there is a security problem with your");
	    System.out.println("appletviewer / browser");
            mSocket = new Socket(mHost, mPort);
            System.out.println("Connected: mHost = " + mHost + ", mPort = " + mPort);
            out = new DataOutputStream(mSocket.getOutputStream());
            return 1;
        }
        catch (IOException e) {
            System.err.println("Server not started: " + e);
            return -1;
        }
    }

    public void close() {
        //PRINTOUT: System.out.println("close");
        try {
	    //	    mSocket.shutdownOutput();
	    //	    mSocket.shutdownInput();

            mSocket.close();
        }
        catch (IOException e) {
            System.err.println("Can't close connection with server: " + e);
        }
    }

    public void send(byte[] Bytes, int NbBytes) {

        // System.out.println("Nb of bytes Sent: " + NbBytes);

        try {
            out.write(Bytes,0,NbBytes);
	    //out.flush();
        }
        catch (IOException e) {
            System.err.println("Can't send to server: " + e);
        }
    }

    Socket getSocket(){
        return mSocket;
    }
  
}


public class CharmerConnectionMRML
    implements CMRMLUser
{

    static final String DTDSOURCE = "http://isrpc85.epfl.ch/Charmer/code/mrml.dtd";
    //"/home/muellerw/sunHome/ViperGrammar/test.dtd";
    static URL DUMMYURL=null;

    //private data used y interface CMRMLUser implementation
    private String mCurrentSession=new String("dummy_session_identifier");
    private CQueryStep mQuery; //The query type expected by clear and send query, etc...
    private CUserRelevanceList mUserRelevanceList; //The actual list of relevance elements contained in query for fast access I guess
    private Hashtable mIDToAlgorithm=new Hashtable();   
    private internalClient client;
    private boolean validResults=false;
    private boolean validHandshake=false;
    private Vector mCurrentAlgorithmIDList;
    private String mAlgorithmNameListID;
    private CParser cParser;

    public class CollectionSpec
    {
        public String ID;
        public String Name;
	public CXMLElement mQueryParadigmList;
	public Vector Algorithms; //A vector of Algorithm specs,
	// this field will only be
	// filled in by a call to getCollections method
	public String toString(){
	    String ret = "\nID : "+ID+
		" Name : "+Name+
		" Algorithms : ";
	    for(int i=0; i<Algorithms.size(); i++) {
		ret += Algorithms.elementAt(i).toString();
	    }
	    return ret;
	}
    }

    public class AlgorithmSpec {
        public String ID=null;
        public String Name=null;
	public CXMLElement mQueryParadigmList=null;
	public CXMLElement mPropertySheet=null;
	public String toString(){
	    return "\n  ID : "+ID+"  Name : "+Name;

	}
    }

    class EHashtable
        extends Hashtable
    {
        public String mID;
    }
    
    private EHashtable CollectionList = new EHashtable();

    //helper and inhereted methods from CMRMLUser which will not be used directly by the clients.

    public String getCurrentSession(){
        return new String(mCurrentSession);
    }

    public String preamble(){
        return new String("<?xml version=\"1.0\" standalone=\"no\" ?>\n"+
                          "<!DOCTYPE mrml SYSTEM \""+DTDSOURCE+"\">\n");
    }
    
    public String frame(String inString){
        return new String(preamble()+"<mrml session-id=\""+getCurrentSession()+"\">\n"+inString+"\n</mrml>\n");
    }

    public void  clearImageDisplay() {
        mUserRelevanceList=new CUserRelevanceList();		
    } //do nothing the list construction mechanism will do this for you

    public void  addImageToDisplay(String inURL,
				   String inThumbnail,
                                   Double inCalculatedSimilarity){
        //this will actually be added at the end by the surrounding code, here we just make a list of valid Results   
	try{
	    System.err.println("ADD: "+inURL+inThumbnail);
	    if(inCalculatedSimilarity==null) 
		System.err.println("Damned!");
	    //PRINTOUT: else 
	    //PRINTOUT: System.out.println("Yeah!");
	    //PRINTOUT: System.out.println("URL = "+inURL+" inUserRelevance = "+inCalculatedSimilarity);
	    CUserRelevanceElement ure= new CUserRelevanceElement(inURL,
								 inThumbnail,
								 inCalculatedSimilarity.toString());
	    mUserRelevanceList.addItem(ure);
	}catch(Exception e){
	    e.printStackTrace();
	}
	//addUserRelevanceElement(inURL,inUserRelevance);
    }

    public void  showImageDisplay(){
	validResults = true;
    }

    public boolean sendInterfaceHandshake(String inUserName){
	String lMessage=new String("<"
				   + mrml_const.open_session
				   +" "
				   + mrml_const.user_name 
				   + "=\""
				   +inUserName
				   + "\" "
				   + mrml_const.session_name 
				   + "=\""
				   +"charmer_default_session"
				   + "\" "
				   + "/>"

				   +"<"
				   + mrml_const.get_collections
				   + "/>"

				   +"<"
				   + mrml_const.get_algorithms
				   + "/>"
				   );
	return sendMessage(frame(lMessage));
    }

    public void clearQuery(String inID,
                           String inResultSize,
                           String  inResultCutoff,
                           String  inAlgorithmID,
                           String  inCollectionID){
        mUserRelevanceList=new CUserRelevanceList();
        mQuery=new CQueryStep(inID,
                              inResultSize,
                              inResultCutoff,
                              inAlgorithmID,
                              inCollectionID,
                              mUserRelevanceList);        
    }

    public void addUserRelevanceElement(String inURL,
                                        Double inUserRelevance){
	if(inUserRelevance==null) System.err.println("Damned!");
	else System.err.println("Yeah!");
	System.err.println("URL = "+inURL+" inUserRelevance = "+inUserRelevance);
	CUserRelevanceElement ure= new CUserRelevanceElement(inURL,"",new String(inUserRelevance.toString()));
        mUserRelevanceList.addItem(ure);
    }
    /** simply send the constructed query from previous calls to addUserRelevanceElement */
    public boolean sendQuery(){
	return sendMessage(frame(mQuery.toString()));
    };
    /** simply send the constructed query from previous calls to addUserRelevanceElement */
    public boolean sendQuery(String inConfigureMessage){
	return sendMessage(frame(inConfigureMessage+
				 mQuery.toString()));
    };
    /** as before, but an additional XML string inserted into the query-step tag */
    public boolean sendQuery(String inConfigureMessage, String inAdditionalXML){
	return sendMessage(frame(inConfigureMessage+
				 mQuery.toStringWithAdditionalXML(inAdditionalXML)));
    };
    //set new session id...
public void setCurrentSession(String inSession){
    //PRINTOUT: System.out.println("This is in set CurrentSession.");
    //PRINTOUT: System.out.println("Previous value: "+mCurrentSession);
    if(inSession!=null){
	mCurrentSession=new String(inSession);
    }
    //PRINTOUT: System.out.println("Current value: "+mCurrentSession);
}


public void clearSessionList(String inID){
    //PRINTOUT: System.out.println("Clear session list");
} //NOP for the moment
///call this at each encountered ssession ELEMENT
public void addSessionToList(String inID,
			     String inName){
    //PRINTOUT: System.out.println("Add session "+inName+" to list : "+inID);
} //NOP for the moment ignore session names 


public Hashtable getIDToAlgList() {return null;}

public void clearAlgorithmList(String inID){
    mIDToAlgorithm.clear();
}

public void addAlgorithmToList(String inID,
			       String inName,
			       CXMLElement inQueryParadigmList,
			       CXMLElement inPropertySheet){
    AlgorithmSpec lAS=new AlgorithmSpec();
    lAS.ID=inID;
    lAS.Name=inName;
    lAS.mQueryParadigmList=inQueryParadigmList;
    lAS.mPropertySheet=inPropertySheet;
    mIDToAlgorithm.put(inID, 
		       lAS);
}
public void clearCollectionList(String inID){
    CollectionList.clear();
    if(inID!=null){
	CollectionList.mID=new String(inID);
    }else{
	CollectionList.mID=new String("default");
    }
}

    ///call this at each encountered scollection element
public void addCollectionToList(String inID,
				String inName,
				CXMLElement inQueryParadigmList){  
    CollectionSpec ncs = new CollectionSpec();
    ncs.ID=inID;
    ncs.Name=inName;
    ncs.mQueryParadigmList=inQueryParadigmList;
    CollectionList.put(inName,ncs);
};

public String toAttribute(String inName,
			  String inValue){
    return new String(" ")+inName+new String("=\"")+inValue+new String("\"");
}
    
public String toEmptyTag(String inElementName,
			 String inAttributes){
    return new String("<")+inElementName+new String(" ")+inAttributes+new String("/>");
}

public String toBeginTag(String inElementName,
			 String inAttributes){
    return new String("<")+inElementName+new String(" ")+inAttributes+new String(">");
}

public String toEndTag(String inElementName){
    return new String("</")+inElementName+new String(">");
}

public String makeConfigureMessage(String inAlgorithmID,
				   String inCollectionID,
				   CPropertyElement inPropertyElement){

    //PRINTOUT: System.out.println("makeConfigureMessage");
    if(null!=inPropertyElement){

	
	CMRMLBuilder lMRMLBuilder=new CMRMLBuilder ();
	
	lMRMLBuilder.openStartTag(mrml_const.configure_session);
	lMRMLBuilder.addAttributeToGenerated(mrml_const.session_id,
					     getCurrentSession());
	lMRMLBuilder.closeStartTag();
	
	lMRMLBuilder.openStartTag(mrml_const.algorithm);

	lMRMLBuilder.addAttributeToGenerated(mrml_const.algorithm_id,
					     inAlgorithmID);

	lMRMLBuilder.addAttributeToGenerated(mrml_const.algorithm_type,
					     inAlgorithmID);

	lMRMLBuilder.addAttributeToGenerated(mrml_const.collection_id,
					     inCollectionID);

	CXEVMRMLBuilder lMRMLBuilderVisitor=new CXEVMRMLBuilder(lMRMLBuilder);

	inPropertyElement.traverse(lMRMLBuilderVisitor);

	lMRMLBuilder.addEndTag(mrml_const.algorithm);
	lMRMLBuilder.addEndTag(mrml_const.configure_session);

	//PRINTOUT: System.out.print("I GENERATED:  ");
	//PRINTOUT: System.out.println(lMRMLBuilder.getGenerated());

	return lMRMLBuilder.getGenerated();
    }
    return new String();
}

public boolean sendRandomImages(String  inSessionID,
				String  inNumber,
				String  inAlgorithmID,
				String  inCollectionID,
				CPropertyElement inPropertyElement
				){
    
    String lConfigureMessage=makeConfigureMessage(inAlgorithmID,
						  inCollectionID,
						  inPropertyElement);

    String lMessage= lConfigureMessage
	+toEmptyTag(mrml_const.query_step,
		    toAttribute(mrml_const.session_id,getCurrentSession())
		    + toAttribute(mrml_const.result_size,inNumber)
		    + toAttribute(mrml_const.algorithm_id,inAlgorithmID)
		    + toAttribute(mrml_const.collection,inCollectionID)
		    );
    return sendMessage(frame(lMessage));
}

public void endServerHandshake(){
    validHandshake=true;
				
}

private boolean sendMessage(String str) {
    byte[] bytes;
    String TypeLen;
    System.out.println("sendMessage: Trying to send:"+str+".");
    if (client.connect(mHost) > 0) {     
	//PRINTOUT: System.out.println("SENDING");
	bytes = str.getBytes();
	//PRINTOUT: System.out.println("SENDING");
	//PRINTOUT: System.out.println("Sending a message to Server:"+str+".");
	//PRINTOUT: System.out.println("SENDING");
	client.send(bytes,bytes.length);
	//TfOutMessages.setText("Waiting for response");
	System.out.println("SUCCESS");
	return true;
    }else{
	System.err.println("sendMessage FAILED");
    }
    
    System.err.println("sendMessage FAILED");
    //TfOutMessages.setText("No connection: Server not started?");
    return false;
}

private boolean readMessage() {
    //PRINTOUT: System.out.println("before read"); 
    String Message;  
    //TfOutMessages.setText("Waiting for a message from the Server...");
    try {
						
	cParser.parse(this,client.getSocket());
	//ex: mHost,mPort
	//This little bastard will close the connection when parsing is done apparently.
	//It could actually close it once the slurping-in of the stream has been done.
    }
    catch (Exception e) {
	//TfOutMessages.setText("Exception during read/parse:");
	System.out.println("Exception during read/parse:");
	System.out.println(e.toString()); 
	return false;
    }
    //TfOutMessages.setText("Ready.");
    //RemoveWelcomeComponents();// should not be here
    //InitState  = false;
    //ReDrawInterface();
    return true;
}


/** 
 * The normal running state.
 */
public static final int S_CONNECTED=0;

/** 
 * An error in the Server IP address.
 */
public static final int S_IP_ERROR=1;
    
/** 
 * An error occured while opening the socket.
 */
public static final int S_SOCKET_ERROR=2;

/** 
 * An error occured while opening the communication streams.
 */
public static final int S_STREAM_OPEN_ERROR=3;
    
/** 
 * The server refused the connection : busy or unrecognized user.
 */
public static final int S_SERVER_REFUSAL=4;
    
/** 
 * An error occured during transmission of the data.
 */
public static final int S_STREAM_ERROR=5;
    
    
/** The one and only constructor.
 * 
 * The Collection string must be aquired by ad-hoc means by the client. 
 * A list of available collections is transmitted by the server when the connection is accepted 
 * and can be retrieved by the getCollections method. The collection can then be also set by 
 * the setCollection method. The username and server can <strong>not</strong> be changed later.
 *
 * @param Username the name of the connecting user.
 * @param Collection the name of the collection to access. 
 * @param ServerAddress the IP address of the server. Format : server.company.com:port.
 *
 * @see CharmerConnection#getCollections
 */
public CharmerConnectionMRML(String UserName, 
			     String Collection,
			     String ServerAddress,
			     Charmer loader)
{
    this.loader = loader;
    //init local variables
    StringTokenizer st = new StringTokenizer(ServerAddress,":",false);
    mHost = st.nextToken();
    mPort =44322;
    cParser = new CParser();
    //Check address
    try {
	mPort = Integer.parseInt(st.nextToken());
    } catch(Exception e1) {
	System.err.println("Illegal Server address : "+ServerAddress+"\n"+
			   " Should be of the form : ip.address.org:port");
	connected=false;
	state = 1;
    }
    client= new internalClient(mHost,
			       new Integer(mPort));
    if(sendInterfaceHandshake(UserName)){
	if(readMessage()){
	    connected=true;
	}
    }
    try {
	//PRINTOUT: System.out.println("\nOutputing collection specs : ");
	if(null!=getCollections()){
	    //PRINTOUT:Enumeration enum = getCollections().elements();
	    //PRINTOUT:while(enum.hasMoreElements()) {
	    //PRINTOUT:     System.out.println(enum.nextElement().toString());
	    //PRINTOUT:}
	    //PRINTOUT: System.out.println("Done outputing collection specs : ");
	}else{
	    System.err.println("There are no collection specs");
	}
    }catch(Exception coe) {
	coe.printStackTrace();
    }
				
}


    /** Close connection.
 * Closes the connection to the server.
 */
public void close(){
    if(connected && client!=null) {
	client.close();
    }
    connected=false;
}
        
/**
 * Checks the validity of the connection.
 * @return true if connection is valid.
 */
public boolean isValidAndRunning() { return connected;  }
    
/**
 * Retrieves the state of the connection. @see CharmerConnectionMRML#S_CONNECTED
 * @return the state of the connection.
 */
public int getState() { return state; }
    
/**
 * Retrieve the URL prefix. The file identifiers in the Charmer system are simple filenames. 
 * The string returned by this method is the prefix to prepend to them in order to make valid 
 * URL's for accessing the images.
 * @return the prefix of the URL of the images.
 */
public String getURLBase() {return null;}
    
    
/**
 * Returns the set of available collections delivered by the server.
 * @return a hashtable of CollectionSpec objects.
 */
public Hashtable getCollections(){
    if(connected && CollectionList!=null){
	Hashtable ret = new Hashtable();
	Enumeration e = CollectionList.elements();
	while(e.hasMoreElements()){
	    CollectionSpec cs = (CollectionSpec)e.nextElement();
	    cs.Algorithms = getAlgorithms(cs.mQueryParadigmList);
	    ret.put(cs.ID,cs);
	}
	System.out.println("returning from getcollections");
	return ret;
    } else {
	return null;
    }
}
        
/*
 * Returns the list of available algorithms associated with the collection.
 */
private Vector getAlgorithms(CXMLElement inQueryParadigmList){
    if(connected ){//&& mIDToAlgorithmList.contains(AlgListID)) {
	Vector lReturnValue = new Vector();
	for(Enumeration eAlgorithms = mIDToAlgorithm.elements();
	    eAlgorithms.hasMoreElements();
	    ) {
	    AlgorithmSpec lAlgorithmSpec = (AlgorithmSpec)(eAlgorithms.nextElement());

	    if(CQueryParadigmMatcher.matchesParadigmList(inQueryParadigmList,
							 lAlgorithmSpec.mQueryParadigmList)){
		//PRINTOUT: System.out.println("Adding algorithm");
		lReturnValue.addElement(lAlgorithmSpec);
	    }else{
		//PRINTOUT: System.out.println("NOT adding algorithm");
	    }
	}
	System.out.println("returning from getAlgorithms");
	return lReturnValue;
    } else 
	return null;
}

public AlgorithmSpec getAlgorithm(String inID){

    return (AlgorithmSpec)(mIDToAlgorithm.get(inID));
}

public CXMLElement getPropertySheet(String inID){

    AlgorithmSpec lAS=(AlgorithmSpec)mIDToAlgorithm.get(inID);

    if(lAS!=null){
	return lAS.mPropertySheet;
    }

    return null;
}


/**
 * Performs a similarity search on the current collection.
 * The results are returned as an array of QueryObjects understood by Charmer interface.
 *@param qos input array of query objects.
 *@param CollectionID the identifier of the collection (not the name!).
 *@param AlgorithmID the identifier of the algorithm (not the name!).
 *@param maxReturnQty maximum number of images to return.
 *@param cutoff the maximum distance allowed.
 */
public QueryObject[] doSimilaritySearch(QueryObject qos[],
					int maxReturnQty,
					String inAlgorithmID,
					String inCollectionID,
					CPropertyElement inPropertyRoot){
    return doSimilaritySearch(qos, 
			      maxReturnQty,
			      inAlgorithmID,
			      inCollectionID,
			      inPropertyRoot,
			      null);
}
/**
 * Performs a similarity search on the current collection.
 * The results are returned as an array of QueryObjects understood by Charmer interface.
 *@param qos input array of query objects.
 *@param CollectionID the identifier of the collection (not the name!).
 *@param AlgorithmID the identifier of the algorithm (not the name!).
 *@param maxReturnQty maximum number of images to return.
 *@param cutoff the maximum distance allowed.
 */
public QueryObject[] doSimilaritySearch(QueryObject qos[],
					int maxReturnQty,
					String inAlgorithmID,
					String inCollectionID,
					CPropertyElement inPropertyRoot,
					String inAdditionalXML){
    double cutoff=0;
    

    //PRINTOUT: System.out.println("DO SIMILARITY SEARCH\n");
    //PRINTOUT: System.out.print(inAlgorithmID);
    //PRINTOUT: System.out.print(":");
    //PRINTOUT: System.out.println(inCollectionID);

    clearQuery(getCurrentSession(),
	       ""+maxReturnQty,
	       ""+cutoff,
	       inAlgorithmID,
	       inCollectionID);
    for(int i=0;i<qos.length;i++){
	mUserRelevanceList.addItem(new CUserRelevanceElement(qos[i].location.toString()
							     ,""
							     ,new Integer(qos[i].type).toString()));
    }


    String lConfigureString=makeConfigureMessage(inAlgorithmID,
						 inCollectionID,
						 inPropertyRoot);

    if(null==inAdditionalXML){
	if(sendQuery(lConfigureString)){
	    if(readMessage()){
		return translateToCharmer();
	    }
	}
    }else{
	if(sendQuery(lConfigureString,
		     inAdditionalXML)){
	    if(readMessage()){
		return translateToCharmer();
	    }
	}
    }
    //if we get this far, it means either send or receive failed
    return null;        
}
    
    
public QueryObject[] getRandomImages(int inResultSize,
				     String AlgorithmID,
				     String CollectionID, 
				     CPropertyElement inPropertyElement) {
    if(sendRandomImages(getCurrentSession(), 
			""+ inResultSize,
			AlgorithmID, 
			CollectionID,
			inPropertyElement)){
	if(readMessage()){
	    return translateToCharmer();
	}
    }
    return null;
}

private QueryObject[] translateToCharmer(){
    //should be called when mUserRelevanceList contains new results.
    //PRINTOUT: System.out.println("<The results are :> ");
    //PRINTOUT: System.out.println(mUserRelevanceList.toString());
    int nret = mUserRelevanceList.mContent.size();
    QueryObject ret[] = new QueryObject[nret];
    //PRINTOUT: System.out.println("</The results are : >");
    for(int i=0;i<nret;i++){
	ret[i] = new QueryObject();
	QueryObject qo = ret[i]; //naming facility
	String urls = ((CUserRelevanceElement)mUserRelevanceList.mContent.elementAt(i)).mImageLocation;

	//PRINTOUT: System.out.println("<looking at URL: >");
	//PRINTOUT: System.out.print(i);
	//PRINTOUT: System.out.print(",");
	//PRINTOUT: System.out.print(urls);
	//PRINTOUT: System.out.println("</looking at URL: >");

	try {
	    qo.location = new URL(urls);
	    qo.mThumbnailLocation = new URL(((CUserRelevanceElement)mUserRelevanceList.mContent.elementAt(i)).mThumbnailLocation);
	}catch(MalformedURLException mue){
	    qo.location = DUMMYURL;
	}
	double rt = Double.valueOf(((CUserRelevanceElement)mUserRelevanceList.mContent.elementAt(i)).mUserRelevance).doubleValue();
	qo.loader=loader;
	qo.mCalculatedSimilarity = new Double(rt);
	qo.type=0;
	qo.fname = urls.substring(urls.lastIndexOf('/')+1,urls.length());
	//qo.loader = null;
	qo.cdist=qo.ldist=qo.tdist=i;
	qo.dist=i;
	String qualif = qo.mCalculatedSimilarity.toString();//((qo.type>0)?"relevant":((qo.type<0)?"non-relevant":"neutral"));
	qo.title = i+": "+qualif;
	qo.description = "unavailable";
	qo.tip = qo.fname+"\n  "+qualif;
    }
    return ret;
}


// ---------------------------------
// Instance data fields, private
// ---------------------------------
    
//Data should not be modified after creation
private boolean connected = false;
private int state = -1;
private String mHost;
private int mPort=44322;
private Charmer loader;

static {
    try{
	DUMMYURL = new URL("http://isrpc85.epfl.ch/Charmer/images/Charmer.gif");
    }catch(Exception e){
	DUMMYURL = null;
    }
}
}
