// -*- mode: java -*- 
/* 

    Viper, a flexible content based image retrieval system.
    Copyright (C) 1998-1999 CUI, University of Geneva

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

package charmer.mrml;

import java.util.*;
import charmer.mrml.*;
import org.xml.sax.AttributeList;

/**

   This matches two query paradigm lists. They match, if there exsists 
   a pair of query paradigms taken from the two lists which matches.

 */
public class CQueryParadigmMatcher{
    /** 
	Two query paradigms match, if 
	the intersection of their attribute sets
	has equal values.
     */
    public static boolean matchesParadigm( CXMLElement inQuery, CXMLElement inResult){

	// they have to be both query-paradigms otherwise there's something
	// wrong
	if((0!=inQuery.getName().compareTo(mrml_const.query_paradigm))
	   ||
	   (0!=inResult.getName().compareTo(mrml_const.query_paradigm))){
	    System.out.print("false: ");
	    System.out.print(inQuery.getName());
	    System.out.print(",");
	    System.out.print(inResult.getName());
	    System.out.println("_");
	    return false;
	}

	CXMLElement lQuery=inQuery;
	CXMLElement lResult=inResult;
	
	AttributeList lQueryAttributes=inQuery.getAttributes();
	AttributeList lResultAttributes=inResult.getAttributes();

	for (int i = 0; i < lQueryAttributes.getLength(); i++) {
	    String lName = lQueryAttributes.getName(i);
	    String lQueryValue = lQueryAttributes.getValue(i);
	    String lResultValue=lResultAttributes.getValue(lName);

	    //both attributes are nonnull
	    //and they are not equal => they do not match
	    if((null!=lResultValue)
	       && (null!=lQueryValue)){
		if((0!=lQueryValue.compareTo(lResultValue))
		   &&
		   (0!=lQueryValue.compareTo(""))
		   &&
		   (0!=lResultValue.compareTo(""))){
		    return false;
		}
	    }
	    System.out.print(".");
	}

	//i.e. the intersection set matched
	return true;
    }
    /** 
	Two query-paradigm-list s match, if there exsists one 
	pair of children which matches.
     */
    public static boolean matchesParadigmList( CXMLElement inQuery, CXMLElement inResult){
  
	//either at least one pair matches,
	if((0==inQuery.getName().compareTo(mrml_const.query_paradigm_list))
	   &&
	   (0==inResult.getName().compareTo(mrml_const.query_paradigm_list))){
	    for(Enumeration lQueryEnumerator=inQuery.getChildEnumeration();
		lQueryEnumerator.hasMoreElements();
		){
		CXMLElement i=(CXMLElement)lQueryEnumerator.nextElement();
		for(Enumeration lResultEnumerator=inResult.getChildEnumeration();
		    lResultEnumerator.hasMoreElements();
		    ){
		    CXMLElement j=(CXMLElement)lResultEnumerator.nextElement();
		    if(matchesParadigm(i,j)){
			return true;
		    }
		}
	    };
	}else{
	    System.out.println("WRONG TREE LEVEL");
	}
	// or we return false
	return false;
    };
}
