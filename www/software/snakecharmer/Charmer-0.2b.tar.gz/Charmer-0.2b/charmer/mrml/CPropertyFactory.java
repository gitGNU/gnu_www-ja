package charmer.mrml;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

import org.xml.sax.AttributeList;
import org.xml.sax.helpers.AttributeListImpl;

public class CPropertyFactory{

    /**
       Construct a new element
       @param inAttributes are the attributes which fully specify the 
       look and the function of this element 
    */
    static public CPropertyElement constructElement(AttributeList inAttributes){
	String lType=(String)inAttributes.getValue(mrml_const.property_sheet_type);
	
	if(0==lType.compareTo("subset")){
	    System.out.println("subset");

	    return new CPPSubset(inAttributes);
	}
	if(0==lType.compareTo("multiset")){
	    System.out.println("multiset");
	    return null;
	}
	if(0==lType.compareTo("set-element")){
	    System.out.println("checkbox");
	    return new CPPCheckbox(inAttributes);
	}
	if(0==lType.compareTo("numeric")){
	    System.out.println("numeric");
	    return new CPPSlider(inAttributes);
	}
	if(0==lType.compareTo("textual")){
	    System.out.println("textual");
	    return null;
	}
	if(0==lType.compareTo("panel")){
	    System.out.println("panel");
	    return new CPPPanel(inAttributes);
	}
	return null;
    };
}
