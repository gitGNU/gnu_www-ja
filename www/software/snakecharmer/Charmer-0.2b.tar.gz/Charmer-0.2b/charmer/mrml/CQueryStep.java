// -*- mode: java -*- 
/* 

    Viper, a flexible content based image retrieval system.
    Copyright (C) 1998-1999 CUI, University of Geneva

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.mrml;

import java.lang.String;


public class CQueryStep{
    private String mSessionID;
    private String mResultSize;
    private String mResultCutoff;
    private String mCollectionID;
    private String mAlgorithmID;

    private CUserRelevanceList mUserRelevanceList;

    public CQueryStep(String inSessionID,
		      String inResultSize,
		      String inResultCutoff,
		      String inAlgorithmID,
		      String inCollectionID,
		      CUserRelevanceList inUserRelevanceList){
	mSessionID=inSessionID;
	mUserRelevanceList=inUserRelevanceList;
	mResultSize= inResultSize;
	mResultCutoff=inResultCutoff;
	mCollectionID=inCollectionID;
	mAlgorithmID=inAlgorithmID;
    };
    public String toString(){
	return new String("<query-step"
			  +" session-id=\""+mSessionID +"\" \n"
			  +" result-size=\""+mResultSize +"\" \n"
			  +" result-cutoff=\""+mResultCutoff +"\" \n"
			  +" collection-id=\""+mCollectionID +"\" \n"
			  +" algorithm-id=\""+mAlgorithmID +"\"> \n"
			  +mUserRelevanceList.toString()
			  +"</query-step>");
    };
    /** 
	this is a VERY DIRTY HACK don't try this at home 
     */
    public String toStringWithAdditionalXML(String inAdditionalXML){
	return new String("<query-step"
			  +" session-id=\""+mSessionID +"\" \n"
			  +" result-size=\""+mResultSize +"\" \n"
			  +" result-cutoff=\""+mResultCutoff +"\" \n"
			  +" collection-id=\""+mCollectionID +"\" \n"
			  +" algorithm-id=\""+mAlgorithmID +"\"> \n"
			  +inAdditionalXML
			  +mUserRelevanceList.toString()
			  +"</query-step>");
    };
}
