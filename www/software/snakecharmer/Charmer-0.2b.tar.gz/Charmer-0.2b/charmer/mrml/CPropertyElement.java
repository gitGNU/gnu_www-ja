package charmer.mrml;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

import org.xml.sax.AttributeList;
import org.xml.sax.helpers.AttributeListImpl;

public interface CPropertyElement{

    /** 
	the component containing the Button/Menu associated
	with this element.
    */
    public Panel getThisPanel();
    /** 
	get the name of this (for non-panels)
    */
    public String getThisName();
    /** is this a panel or does this need 
	special treatment ?*/
    public boolean isPanel();
    /** add a child */
    public void addChild(CPropertyElement inChild);
    /** hides the children of this */
    public void hideChildren();
    /** shows the children of this */
    public void showChildren();
    /** clears a dirty-bit */
    public void clearChanged();
    /** sets a dirty-bit */
    public void setChanged();
    /** queries dirty-bit */
    public boolean isChanged();
    /** sets the father of this 
	(useful for handing through
	dirty-bits) */
    public void setFather(CPropertyElement inFather);

    /** traverses the hierarchy */
    public void traverse(CXMLElementVisitor inVisitor);
};

