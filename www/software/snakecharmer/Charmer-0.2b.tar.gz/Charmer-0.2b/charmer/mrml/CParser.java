// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.mrml;                    

import charmer.mrml.mrml_const;
import charmer.mrml.CXMLElement;

import org.xml.sax.InputSource;
                    
import java.net.*;
import java.io.*;
import java.util.*;

import java.util.Vector;

import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

import org.xml.sax.AttributeList;
import org.xml.sax.HandlerBase;
import org.xml.sax.Parser;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import org.xml.sax.helpers.ParserFactory;
import org.xml.sax.helpers.AttributeListImpl;

/**
 * A sample SAX writer. This sample program illustrates how to
 * register a SAX DocumentHandler and receive the callbacks in
 * order to print a document that is parsed.
 *
 * @version mrep/CParser.java
 */


class CElementHandler{

    private CParser mParser;

    CElementHandler(CParser inParser){
	mParser=inParser;
    }

    public boolean startElement(String inName,
				AttributeList inAttributes){	
	return false;
    };
    public boolean endElement(String inName,
			      AttributeList inAttributes){
	return false;
    };
}

/** handles the document */
class CMrepHandler{

    private CParser mParser;

    CMrepHandler(CParser inParser){
	mParser=inParser;
    }

    public boolean startElement(String inName,
				AttributeList inAttributes){
	
	return true;
    };
    public boolean endElement(String inName,
			      AttributeList inAttributes){
	return true;
    };
}



/**
 * A sample SAX writer. This sample program illustrates how to
 * register a SAX DocumentHandler and receive the callbacks in
 * order to print a document that is parsed.
 *
 * @version Revision: 06 1.4 samples/sax/SAXWriter.java, samples, xml4j2, xml4j2_0_5 
 */
public class CParser 
    extends org.xml.sax.HandlerBase {

    /** this will in the end be the only representation
	which will be constructed during parsing */
    CXMLElement mDocumentRoot;

    //
    // Interface of a java program using this parser
    //
    CMRMLUser mCaller;

    //
    // Constants
    //

    /** Default parser name. */
    private static final String 
	DEFAULT_PARSER_NAME = "com.microstar.xml.SAXDriver";

    //
    // Data
    //

    /** Print writer. */
    private PrintWriter out;

    /** Canonical output. */
    private boolean canonical;


    private boolean mParsing;

    private void beginParse(){
	mParsing=false;
    }
    private void endParse(){
	mParsing=false;
    }
    private boolean isParsing(){
	return mParsing;
    }
    
    //
    // Constructors
    //

    /** Default constructor. */
    public CParser() {

	mDocumentRoot=null;

	System.out.println("beginning of new CParser");

	try {
	    out = new PrintWriter(new OutputStreamWriter(System.out, "UTF8"));
	}
	catch (UnsupportedEncodingException e) {
	    System.err.println("encoding UTF8 not supported");
	}
	this.canonical = false;
	
	System.out.println("End of new CParser");

    } // <init>(boolean)

    //
    // Public static methods
    //


    // 	    //listen
    // 	    Socket lSocket = new Socket(inHost, 
    // 					inPort.intValue());
    // 	    mInputStream = new DataInputStream(lSocket.getInputStream());


    void setCaller(CMRMLUser inCaller){
	mCaller=inCaller;
    }

    //     public static void parse(CMRMLUser inCaller,
    // 			     String inHost,
    // 			     Integer inPort) throws java.io.IOException{
    //         try {
    // 	    Socket               lSocket = new Socket(inHost, 
    // 						      inPort.intValue());
    // 	    DataInputStream lInputStream = new DataInputStream(lSocket.getInputStream());
    //             CParser         handler = new CParser();

    // 	    handler.setCaller(inCaller);
	    
    //             Parser parser = ParserFactory.makeParser(DEFAULT_PARSER_NAME);
    //             parser.setDocumentHandler(handler);
    //             parser.setErrorHandler(handler);
    //             parser.parse(new InputSource(lInputStream));
	    
    //         }
    //         catch (Exception e) {
    //             e.printStackTrace(System.err);
    //         }
    //     }    
    public void parse(CMRMLUser inCaller,
		      Socket inSocket)
	throws java.io.IOException{

	System.out.println("CParser::parse("+inCaller+" , "+inSocket+") called.");

	beginParse();

	String lMessage=new String();
        try {
	    DataInputStream lInputStream = 
		new DataInputStream(
				    inSocket.getInputStream()
				    //new BufferedInputStream(
				    );
	    
	    //as a workaround: slurp in everything
	    
	    StringBuffer zb = new StringBuffer();
	    int lRead=0;
	    boolean lNothingRead=true;
	    try{
		do{
		    lRead=lInputStream.read();
		    lNothingRead=false;
		    if(lRead>=0){
			zb.append((char)lRead);
		    }
		}while(lRead > 0);
		lInputStream.close();
	    }
	    catch(Exception e){
		System.out.println("While reading I caught exception : "
				   +e.getClass().getName());
		e.printStackTrace();
		System.out.println("Currently message is : ---\n"+lMessage+"\n---.");
					
		//int lRead=0;
		if((lRead>0) || lNothingRead) do{
		    lRead=lInputStream.read();
		    if(lRead>=0){
			//System.out.print("e");
			char[] lString=new char[1];
			lString[0]=(char)lRead;
			lMessage+=new String(lString);
		    }
		}while(lRead > 0);
		System.out.println("finished reading");
	    }
	    lMessage=zb.toString();
	    //PRINTOUT: System.out.println(lMessage);
	    FileWriter fw=null;
	    try{
		fw = new FileWriter("E:\\out.mrml");
		fw.write(lMessage,0,lMessage.length()-1);
	    }catch(Exception e){								
	    }
	    finally{
		if(fw!=null){
		    fw.close();
		}
	    }
	    lInputStream.close();
	}
	catch(Exception mye){

	}
	try{
	    CParser         handler = new CParser();
	    
	    handler.setCaller(inCaller);
	    
	    System.out.println("makeparser");
	    Parser parser = ParserFactory.makeParser(DEFAULT_PARSER_NAME);
	    parser.setDocumentHandler(handler);
	    parser.setErrorHandler(handler);
	    InputSource lSource=new InputSource(new StringReader(lMessage));
	    //PRINTOUT: System.out.println("Directly before parsing:"+ lMessage + "\n");
	    //PRINTOUT: System.out.flush();


	    mDocumentRoot=null;;
	    parser.parse(lSource);//lInputStream
	    

	    CXEVCommunication lVisitor=new CXEVCommunication();
	    lVisitor.setMRMLUser(handler.mCaller);
	    
	    System.out.print("The document root is: ");
	    System.out.println(handler.mDocumentRoot);
	    handler.mDocumentRoot.traverse(lVisitor);
	    System.out.println("DIRECTLY AFTER TRAVERSING");
	    System.out.flush();
	    
        }catch (Exception mye) {
	    System.out.println("Caught exception during parsing and not during read!");
	    System.err.println(mye.toString());
	    mye.printStackTrace();
        }
	try{
	    inSocket.close();
	}catch(IOException ie){
	    System.out.println("YES! Exception is thrown if I try to close it as well.");
	    ie.printStackTrace();
	}
    }

    /** Prints the output from the SAX callbacks. */
    public static void print(String uri) {

	try {
	    HandlerBase handler = new CParser();

	    Parser parser = ParserFactory.makeParser(DEFAULT_PARSER_NAME );
	    parser.setDocumentHandler(handler);
	    parser.setErrorHandler(handler);
	    parser.parse(uri);
	}
	catch (Exception e) {
	    e.printStackTrace(System.err);
	}

    } // print(String,String,boolean)

    //
// DocumentHandler methods
//

/** Processing instruction. */
public void processingInstruction (String target, String data) {

    /*out.print("<?");
      out.print(target);
      if (data != null && data.length() > 0) {
      out.print(' ');
      out.print(data);
      }
      out.print("?>");*/

} // processingInstruction(String,String)

    /** Start document. */
public void startDocument() {

    if (!canonical) {
	//out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    }

} // startDocument()

/** Start element. */
public void startElement(String name, AttributeList attrs) {
    
    out.println("["+name+"]\n");
    out.flush();

    AttributeListImpl lAttributes=new AttributeListImpl(attrs);

    if(mDocumentRoot==null){
	mDocumentRoot=new CXMLElement(name,
				      lAttributes);
    }else{
	mDocumentRoot.addChild(new CXMLElement(name,
					       lAttributes));
    }
    
    //    out.println("------------------------------["+name+"]\n");
    //    out.flush();

				//------------------------------
				//Handshake message coming from the server
				//------------------------------
    if(attrs!=null){
	if(0==name.compareTo(new String(mrml_const.query_result))){
	    mCaller.setCurrentSession(attrs.getValue(mrml_const.session_id));
	}
				//--------------------List of sessions
	if(0==name.compareTo(new String(mrml_const.session_list))){
	    mCaller.clearSessionList(new String("0"));//attrs.getValue(mrml_const.session_list_id));
	}
				//Add element to list of sessions
	if(0==name.compareTo(new String(mrml_const.session))){
	    mCaller.addSessionToList(attrs.getValue(mrml_const.session_id),
				     attrs.getValue(mrml_const.session_name)
				     );
	    // is this a hack?
	    mCaller.setCurrentSession(attrs.getValue(mrml_const.session_id));
	}
				//--------------------List of collections
// 	if(0==name.compareTo(new String(mrml_const.collection_list))){
// 	    System.out.println("______________");
// 	    System.out.println("COLLECTIONLIST");
// 	    mCaller.clearCollectionList("0");
// 	    System.out.println("--------------");
// 	}
				//Add element to list of collections
// 	if(0==name.compareTo(new String(mrml_const.collection))){

// 	    System.out.println("_________________");
// 	    System.out.println("ADDING COLLECTION");

// 	    mCaller.addCollectionToList(attrs.getValue(mrml_const.collection_id),
// 					attrs.getValue(mrml_const.collection_name),
// 					attrs.getValue(mrml_const.cui_algorithm_id_list_id)
// 					);
// 	}
				//--------------------List of algorithm names
	if(0==name.compareTo(new String(mrml_const.algorithm_list))){
	    mCaller.clearAlgorithmList("0");
	}
				//Add element to list of algorithmnames
// 	if(0==name.compareTo(new String(mrml_const.algorithm))){
// 	    System.out.println("_________");
// 	    System.out.println("ALGORITHM");
// 	    System.out.println(attrs.getValue(mrml_const.algorithm_id));
// 	    System.out.println(attrs.getValue(mrml_const.algorithm_name));
// 	    mCaller.addAlgorithmNameToList(attrs.getValue(mrml_const.algorithm_id),
// 					   attrs.getValue(mrml_const.algorithm_name)
// 					   );
// 	}
				//--------------------List of lists of algorithm ids
// 	if(0==name.compareTo(new String(mrml_const.cui_algorithm_id_list_list))){
// 	    // at present NOT: mCaller.clearAlgorithmNameList(attrs.getValue("listid"));
// 	    //mCaller.clearAlgorithmIDListList();
// 	}
// 				//Add element to list of algorithmnames
// 	if(0==name.compareTo(new String(mrml_const.cui_algorithm_id_list))){
// 	    System.out.println("_________");
// 	    System.out.println("A     IDL");
// 	    System.out.println(attrs.getValue(mrml_const.cui_algorithm_id_list_id));
	    
// 	    //mCaller.addAlgorithmIDList(attrs.getValue(mrml_const.cui_algorithm_id_list_id));
// 	}
// 				//Add element to list of algorithmnames
// 	if(0==name.compareTo(new String(mrml_const.cui_algorithm_id))){
// 	    System.out.println("_________");
// 	    System.out.println("A      ID");
// 	    System.out.println(attrs.getValue(mrml_const.cui_algorithm_id));
// 	    mCaller.addAlgorithmIDToCurrent(attrs.getValue(mrml_const.cui_algorithm_id));
// 	}
				//------------------------------
				//Result coming from the server
				//------------------------------
// 	if(0==	name.compareTo(new String(mrml_const.query_result_element))){
// 	    System.out.println("Why don't I execute this?");
// 	    if((attrs.getValue(mrml_const.image_location)!=null) 
// 	       && (attrs.getValue(mrml_const.calculated_similarity)!=null)){

// 		mCaller.addImageToDisplay(new String(attrs.getValue(mrml_const.image_location)),
// 					  new Double(attrs.getValue(mrml_const.calculated_similarity)),
// 					  new Double(0));
// 		System.out.println("But I do execute this!");
// 	    }else{
// 		System.out.println("...because some attributes are null!");
// 	    }

// 	}
    
    }
} // startElement(String,AttributeList)

    /** Characters. */
public void characters(char ch[], int start, int length) {

    //out.print(normalize(new String(ch, start, length)));

} // characters(char[],int,int);

    /** Ignorable whitespace. */
public void ignorableWhitespace(char ch[], int start, int length) {

    characters(ch, start, length);

} // ignorableWhitespace(char[],int,int);

/** End element. */
public void endElement(String name) {

    out.println("MOVING UP");

    mDocumentRoot.moveUp();

    if(0==name.compareTo(new String(mrml_const.query_result))){
	//mCaller.showImageDisplay();//the correction here is new as of 20000309 taken out of again, one day later...
    }
    if(0==name.compareTo(new String(mrml_const.mrml))){

	out.print("\nEND\n\n");
	out.flush();
	    
	endParse();
    }

    if(0==name.compareTo(new String(mrml_const.cui_shandshake))){

	out.print("\n\nESH\n\n");
	out.flush();
	    
	mCaller.endServerHandshake();
    }

    //out.print("</");
    //out.print(name);
    //out.print('>');

} // endElement(String)

/** End document. */
public void endDocument() {

    out.flush();

} // endDocument()

//
// ErrorHandler methods
//

/** Warning. */
public void warning(SAXParseException ex) {
    System.err.println("[Warning] "+
		       getLocationString(ex)+": "+
		       ex.getMessage());
}

/** Error. */
public void error(SAXParseException ex) {
    System.err.println("[Error] "+
		       getLocationString(ex)+": "+
		       ex.getMessage());
}

/** Fatal error. */
public void fatalError(SAXParseException ex) throws SAXException {
    System.err.println("[Fatal Error] "+
		       getLocationString(ex)+": "+
		       ex.getMessage());
    throw ex;
}

/** Returns a string of the location. */
private String getLocationString(SAXParseException ex) {
    StringBuffer str = new StringBuffer();

    String systemId = ex.getSystemId();
    if (systemId != null) {
	int index = systemId.lastIndexOf('/');
	if (index != -1) 
	    systemId = systemId.substring(index + 1);
	str.append(systemId);
    }
    str.append(':');
    str.append(ex.getLineNumber());
    str.append(':');
    str.append(ex.getColumnNumber());

    return str.toString();

} // getLocationString(SAXParseException):String

//
// Private static methods
//


}

