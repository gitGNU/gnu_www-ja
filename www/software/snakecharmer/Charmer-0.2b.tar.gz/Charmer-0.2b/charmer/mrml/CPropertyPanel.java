package charmer.mrml;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

import org.xml.sax.AttributeList;
import org.xml.sax.helpers.AttributeListImpl;

/** */
public class CPropertyPanel extends CXMLElement
    implements CPropertyElement, ActionListener{
    /** the property panels which are children of this */
    Vector mPropertyChildren;
    /** mLayout */
    GridBagLayout mLayout;
    /** mConstraints */
    GridBagConstraints mConstraints;
    /** the name of this element (if it's not a panel) */
    String mThisName;
    /** see below */
    Panel mThisPanel;
    /** panel containing the children */
    Panel mChildPanel;
    /** */
    boolean mIsPanel;
    
    /** the father of this */
    CPropertyElement mFather;
    /** the father of this */
    public void setFather(CPropertyElement inFather){
	mFather=inFather;
    }
    /** dirty-bit */
    boolean mIsChanged=false;
    /** dirty-bit */
    public void setChanged(){
	mIsChanged=true;

	if(null!=mFather){
	    mFather.setChanged();
	}
    }
    /** dirty-bit */
    public void clearChanged(){
	mIsChanged=false;

	for(int i=0;
	    i<mPropertyChildren.size();
	    i++){
	    if(null!=((CPropertyElement)mPropertyChildren.elementAt(i))){
		((CPropertyElement)mPropertyChildren.elementAt(i)).clearChanged();
	    }
	}
    }
    /** dirty-bit */
    public boolean isChanged(){
	return mIsChanged;
    }

    /** 
	the component containing the Button/Menu associated
	with this element.
    */
    public Panel getThisPanel(){
	return mThisPanel;
    };
    /** 
	get the name of this (for non-panels)
    */
    public String getThisName(){
	return mThisName;
    };
    /** 
	get the name of this (for non-panels)
    */
    public void setThisName(String inName){
	mThisName=inName;
    };
    /** finds out, if this is a panel or
	an item which need special treatment
    */
    public boolean isPanel(){
	return mIsPanel;
    }

    /** add a component to this */
    void addComponent(Component inComponent){
	mLayout.setConstraints(inComponent, 
			       mConstraints);
	mThisPanel.add(inComponent);
    }
    /** construct this  */
    public CPropertyPanel(){
	mPropertyChildren= new Vector();
	mName=mrml_const.property_sheet;
    };

    public void setComponent(Component inThis){
	mLayout = new GridBagLayout();
	mConstraints = new GridBagConstraints();

	mThisPanel =new Panel();
	mThisPanel.setFont(new Font("Helvetica", Font.PLAIN, 14));
	mThisPanel.setLayout(mLayout);

	GridLayout lChildLayout=new GridLayout(0,1);
	mChildPanel =new Panel();
	//mChildPanel.setFont(new Font("Helvetica", Font.PLAIN, 14));
	mChildPanel.setLayout(lChildLayout);
	
	mConstraints.fill = GridBagConstraints.BOTH;
	mConstraints.gridwidth=10;
	mConstraints.gridheight=10;
	mConstraints.weightx = 1.0;
	mConstraints.weighty = 1.0;
	mConstraints.gridwidth=GridBagConstraints.REMAINDER;
	if(inThis!=null){
	    addComponent(inThis);
	}
	mConstraints.weighty = 20.0;
	mConstraints.weightx = 1.0;
	mConstraints.gridheight=GridBagConstraints.REMAINDER;
	mConstraints.gridwidth=1;
	addComponent(new Panel());
	mConstraints.weightx = 10.0;
	mConstraints.gridwidth=GridBagConstraints.REMAINDER;
	addComponent(mChildPanel);
    }


    public void actionPerformed(ActionEvent e){
	System.out.println("hallo");
    }

    /** construct this (for menu items)  */
    public CPropertyPanel(String inName){
	mThisName=new String(inName);
	mThisPanel=new Panel();
    }

    /** add a child */
    public void addChild(CPropertyElement inChild){
	inChild.setFather(this);
	mPropertyChildren.addElement(inChild);
	addChild((CXMLElement) inChild);
	super.moveUp();
	mChildPanel.add(inChild.getThisPanel());
    }
    /** add a child */
    public void hideChildren(){
	System.out.println("hiding children");
	//	mThisPanel.remove(mChildPanel);
	mChildPanel.setVisible(false);
	mChildPanel.validate();
	mThisPanel.validate();
    }
    /** add a child */
    public void showChildren(){
	System.out.println("showing children");
	//      addComponent(mChildPanel);
	mChildPanel.setVisible(true);
	mChildPanel.validate();
	mThisPanel.validate();

    }
}
