// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
//
//
// A program which uses MRML. Here we give just the interface.
//
//Author: Wolfgang M�ller

package charmer.mrml;

import java.lang.*;


//should be ...Client
public interface CMRMLUser{
    //------------------------------------------------------------
    /// Helpers
    //------------------------------------------------------------
    public String getCurrentSession();
    public String frame(String inString);
    public String preamble();
    //------------------------------------------------------------
    /// Recieving a query result
    //------------------------------------------------------------
    public void  clearImageDisplay();
    ///
    public void  addImageToDisplay(String inURL,
				   String inThumbnailURL,
				   Double inCalculatedSimilarity);
    ///
    public void  showImageDisplay();

    //------------------------------------------------------------
    /// Sending the interface handshake
    //------------------------------------------------------------
    ///
    public boolean sendInterfaceHandshake(String inUserName);

    //------------------------------------------------------------
    /// Sending a query
    //------------------------------------------------------------
    public void clearQuery(String inID,
			   String inResultSize,
			   String  inResultCutoff,
			   String  inCollectionID,
			   String  inAlgorithmID);
    ///call this when traversing query list for setting relevance
    public void addUserRelevanceElement(String inURL,
					Double inUserRelevance);
    ///
    public boolean sendQuery();

    //------------------------------------------------------------
    ///Recieving the server handshake
    //------------------------------------------------------------
    public void setCurrentSession(String inSession);
    //--------------------
    /// Recieving the list of possible sessions
    //--------------------
    ///Priority low
    ///call this at the begin of the ssessionlist ELEMENT
    public void clearSessionList(String inListID);
    ///call this at each encountered ssession ELEMENT
    public void addSessionToList(String inID,
				 String inName);

    //--------------------
    /// Recieving the list of algorithm names
    /// Translator from algorithm id to algorithm name
    //--------------------
    ///
    public void clearAlgorithmList(String inID);
    ///
    public void addAlgorithmToList(String inID,
				   String inName,
				   CXMLElement inQueryParadigmList,
				   CXMLElement inPropertySheet);
    
    //--------------------
    /// Recieving the list of possible collections
    //--------------------
    ///
    public void clearCollectionList(String inListID);
    ///
    public void addCollectionToList(String inID,
				    String inName,
				    CXMLElement inQueryParadigmList);
    
    //
    public boolean sendRandomImages(String inID,
				    String  inResultSize,
				    String  inAlgorithmID,
				    String  inCollectionID,
				    CPropertyElement inPropertyElement);

    //now use all these structures
    public void endServerHandshake();    
    
};
