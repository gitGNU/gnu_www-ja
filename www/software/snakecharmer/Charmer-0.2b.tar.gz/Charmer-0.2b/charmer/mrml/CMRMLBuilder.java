package charmer.mrml;
import java.lang.*;
import java.util.*;

public class CMRMLBuilder{
    /** is currently an attribute open?*/
    protected boolean mIsOpenAttribute;
    /** the name of the currently open attribute */
    protected String mOpenAttributeName;
    /** the name of the value of the currently open attribute */
    protected String mOpenValueName;

    /** is currently a start tag "open"*/
    protected boolean mIsOpenStartTag;

    /** store what's generated */
    String mGenerated;


    /** add attribute to generated */
    public void addAttributeToGenerated(String inName,
					String inValue){
	mGenerated+=" "+inName+"=\""+inValue+"\" ";
    }
    /** add attribute to generated */
    public void addAttributeToGenerated(String inName,
					double inValue){
	mGenerated+=" "+inName+"=\""+(new Double(inValue)).toString()+"\" ";
    }
    /** add attribute to generated */
    public void addAttributeToGenerated(String inName,
					long inValue){
	mGenerated+=" "+inName+"=\""+(new Long(inValue)).toString()+"\" ";
    }
    /** add attribute to generated */
    public void addAttributeToGenerated(String inName,
				 boolean inValue){
	mGenerated+=" "+inName+"=\""+(new Boolean(inValue)).toString()+"\" ";
    }
    /** open a start tag */
    public void openStartTag(String inElementName){
	if(mIsOpenStartTag){
	    closeStartTag();
	}
	mIsOpenStartTag=true;
	mGenerated+="<"+inElementName+" ";
    };
    /** closes an open start tag */
    public void closeStartTag(){
	if(mIsOpenStartTag){
	    mGenerated+=">";
	    mIsOpenAttribute=false;
	    mIsOpenStartTag=false;
	}
    }
    /** opens an attribute */
    public void openAttribute(String inName){
	mIsOpenAttribute=true;
	mOpenAttributeName=inName;
    }
    /** opens an attribute */
    public void closeAttribute(String inValue){
	mIsOpenAttribute=false;
	addAttributeToGenerated(mOpenAttributeName,
				inValue);
    }
    /** opens an attribute */
    public void closeAttribute(long inValue){
	
	mIsOpenAttribute=false;
	addAttributeToGenerated(mOpenAttributeName,
				inValue);
    }
    /** opens an attribute */
    public void closeAttribute(double inValue){
	mIsOpenAttribute=false;
	addAttributeToGenerated(mOpenAttributeName,
				inValue);
    }
    /** opens an attribute */
    public void closeAttribute(boolean inValue){
	mIsOpenAttribute=false;
	addAttributeToGenerated(mOpenAttributeName,
				inValue);
    }
    /** opens an attribute */
    public void addEndTag(String inName){
	mIsOpenAttribute=false;	
	closeStartTag();
	mGenerated+="</"+inName+">";
    }
    /** constructor */
    public CMRMLBuilder(){
	System.out.println(" in constructor ");

	mIsOpenAttribute=false;
	mIsOpenStartTag=false;
	clearGenerated();
    } 
    /** return the generated string */
    public String getGenerated(){
	return mGenerated;
    }
    /** return the generated string */
    public void setGenerated(String inGenerated){
	mGenerated=inGenerated;
    }
    /** return the generated string */
    void clearGenerated(){
	mGenerated=new String();
    }

    /** for testing only */
    public static void main(String argv[]){
	CMRMLBuilder lVisitor=new CMRMLBuilder();


	lVisitor.openStartTag("element");
	lVisitor.openAttribute("test1");
	lVisitor.closeAttribute("11");
	lVisitor.openAttribute("test2");
	lVisitor.closeAttribute(22.3);
	lVisitor.openStartTag("element");
	lVisitor.addEndTag("element");
	lVisitor.addEndTag("element");

	System.out.println(lVisitor.getGenerated());
    }
};
