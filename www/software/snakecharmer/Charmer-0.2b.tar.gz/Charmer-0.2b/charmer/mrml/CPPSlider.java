package charmer.mrml;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

import org.xml.sax.AttributeList;
import org.xml.sax.helpers.AttributeListImpl;


class CPPSlider extends CPropertyPanel{
    Label  mCurrentLabel;
    Double mCurrent  ;
    Double mFrom     ;
    Double mTo       ;
    Double mStep     ;
    
    CPPSlider(AttributeList inAttributes){
	mAttributes=new AttributeListImpl(inAttributes);

	setThisName(new String((String)inAttributes.getValue("caption")));
	mCurrent  =new Double((String)inAttributes.getValue(mrml_const.send_value));
	mFrom     =new Double((String)inAttributes.getValue("from"));
	mTo       =new Double((String)inAttributes.getValue("to"));
	mStep     =new Double((String)inAttributes.getValue("step"));
	if(mStep==null){
	    mStep=new Double(1);
	}

	int lEnd=(int)Math.round((mTo.doubleValue()-mFrom.doubleValue())/mStep.doubleValue())+1;
	
	int lPosition=(int)Math.round((mCurrent.doubleValue()-mFrom.doubleValue())/mStep.doubleValue());

	Scrollbar lScrollbar=(new Scrollbar(Scrollbar.HORIZONTAL, lPosition, 1, 0, lEnd));

	Panel lContainerPanel=new Panel(new BorderLayout(2,2)){				
	    public Insets getInsets() {return new Insets(5,5,5,5);}
	};
	java.text.DecimalFormat lDecimalFormat = new java.text.DecimalFormat("#####.#####");
	if(getThisName()!=null){
	    lContainerPanel.add(new Label(getThisName(),Label.CENTER),BorderLayout.NORTH);
	}
	lContainerPanel.add(new Label(lDecimalFormat.format(mFrom.doubleValue()),Label.RIGHT),BorderLayout.WEST);
	lContainerPanel.add(new Label(lDecimalFormat.format(mTo.doubleValue()),Label.LEFT),BorderLayout.EAST);

	Panel lCurrentPanel = new Panel(new BorderLayout(2,2));
	mCurrentLabel = new Label(lDecimalFormat.format(mCurrent),Label.CENTER);
	lCurrentPanel.add(mCurrentLabel,BorderLayout.SOUTH);
	lCurrentPanel.add(lScrollbar,BorderLayout.CENTER);
	lContainerPanel.add(lCurrentPanel,BorderLayout.CENTER);

	lScrollbar.addAdjustmentListener(new AdjustmentListener(){
	    public void adjustmentValueChanged(AdjustmentEvent e){
		mCurrent = new Double(((double)e.getValue()*mStep.doubleValue())+mFrom.doubleValue());
		java.text.DecimalFormat lAdjustmentDecimalFormat = new java.text.DecimalFormat("#####.##");
		mCurrentLabel.setText(lAdjustmentDecimalFormat.format(mCurrent));
		
		
		System.out.println((String)(mAttributes.getValue(mrml_const.send_value)));
		mAttributes.removeAttribute(mrml_const.send_value);
		mAttributes.addAttribute(mrml_const.send_value,"CDATA",mCurrent.toString());
		System.out.println((String)(mAttributes.getValue(mrml_const.send_value)));
		Object lTestValue=mAttributes.getValue(mrml_const.send_value);
		lTestValue=mCurrent.toString();
		System.out.println((String)(mAttributes.getValue(mrml_const.send_value)));
		setChanged();
	    }
	});
	setComponent(lContainerPanel);
    };
}
