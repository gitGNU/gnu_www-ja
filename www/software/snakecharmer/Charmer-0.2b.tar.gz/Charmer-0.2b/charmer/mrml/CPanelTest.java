package charmer.mrml;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

import org.xml.sax.AttributeList;
import org.xml.sax.helpers.AttributeListImpl;









class CPanelTest{
    static public void main(String argv[]){

	CPropertyBuilder lPB=new CPropertyBuilder();

	AttributeListImpl lAttributes=new AttributeListImpl();

	lAttributes.addAttribute("caption","CDATA","Algorithm configuration");
	lAttributes.addAttribute("type","CDATA","subset");

	lPB.addChild(lAttributes);

	lAttributes.addAttribute("value","CDATA","yes");
	lAttributes.addAttribute("caption","CDATA","Use color histogram");
	lAttributes.addAttribute("type","CDATA","set-element");
	
	lPB.addChild(lAttributes);
	lPB.moveUp();

	lAttributes.addAttribute("caption","CDATA","Use color blocks ");
	lPB.addChild(lAttributes);
	lPB.moveUp();

	lAttributes.addAttribute("caption","CDATA","Use Gabor histograms ");
	lPB.addChild(lAttributes);
	lPB.moveUp();

	lAttributes.addAttribute("caption","CDATA","Use Gabor blocks ");
	lPB.addChild(lAttributes);
	lAttributes.addAttribute("caption","CDATA","Use Gabor blocks,child ");
	lPB.addChild(lAttributes);
	lPB.moveUp();
	lAttributes.addAttribute("caption","CDATA","Use Gabor blocks,child 2");
	lPB.addChild(lAttributes);
	lPB.moveUp();
	lPB.moveUp();


	lAttributes.addAttribute("type","CDATA","numeric");
	lAttributes.addAttribute("caption","CDATA","Evaluate % of features");
	lAttributes.addAttribute("current","CDATA","70");
	lAttributes.addAttribute("from","CDATA","20");
	lAttributes.addAttribute("to","CDATA","100");
	lAttributes.addAttribute("step","CDATA","1");

	lPB.addChild(lAttributes);
	lPB.moveUp();

	Frame lFrame=new Frame();
	lFrame.setSize(400,400);
	lFrame.add(lPB.getPanel());
	lFrame.show();
	
    }
}


