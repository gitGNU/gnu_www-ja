// -*- mode: java -*- 
/* 

   Viper, a flexible content based image retrieval system.
   Copyright (C) 1998-1999 CUI, University of Geneva

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.mrml;

import java.net.*;
import java.util.*;
import java.io.*;
import java.lang.String;
import charmer.mrml.*;
import charmer.client.*;
import org.xml.sax.AttributeList;

/** 
    <h1> CXEVCommunication.java </h1>

    an CXMLElementVisitor which is designed to visit
    CXMLElements derived from MRML COMMUNICATION between
    client and server.

    @author Wolfgang M�ller
*/
public class CXEVCommunication implements CXMLElementVisitor{
    /** the structure using the MRML information */
    CMRMLUser mMRMLUser;
    /**
       set the MRML user which is recieving all our information
    */
    void setMRMLUser(CMRMLUser inUser){
	mMRMLUser=inUser;
    };
    /** 
	During the visit we do about what we did during 
	parsing before...
    */
    public boolean startVisit(CXMLElement inElement){

	String        name=inElement.getName();
	AttributeList attrs=inElement.getAttributes();

	//
	//
	System.out.println(name);

	// we do not anything with this, but we want 
	// traversing to be pursued
	if(
	   (0==name.compareTo(mrml_const.algorithm_list))
	   ||(0==name.compareTo(mrml_const.collection_list))
	   ||(0==name.compareTo(mrml_const.query_result_element_list))
	   ){
	    return true;
	}
	if(attrs!=null){	
	    // is this a hack?
	    if(0==name.compareTo(new String(mrml_const.mrml))){
		mMRMLUser.setCurrentSession(attrs.getValue(mrml_const.session_id));
		return true;
	    }
	    //attrs.getValue(mrml_const.session_list_id));
	    if(0==name.compareTo(new String(mrml_const.session_list))){
		mMRMLUser.clearSessionList(new String("0"));
		return true;
	    }
	    // Add element to list of sessions
	    if(0==name.compareTo(new String(mrml_const.session))){
		mMRMLUser.addSessionToList(attrs.getValue(mrml_const.session_id),
					 attrs.getValue(mrml_const.session_name)
					 );
		return false;
	    }
	    // --------------------List of algorithm names
	    if(0==name.compareTo(new String(mrml_const.algorithm_list))){
		mMRMLUser.clearAlgorithmList("0");
		return true;
	    }
	    if(0==name.compareTo(new String(mrml_const.collection_list))){
		// 		System.out.println("______________");
		// 		System.out.println("COLLECTIONLIST");
		mMRMLUser.clearCollectionList("0");
		//		System.out.println("--------------");
		return true;
	    }
	    //------------------------------
	    //an algorithm list
	    if(0==name.compareTo(new String(mrml_const.algorithm))){
// 		System.out.println("_________");
// 		System.out.println("ALGORITHM");
// 		System.out.println(attrs.getValue(mrml_const.algorithm_id));
// 		System.out.println(attrs.getValue(mrml_const.algorithm_name));

		//
		// find the subtree which defines the query-paradigms 
		// accepted by this
		//
		CXMLElement lQueryParadigmList=null;
		CXMLElement lPropertySheet=null;
		for(Enumeration e=inElement.getChildEnumeration();
		    e.hasMoreElements();
		    ){
		    CXMLElement lElement=(CXMLElement)(e.nextElement());
		    if(0==lElement.getName().compareTo(mrml_const.query_paradigm_list)){
			lQueryParadigmList=lElement;
		    }
		    if(0==lElement.getName().compareTo(mrml_const.property_sheet)){
			lPropertySheet=lElement;
		    }
		}
		mMRMLUser.addAlgorithmToList(attrs.getValue(mrml_const.algorithm_id),
					     attrs.getValue(mrml_const.algorithm_name),
					     lQueryParadigmList,
					     lPropertySheet);
		
		return false;
	    }
	    //-------------------------------
	    //a query result
	    if(0==name.compareTo(mrml_const.query_result)){
		mMRMLUser.clearImageDisplay();
		return true;
	    }
	    // ------------------------------
	    // add a collection
	    if(0==name.compareTo(new String(mrml_const.collection))){
		
// 		System.out.println("_________________");
// 		System.out.println("ADDING COLLECTION");
		
		//
		// find the subtree which defines the query-paradigms 
		// accepted by this
		//
		CXMLElement lQueryParadigmList=null;
		for(Enumeration e=inElement.getChildEnumeration();
		    e.hasMoreElements();
		    ){
		    CXMLElement lElement=(CXMLElement)(e.nextElement());
		    if(0==lElement.getName().compareTo(mrml_const.query_paradigm_list)){
			lQueryParadigmList=lElement;
		    }
		}
		
		//
		mMRMLUser.addCollectionToList(attrs.getValue(mrml_const.collection_id),
					      attrs.getValue(mrml_const.collection_name),
					      lQueryParadigmList
					      );
	    }
	    // ------------------------------
	    // an image from the query result
	    if(0== name.compareTo(new String(mrml_const.query_result_element))){
		//		System.out.println("Why don't I execute this?");
		if((attrs.getValue(mrml_const.image_location)!=null) 
		   && (attrs.getValue(mrml_const.calculated_similarity)!=null)){
		    
		    String lImageLocation=new String(attrs.getValue(mrml_const.image_location));

		    String lThumbnailLocation=null;

		    if(attrs.getValue(mrml_const.thumbnail_location)!=null){
			lThumbnailLocation=new String(attrs.getValue(mrml_const.thumbnail_location));
		    }else{
			lThumbnailLocation=lImageLocation;
		    }

		    mMRMLUser.addImageToDisplay(lImageLocation,
						lThumbnailLocation,
						new Double(attrs.getValue(mrml_const.calculated_similarity)));
		    //System.out.println("But I do execute this!");
		}else{
		    //System.out.println("...because some attributes are null!");
		}
		return false;
	    }
	}
	//default: if I do not know it, I do not traverse it...
	return false;
    }
    public void endVisit(CXMLElement inElement){
	// plain nothing
    }
};

