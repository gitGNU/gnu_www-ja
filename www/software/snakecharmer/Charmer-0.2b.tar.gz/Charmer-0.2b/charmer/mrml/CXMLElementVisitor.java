// -*- mode: java -*- 
/* 

   Viper, a flexible content based image retrieval system.
   Copyright (C) 1998-1999 CUI, University of Geneva

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.mrml;

import java.net.*;
import java.util.*;
import java.io.*;
import java.lang.String;
import charmer.mrml.*;
import charmer.client.*;
import org.xml.sax.AttributeList;

/** 
    <h1> CXMLElementVisitor.java </h1>

    An interface for XMLElement visitors

    @author Wolfgang M�ller
*/
public interface CXMLElementVisitor{
    /** 
	visit on the way into the tree
    */
    public boolean startVisit(CXMLElement inElement);
    /**
       visit on the way out of the tree
    */
    public void endVisit(CXMLElement inElement);
};

