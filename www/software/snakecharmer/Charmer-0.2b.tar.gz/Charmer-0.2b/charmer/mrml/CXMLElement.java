// -*- mode: java -*- 
/* 

   Viper, a flexible content based image retrieval system.
   Copyright (C) 1998-1999 CUI, University of Geneva

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.mrml;

import java.net.*;
import java.util.*;
import java.io.*;
import java.lang.String;
import charmer.mrml.*;
import charmer.client.*;
import org.xml.sax.AttributeList;
import org.xml.sax.helpers.AttributeListImpl;

/** 
    <h1> CXMLElement.java </h1>
    This will be an element of a restricted DOM tree.
    What we want is an element with children (i.e. a tree)
    attributes in each node.
    
    The whole thing can be visited. In fact, this is all we
    need.

    Given that I do not find any GPL-compatible DOM parser,
    I program a tiny subset of DOM for our purposes
    
    @author Wolfgang M�ller
*/
public class CXMLElement{
    /**
    /** the name of this element */
    protected String mName;
    /** the children of this element */
    protected Vector mChildren;
    /** the node to which a new child will be added*/
    CXMLElement mCurrentChild;
    /** the father of this */
    CXMLElement mFather;
    /** the attributes contained in this node */
    AttributeListImpl mAttributes;
    /** This is constructed from a name and an attribute 
	list*/
    public CXMLElement(String inName,
		       AttributeList inAttributes){
	mName=inName;
	mAttributes=new AttributeListImpl(inAttributes);
	mCurrentChild=this;
	mFather=null;
	mChildren=new Vector();
    };
    /** This is constructed from a name and an attribute 
	list*/
    public CXMLElement(){
	mName=null;
	mAttributes=null;
	mCurrentChild=this;
	mFather=null;
	mChildren=new Vector();
    };
    /** getting the number of children */
    public int getNumberOfChildren(){
	if(mChildren==null){
	    return 0;
	}
	return mChildren.size();
    };
    /** adding a child*/
    public void addChild(CXMLElement inElement){
	try{
	    inElement.mFather=mCurrentChild;
	    mCurrentChild.mChildren.addElement(inElement);
	    mCurrentChild=inElement;
	}catch(Exception e){
	    //PRINTOUT: System.out.println(e.getClass().getName());
	    //PRINTOUT: e.printStackTrace();
	}
    };
    /** adding a child*/
    public void addAttribute(String inAttribute,
			     String inValue){

	if(mAttributes!=null){
	    mAttributes.addAttribute(inAttribute,
				     "cdata",
				     inValue);
	}
    };
    /** moving one up in the hierarchy*/
    public void moveUp(){
	mCurrentChild=mCurrentChild.mFather;
    }
    /** traverse this */
    public void traverse(CXMLElementVisitor inVisitor){
	//PRINTOUT: System.out.print("[size:");
	//PRINTOUT: System.out.print(mChildren.size());
	//PRINTOUT: System.out.print("]");
	//PRINTOUT: System.out.print("<--childnr traverse:");
	boolean lVisitChildren=inVisitor.startVisit(this);

	//PRINTOUT: System.out.print("<");
	//PRINTOUT: System.out.print(mName);
	//PRINTOUT: System.out.println(">");

	if(lVisitChildren){
	    //if the visitor tells us to proceed
	    //visit all children
	    for (int i=0;i<mChildren.size();i++){
		
		//PRINTOUT: System.out.print("size:");
		//PRINTOUT: System.out.print(mChildren.size());
		//PRINTOUT: System.out.print(" i:");
		//PRINTOUT: System.out.print(i);

		((CXMLElement)mChildren.elementAt(i)).traverse(inVisitor);
	    }
	}

	//PRINTOUT: System.out.print("</");
	//PRINTOUT: System.out.print(mName);
	//PRINTOUT: System.out.println(">");

	//anyway, end the visit
	inVisitor.endVisit(this);
    }
    /** moving one up in the hierarchy*/
    public String getName(){
	return mName;
    }
    /** moving one up in the hierarchy*/
    public AttributeList getAttributes(){
	return mAttributes;
    }
    /** moving one up in the hierarchy*/
    public Enumeration getChildEnumeration(){
	return mChildren.elements();
    }
};

