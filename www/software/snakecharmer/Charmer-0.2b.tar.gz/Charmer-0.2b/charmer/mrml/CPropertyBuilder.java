package charmer.mrml;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

import org.xml.sax.AttributeList;
import org.xml.sax.helpers.AttributeListImpl;

class CPropertyBuilder{
    /** the root of this */
    CPropertyElement mRoot;
    /** the stack which contains the ancestry of the last
	added element */
    Stack mStack;
    /** a factory for property sheet elements */
    CPropertyFactory mPropertyFactory;
    /** constructor */
    public CPropertyBuilder(){
	mRoot=null;
	mStack=new Stack();
	mPropertyFactory=new CPropertyFactory();
    }
    
    /** add something to the tree: a new rightmost child 
	to the element on top of the stack 

	@param inAttributes are the attributes which fully specify the look of this element 
    */
    public void addChild(AttributeList inAttributes){

	AttributeListImpl lAttributes=new AttributeListImpl(inAttributes);

	CPropertyElement lElement=null;
	if(0<mStack.size()){
	    lElement=(CPropertyElement)mStack.peek();
	}

	mStack.push(mPropertyFactory.constructElement(lAttributes));
	
	if(mStack.peek()!=null){
	    if(lElement!=null){
		lElement.addChild((CPropertyElement)mStack.peek());
	    }else{
		mRoot=(CPropertyElement)mStack.peek();
	    }
	}else{
	    mStack.pop();
	}
    }
    /** move up in the hierarchy */
    public void moveUp(){
	if(0<mStack.size()){
	    mStack.pop();
	}
    }
    /** get the panel*/
    public Panel getPanel(){
	return mRoot.getThisPanel();
    };
    /** get the */
    public CPropertyElement getPropertyElement(){
	return mRoot;
    };
}
