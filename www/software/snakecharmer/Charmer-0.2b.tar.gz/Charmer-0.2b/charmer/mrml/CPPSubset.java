package charmer.mrml;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

import org.xml.sax.AttributeList;
import org.xml.sax.helpers.AttributeListImpl;

class CPPSubset extends CPropertyPanel{
    public CPPSubset(AttributeList inAttributes){
	mAttributes=new AttributeListImpl(inAttributes);
	String lCaption=(String)inAttributes.getValue("caption");
	if(lCaption!=null){
	    setComponent(new Label(lCaption));
	}else{
	    setComponent(null);
	}
    }
}

