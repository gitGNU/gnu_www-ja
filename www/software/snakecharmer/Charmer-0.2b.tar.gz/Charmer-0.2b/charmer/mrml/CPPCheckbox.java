package charmer.mrml;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

import org.xml.sax.AttributeList;
import org.xml.sax.helpers.AttributeListImpl;


class CPPCheckbox extends CPropertyPanel{
    CPPCheckbox(AttributeList inAttributes){
	mAttributes=new AttributeListImpl(inAttributes);

	Checkbox lCheckbox=(new Checkbox((String)inAttributes.getValue("caption")));
	
	lCheckbox.addItemListener(new ItemListener(){
	    public void itemStateChanged(ItemEvent e){
		
		if(e.getStateChange()==ItemEvent.SELECTED){
		    mAttributes.removeAttribute(mrml_const.send_value);
		    mAttributes.addAttribute(mrml_const.send_value,"CDATA","yes");
		    showChildren();
		    setChanged();
		}
		if(e.getStateChange()==ItemEvent.DESELECTED){
		    mAttributes.removeAttribute(mrml_const.send_value);
		    mAttributes.addAttribute(mrml_const.send_value,"CDATA","no");
		    hideChildren();
		    setChanged();
		}
	    }
	});
	setComponent(lCheckbox);

	if(inAttributes.getValue(mrml_const.send_value)!=null){
	    if(0==inAttributes.getValue(mrml_const.send_value).compareTo("yes")){
		lCheckbox.setState(true);
		showChildren();
	    }else{
		lCheckbox.setState(false);
		hideChildren();
	    }
	}else{
		lCheckbox.setState(false);
		hideChildren();
	}
	mThisPanel.doLayout();
    }
}
