// -*- mode: java -*- 
/* 

   Viper, a flexible content based image retrieval system.
   Copyright (C) 1998-1999 CUI, University of Geneva

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.mrml;

import java.net.*;
import java.util.*;
import java.io.*;
import java.awt.Panel;
import java.lang.String;
import charmer.mrml.*;
import charmer.client.*;
import org.xml.sax.AttributeList;


/** 
    This is a class which generates an XML subtree from a visit of
    a property sheet.
    @author Wolfgang M�ller
*/
public class CXEVMRMLBuilder implements CXMLElementVisitor{
    /**
    
       a class for building property sheets in a way which 
       corresponds well to 

     */
    CMRMLBuilder mMRMLBuilder;

    protected int lState=0;
    /** 
     */
    public CXEVMRMLBuilder(){
	mMRMLBuilder= new CMRMLBuilder();
    };
    /** 
     */
    public CXEVMRMLBuilder(CMRMLBuilder inBuilder){
	mMRMLBuilder= inBuilder;
    };

    public boolean startVisit(CXMLElement inElement){

	String        lElementName=inElement.getName();

	boolean lReturnValue=true;

	if(0==lElementName.compareTo(mrml_const.property_sheet)){

	    AttributeList lAttributes=inElement.getAttributes();
	    String  lSheetType=lAttributes.getValue(mrml_const.property_sheet_type);
	    String  lSendType=lAttributes.getValue(mrml_const.send_type);

	    if(null==lSheetType){
		lSheetType=new String("none");
	    }
	    
   	    String lValue=lAttributes.getValue(mrml_const.send_value);

	    System.out.println("");
	    System.out.print("lValue: ");
	    System.out.println(lValue);
	    System.out.print("lSheetType: ");
	    System.out.println(lSheetType);

	    if(((null==lValue)
		||(0==lValue.compareTo("false"))
		||(0==lValue.compareTo("no")))
	       &&
	       (0==lSheetType.compareTo("set-element"))){

		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

		lReturnValue=false;
	    }

	    String lIsInverted=(lAttributes.getValue("send-boolean-inverted"));

	    if((null!=lValue) 
	       &&(null!=lIsInverted)){
		if((0==lIsInverted.compareTo("true"))
		   ||(0==lIsInverted.compareTo("yes"))){
		    if((0==lValue.compareTo("true"))
		       ||(0==lValue.compareTo("yes"))){
			lValue=new String("false");
		    }else{
			lValue=new String("true");
		    }
		}
	    }


	    if(null==lValue){
		lValue=new String("");
	    }
	    

	    if(0==lSendType.compareTo("element")){
		System.out.println("element: start tag");
		mMRMLBuilder.openStartTag(lAttributes.getValue(mrml_const.send_name));

	    
	    }

	    if(0==lSendType.compareTo("attribute")){

		mMRMLBuilder.addAttributeToGenerated(lAttributes.getValue(mrml_const.send_name),
						     lValue
						     );
		
		
	    }
	    
	    if(0==lSendType.compareTo("attribute-name")){
		
		mMRMLBuilder.openAttribute(lAttributes.getValue(mrml_const.send_name));

	    
	    }
	    if(0==lSendType.compareTo("attribute-value")){

		mMRMLBuilder.closeAttribute(lValue);

	    }
	    //"normal" i.e. "property sheet" return
	    System.out.println("visit returning:");
	    System.out.println(lReturnValue);
	    return lReturnValue;
	}
	//do not traverse further, because unknown tag
	return false;
    }
    public void endVisit(CXMLElement inElement){
	String        lElementName=inElement.getName();
	AttributeList lAttributes=inElement.getAttributes();
	String  lSheetType=lAttributes.getValue(mrml_const.property_sheet_type);
	String  lSendType=lAttributes.getValue(mrml_const.send_type);
	
	if(0==lSendType.compareTo("element")){

	    mMRMLBuilder.addEndTag(lAttributes.getValue(mrml_const.send_name));

	    
	}

    }

    public String getGenerated(){
	return mMRMLBuilder.getGenerated();
    }
};

