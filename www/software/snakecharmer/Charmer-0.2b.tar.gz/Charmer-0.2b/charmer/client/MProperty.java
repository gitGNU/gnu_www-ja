// -*- mode: java -*- 
/* 

   SnakeCharmer, and MRML complient JAVA interface for CBIRs
   Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;
import java.awt.event.*;
import java.util.*;


abstract class MMeta {
    public abstract String getValue();
} //just for avoiding some type checking

class StringMeta
    extends MMeta
{
    TextField data;
    public String getValue(){
	return data.getText();
    };
}

class GroupMeta
    extends MMeta
{
    Vector subs;

    public String getValue(){
	StringBuffer sb = new StringBuffer("\n");
	for(int i = 0; i < subs.size(); i++) {
	    MProperty mp = (MProperty)subs.elementAt(i);
	    sb.append(mp.getValue()+"\n");
	}
	return sb.toString();
    }
}

class BooleanMeta
    extends MMeta
{
    Vector elems = new Vector();
		
    public String getValue(){
	StringBuffer sb = new StringBuffer();
	for(int i=0; i< elems.size(); i++) {
	    Object a = elems.elementAt(i);						
	    if(a instanceof Choice) 
		sb.append(((Choice)a).getSelectedItem());
	    else if(a instanceof CheckboxGroup) 
		sb.append(((CheckboxGroup)a).getSelectedCheckbox().getLabel());
	    else							 
		sb.append("<moption name=\""+((Checkbox)a).getLabel()+"\" value=\""+((Checkbox)a).getState()+"\"/>");
	}
	return sb.toString();
    }

}

class ScrollbarMeta
    extends MMeta
{
    Double min;
    Double max;
    Double def;
    Double unt;
    Label Current;
    int tmin=0,tmax=100,tdef=0,tu=1,tb=16;		
    Scrollbar s;
    public String getValue(){
	return Current.getText();
    }
    public String toString(){
	java.text.DecimalFormat df = new java.text.DecimalFormat("#####.#####");
	return df.format(min)+" "+df.format(max)+" "+df.format(def)+" "+df.format(unt)+"\n"+
	    df.format(tmin)+" "+df.format(tmax)+" "+df.format(tdef)+" "+df.format(tu)+" "+df.format(tb);
    }
}


public class MProperty
    extends BorderedPanel
{
    public static final int GROUP_T = 0;
    public static final int FIELD_T = 1; //Textfield (numeric or string)
    public static final int RANGE_T = 2; //Slider
    public static final int OPTION_T = 4; //Checkbox
    public static final int MUST_T = 8; //Radiobutton
    public static final int CHOICE_T = 16; //Select list
    public static final int CUSTOM_T = 32; //a class implementing MCustomProperty interface.

    public static final int NUM_TYPES = FIELD_T|RANGE_T;
    public static final int BOOL_TYPES = OPTION_T|MUST_T;


    private Vector Echildren; //Vector of MProperty's that have to be ENabled when this one is.
    private Vector Dchildren; //Vector of MProperty's that have to be DISabled when this one is.
    private String Name;
    private String ID;
    private int Type;
    private MMeta Meta;

    private void createRanged(String Name, Vector g) {
	setLayout(new BorderLayout(2,2));
				//  g[2]=default, {g[3]=unitinc} 
				//  all of which are Double values so we can automate
				//  the process of scale etc.
				//  if g[3] is not there use rounded versions of supplied values
	ScrollbarMeta meta = new ScrollbarMeta();
	try{
	    meta.min = (Double)(g.elementAt(0));
	    meta.max = (Double)(g.elementAt(1));
	    meta.def = (Double)(g.elementAt(2));
	    meta.unt = (Double)(g.elementAt(3));
	}catch(Exception e) {}
				//arbitraryLY we set a 16 page long slider always
	if(meta.unt!=null) {
	    meta.tmin=0;
	    meta.tmax=(int)Math.ceil((meta.max.doubleValue()-meta.min.doubleValue())/meta.unt.doubleValue());
	    meta.tdef=(int)Math.round((meta.def.doubleValue()-meta.min.doubleValue())/meta.unt.doubleValue());
	    meta.tu=1;
	    meta.tb=meta.tmax/16; 
	} else {
	    meta.tmin = (int)Math.round(meta.min.doubleValue());
	    meta.tmax = (int)Math.round(meta.max.doubleValue());
	    meta.tdef = (int)Math.round(meta.def.doubleValue());
	    meta.tu = 1;
	    meta.tb = (meta.tmax-meta.tmin)/16;
	    meta.unt = new Double(1.0);
	}
	meta.s = new Scrollbar(Scrollbar.HORIZONTAL);
	meta.s.setValues(meta.tdef,meta.tb,meta.tmin,meta.tmax);
	meta.s.setUnitIncrement(meta.tu);
	meta.s.addAdjustmentListener(new AdjustmentListener(){
	    public void adjustmentValueChanged(AdjustmentEvent e){
		ScrollbarMeta localMeta = (ScrollbarMeta)Meta; //equals MProperty's Meta field
		int v = e.getValue();
		Double dv = new Double(localMeta.unt.doubleValue()*v+localMeta.min.doubleValue());
		java.text.DecimalFormat df = new java.text.DecimalFormat("#####.#####");
		localMeta.Current.setText(df.format(dv));
	    }
	});
	Panel p = new Panel(new BorderLayout(2,2)){				
	    public Insets getInsets() {return new Insets(5,5,5,5);}
	};
	java.text.DecimalFormat df = new java.text.DecimalFormat("#####.#####");
	p.add(new Label(df.format(meta.min.doubleValue()),Label.RIGHT),BorderLayout.WEST);
	p.add(new Label(df.format(meta.max.doubleValue()),Label.LEFT),BorderLayout.EAST);
	Panel mp = new Panel(new BorderLayout(2,2));
	meta.Current = new Label(df.format(meta.def),Label.CENTER);
	mp.add(meta.Current,BorderLayout.SOUTH);
	mp.add(meta.s,BorderLayout.CENTER);
	p.add(mp,BorderLayout.CENTER);
	add(p,BorderLayout.CENTER);				
	Meta = meta;
    }
		
    private void createOptions(String Name,Vector defaults,boolean radio,boolean choice){
	setLayout(new BorderLayout(2,2));
	Panel p = new Panel(new GridLayout(1,0));
	CheckboxGroup mg = new CheckboxGroup();
	Choice choicemenu = new Choice();
	BooleanMeta meta = new BooleanMeta();				
	Meta = meta;
				
	for(int i=0; i<defaults.size(); i++) {
	    StringTokenizer st = new StringTokenizer((String)defaults.elementAt(i),"@");
	    String lab = st.nextToken();
	    boolean state=false;
	    try{
		String val = st.nextToken();
		if(0==val.compareTo("true") || 0==val.compareTo("1")) 
		    state=true;
	    }catch(Exception e){}
						
	    if(radio && !choice){
		Checkbox c = new Checkbox(lab,state,mg);
		p.add(c);
	    } else if(radio && choice) {
		choicemenu.addItem(lab);
		choicemenu.select(lab);
	    } else {
		Checkbox c = new Checkbox(lab,state);
		p.add(c);
		meta.elems.addElement(c);
	    }
	}
	if(radio && choice) {
	    p.add(choicemenu);
	    meta.elems.addElement(choicemenu);
	}else if(radio && !choice){
	    meta.elems.addElement(mg);
	}
	add(p,BorderLayout.CENTER);
    }
		
    public MProperty(int type,String ID, String Name,Vector defaultValues){
	super(B_ETCH_IN,Name);
	Type=type;
	this.ID=ID;
	this.Name=Name;
	Echildren = new Vector(); //prepare for subsequent adding
	Dchildren = new Vector(); //prepare for subsequent adding
	switch(Type){
	case GROUP_T :
	    //defaultVlaues contains an array of MProperty's
	    //  that are considered as both E and D children
	    setLayout(new BorderLayout(2,0));
	    GroupMeta gm = new GroupMeta();
	    gm.subs = (Vector)defaultValues.clone();
	    int rows = (int)Math.max(1 , Math.floor(Math.sqrt(defaultValues.size())));
	    int cols = defaultValues.size()/rows;
	    Panel p = new Panel(new GridLayout(rows,cols,3,3));
	    //  	    GridBagLayout gbl = new GridBagLayout();
	    //  	    GridBagConstraints gbc = new GridBagConstraints();
	    //  	    gbc.fill = GridBagConstraints.HORIZONTAL;
	    //  	    gbc.gridwidth=GridBagConstraints.REMAINDER;
	    //  	    gbc.weightx=1.0;
	    //  	    gbc.insets = new Insets(2,2,2,2);
	    for(int i = 0; i < defaultValues.size(); i++) {
		MProperty mp = (MProperty)defaultValues.elementAt(i);
		addProperty(mp);
		p.add(mp);
	    }
	    add(p,BorderLayout.CENTER);
	    Meta = gm;
	    break;
	case FIELD_T : 
	    //defaultVlaues contains one string at position 0
	    setLayout(new BorderLayout(2,2));
	    StringMeta t = new StringMeta();						
	    t.data = new TextField(defaultValues!=null?(String)defaultValues.elementAt(0):"");
	    add(t.data,BorderLayout.CENTER);
	    Meta = t;
	    break;
	case RANGE_T :
	    //defaultVlaues contains one string at position 0
	    createRanged(Name, defaultValues);
	    break;
	case OPTION_T:
	    //defaultVlaues contains one string at position 0
	    createOptions(Name, defaultValues,false,false);
	    break;
	case MUST_T:
	    //defaultVlaues contains one string at position 0
	    createOptions(Name, defaultValues,true,false);
	    break;
	case CHOICE_T:
	    //defaultVlaues contains one string at position 0
	    createOptions(Name, defaultValues,true,true);
	    break;
	case CUSTOM_T:
	    /*
	      MCustomProperty mcp = ((MCustomProperty)defaultValues.elementAt(0).getMain());
	      mcp.setPeer(this);
	      Value = mcp.getValue();
	    */
	    break;												
	}
    }


    public void addProperty(MProperty child){
	addEProperty(child);
	addDProperty(child);
    }

public void setEnabled(boolean state){
    if(state) {
	for(int i=0; i<Echildren.size(); i++) {
	    MProperty mp = (MProperty)Echildren.elementAt(i);
	    mp.setEnabled(state);
	}
    }else {
	for(int i=0; i<Echildren.size(); i++) {
	    MProperty mp = (MProperty)Echildren.elementAt(i);
	    mp.setEnabled(state);
	}
    }
}

		
		
public void addEProperty(MProperty echild){
    Echildren.addElement(echild);
}

public void addDProperty(MProperty dchild){
    Dchildren.addElement(dchild);
}

public String getValue(){
    return "<mproperty name=\""+ID+"\" >"+Meta.getValue()+"</mproperty>\n";
}
		
public double numValue()
    throws NumberFormatException
{
    if(Type == NUM_TYPES){
	return Double.valueOf(Meta.getValue()).doubleValue();
    }
    else throw new NumberFormatException("Property is not of numeric value type!");
}

    public String getState(){
	if(Type == BOOL_TYPES) {
	    return Meta.getValue();
	} else throw new IllegalStateException("Property is not of boolean value type!");
    }


public static void main(String s[]){
    Frame f = new Frame("Test properties");
    Vector chooser = new Vector();
    chooser.addElement("Red");
    chooser.addElement("Green");
    chooser.addElement("Blue");
    chooser.addElement("Black@true");
    MProperty bcolor = new MProperty(CHOICE_T,"id1","Choose Background color",chooser);
    MProperty fcolor = new  MProperty(CHOICE_T,"id2","Choose Foreground color",chooser);
    MProperty name = new MProperty(FIELD_T,"id3","Enter your name",null);
    chooser.removeAllElements();
    chooser.addElement(new Double(6));
    chooser.addElement(new Double(100));
    chooser.addElement(new Double(25));
    MProperty age = new MProperty(RANGE_T,"id4","Set your age",chooser);				
    chooser.addElement(new Double(0.1));
    MProperty QI = new MProperty(RANGE_T,"id5","Set your QI",chooser);				
    chooser.removeAllElements();

    Vector c2 = new Vector(2);
    c2.addElement("Enabled@true");
    c2.addElement("Disabled");
    MProperty titit = new MProperty(MUST_T,"idcontr","Anti-aliasing",c2);
    c2.removeAllElements();
    c2.addElement(titit);
    MProperty g2 = new MProperty(GROUP_T,"sgr","Rendering",c2);
    chooser.addElement(g2);
    chooser.addElement(bcolor);
    chooser.addElement(fcolor);
    chooser.addElement(name);
    chooser.addElement(age);
    chooser.addElement(QI);
    final MProperty mainp = new MProperty(GROUP_T,"id0","Your personal data",chooser);

    Panel p = new Panel(new BorderLayout(5,5)){
	public Insets getInsets(){return new Insets(5,5,5,5);}
    };				
    p.add(mainp,BorderLayout.CENTER);
    Button sp = new Button("type properties in console");
    sp.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e){
	    System.out.print(mainp.getValue());
	}
    });
    p.add(sp,BorderLayout.SOUTH);
    f.add(p,BorderLayout.CENTER);
    f.show();
    f.pack();
}

}
