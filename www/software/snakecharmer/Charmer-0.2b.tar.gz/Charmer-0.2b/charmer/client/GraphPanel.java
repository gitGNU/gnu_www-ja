// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;


public class GraphPanel
    extends BorderedPanel
    implements ComponentListener
{

	private void Construct(int W, int H, boolean Oa){
		d.width=W;
		d.height=H;
		zero.x = 1;
		zero.y = H-4;
		setSize(d);
		setBackground(Color.gray);
		data = new Vector[16];
		for(int i=0; i<16;i++) data[i] = new Vector(64,64);
		addComponentListener(this);		
		OrbitAxes=Oa;
	}

    public GraphPanel(int width, int height)
    {
		super(1);
		Construct(width,height,true);
    }
    
    public GraphPanel(int width, int height,int axes_type)
    {		
		super(1);
		Construct(width,height,(axes_type==0)?true:false);
    }

    public Dimension getPreferredSize(){return d;}
    public Dimension getMinimumSize(){return d;}
    public Dimension getMaximumSize(){return d;}
    

	public void setLineTo(boolean lt){
		lineTo = lt;
		repaint();
	}

    public void addPoint(int graph, double x, double y, Object ref){
		if(graph<0 || graph>=16) return; //silent error!
		GPoint p = new GPoint(x,y,ref);
		data[graph].addElement(p);
		recreateDisplay(true);
    }

    public void removeAllPoints(int graph){
		if(graph<0 || graph>=16) return; //silent error!
		data[graph].removeAllElements();
		xmin=ymin=0.0;
		xmax=ymax=1.0;
		xscale = 1.0;
		yscale = 1.0;
		zero.x=0;
		zero.y=0;
		repaint();
		selgp=null;
    }

    public void addPoints(int graph, double x[], double y[], Object ref[]){
		if(graph<0 || graph>=16) return; //silent error!
		int len = x.length;
		if(x.length != y.length) 
			len = Math.min(x.length,y.length);
		for(int i=0; i< len; i++) {
			GPoint p = new GPoint(x[i],y[i],(ref!=null?ref[i]:null));
			data[graph].addElement(p);
		}
		recreateDisplay(true);
    }

    public void recreateDisplay(boolean recalc){
		if(recalc){
			xmax=-1e30;
			ymax=-1e30;
			xmin=1e30;
			ymin=1e30;
			for(int i=0;i<16;i++){
				Enumeration e = data[i].elements();
				while(e.hasMoreElements()) {
					GPoint g = (GPoint)e.nextElement();
					xmax = Math.max(xmax,g.x);
					ymax = Math.max(ymax,g.y);
					xmin = Math.min(xmin,g.x);
					ymin = Math.min(ymin,g.y);
				}
			}
		}
		//reinit e for next part...
		for(int i=0;i<16;i++){
			Enumeration e = data[i].elements();			
			d = getSize(); //if window was resized get new values
			//allow for a small border
			double smax = Math.max((xmax-xmin),(ymax-ymin));
			if(constrained) {
			    xscale=(double)smax/(d.width-15); 
			    yscale = (double)smax/(d.height-15);
			}else {
			    xscale = (double)(xmax-xmin)/(d.width-15); 
			    yscale = (double)(ymax-ymin)/(d.height-15);
			}
			// set zeropoint
			zero.x = (int)Math.round((-xmin)/xscale)+5;
			zero.y = d.height-(int)Math.round((-ymin)/yscale)-7;
			// compute display coordinates of each point
			while(e.hasMoreElements()) {
				GPoint g = (GPoint)e.nextElement();
				g.xp = (int)Math.round((g.x-xmin)/xscale)+5;
				g.yp = d.height-(int)Math.round((g.y-ymin)/yscale)-7;
			}
		}
		invalidate();
    } 
    
    public void paint(Graphics g) {

				// grid color 
		g.setColor(getBackground().brighter());
		if(OrbitAxes) {
			double xstep = (xmax-xmin)/4.0;
			double ystep = (ymax-ymin)/4.0;
			double maxmax = Math.max(Math.abs(xmax),Math.abs(ymax));
			maxmax = 2*Math.max(Math.max(Math.abs(xmin),
										 Math.abs(ymin)),
								maxmax);
			double ow=xstep;
			double oh=ystep;
			if(ystep == 0.0) ystep=xstep;
			if(xstep == 0.0) xstep=ystep;
			if(xstep==ystep && xstep==0.0) xstep=ystep=0.1;
			double step = Math.min(xstep,ystep);
			for(int i=0; ow<=maxmax || oh<=maxmax; i++,ow+=step,oh+=step) {
				int rxs = (int)Math.round(ow/xscale);
				int rys = (int)Math.round(oh/yscale);
				g.drawOval(zero.x-rxs/2,zero.y-rys/2,rxs,rys);
			}
		} else {
			int xs=d.width/10;
			int ys=d.height/10;
			for(int i=1; i< 10; i++) {
				g.drawLine(0,i*ys,d.width,i*ys);
				g.drawLine(i*xs,0,i*xs,d.height);
			}
		}
		// points
		for(int i=0; i<16; i++) {
			Enumeration e = data[i].elements();
			if(e.hasMoreElements()){
				GPoint ogp = (GPoint)e.nextElement();
				ogp.paintPoint(g);
				while(e.hasMoreElements()) {
					GPoint gp = (GPoint)e.nextElement();
					if(lineTo) {
						g.setColor(new Color(((i+3)%4)*32,((i+2)%4)*32,((i+1)%4)*32));
						g.drawLine(ogp.xp,ogp.yp, gp.xp,gp.yp);
					}
					gp.paintPoint(g);
					ogp=gp;
				}
			}
		}
		super.paint(g);
    }

    public void componentMoved(ComponentEvent e){}
    public void componentShown(ComponentEvent e){}
    public void componentHidden(ComponentEvent e){}
    public void componentResized(ComponentEvent e){
		recreateDisplay(false);
    }


    public GPoint selectPoint(Point w, boolean click){
				GPoint gp=null;
				GPoint nsgp = null;
				for(int i=0; i<16; i++) {
						Enumeration e = data[i].elements();
						while(e.hasMoreElements()) {
								gp = (GPoint)e.nextElement();
								if(Math.abs(gp.xp-w.x)<3 && Math.abs(gp.yp-w.y)<3) {
										if(selgp != null) {
												if(selgp.mycol != GPoint.Cobj) {
														selgp.mycol = GPoint.Nobj;
														Graphics g = getGraphics();
														selgp.paintPoint(g);
														g.dispose();
												}
										}
										if(click && gp.mycol == GPoint.Cobj) {
												gp.mycol = GPoint.Nobj;
										} else if(click && gp.mycol != GPoint.Cobj){
												gp.mycol = GPoint.Cobj;
										} else if(gp.mycol != GPoint.Cobj){
												gp.mycol = GPoint.Sobj;
										} else {
												gp.mycol = GPoint.Cobj;		    
										}
										selgp=gp;
										Graphics g = getGraphics();
										gp.paintPoint(g);
										g.dispose();
										return gp;			
								}
						}
				}
				return null;
    }

    Dimension d = new Dimension(256,256);
    public boolean OrbitAxes=true;
    public boolean constrained=true;
    private Point zero=new Point();
    private double xmin=0.0,xmax=1.0,xscale=1.0;
    private double ymin=0.0,ymax=1.0,yscale=1.0;
    public Vector data[];
    GPoint selgp=null;
	boolean lineTo = false;
}

