// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;
import java.awt.event.*;


public class CharmerAbout 
	extends Frame
	implements ItemListener
{
	
    Label maint = new Label("CIRCUS + Viper = Snake Charmer",Label.CENTER);
    Label title = new Label("Experimental framework for image retrieval",Label.CENTER);
    Label subtitle = new Label("Copyright 1999-2000, Z. Pecenovic, W. Muller",Label.CENTER); 
    Label credits = new Label("http://lcavwww.epfl.ch  &  http://www.cui.unige.ch/~vision/",Label.CENTER);
    Label version = new Label("alpha 0.99",Label.CENTER);
    Choice hc;
    TextArea ht;
    String helps[];
    private Image logo;

    public static final int H_PROJECT = 0;
    public static final int H_TOOLBAR = 1;
    public static final int H_CHOICES = 2;
    public static final int H_RESULTS = 3;
    public static final int H_ORBIT = 4;
    public static final int H_QUERY = 5;
    public static final int H_HISTORY = 6;
    public static final int H_BASKET = 7;
    public static final int H_SKETCH = 8;
    public static final int H_COLOR = 9;
    
    
    public CharmerAbout(Image About, MainFrame parent){
	super("About this application...");
	logo = About;
	setLayout(new BorderLayout(5,5));
	Panel p = new BorderedPanel(BorderedPanel.B_ETCH_IN);
	p.setLayout(new GridLayout(0,1,0,-6));
	Font n20 = new Font("Helvetica",Font.BOLD|Font.ITALIC,18);
	maint.setForeground(Color.blue);
	maint.setFont(n20);
	p.add(maint);
	title.setFont(n20);
	p.add(title);
	p.add(subtitle);
	p.add(credits);
	p.add(version);		
	add(p,BorderLayout.NORTH);
	
	helps = new String[11];
	Panel help = new BorderedPanel(BorderedPanel.B_ETCH_IN);
	help.setLayout(new BorderLayout(3,3));
	hc = new Choice();
	hc.add("Charmer project");
	helps[0] = 
			"Charmer is a prototype image retrieval system, developed\n"+
	    "in the Laboratory for Audio-Visual Communications and\n"+
	    "in the Laboratory of Ergonomics of Intelligent Systems\n"+
			"and Design, at EPFL,Switzerland at the Vision Group at\n"+
			"the University of Geneva,Switzerland. It is in part\n"+
			"financed by the Swiss National Research Fund.  Please\n"+
			"visit the below links for more information.";
	hc.add("Toolbar");
	helps[1] = "The buttons are described from left to right\n\n"+
	    "The first button exits the application\n"+
			"The second allows you to establish a\nconnection to the server processing the request.\n"+
	    "A dialog window will open prompting you\nfor a server IPaddress:port.\n"+
	    "Underneath, it will ask you for a name that you\nwill remember for future use of the system.\n"+
	    "If the connection is accepted you will see\nthe button depressed.\n"+
	    "The dice button allows you to query the system\nfor a random set of images.\n"+
			"The binoculars or search button executes the\n current query.\n"+
	    "The following undo button clears the\ncurrent query.\n"+
	    "The following two buttons allow you to\nview the previous and respectively next\n"+
			"query results.\n"+
			"The last button brought you to this help window.\n";
		hc.add("Parameters");
		helps[2] = "The row of controls underneath the\ntoolbar sets the basic query parameters.\n\n"+
			"The Collection choice menu allows you to\nquery several different image collections.\n"+
			"The Method allows you a choice of different\nquery algorithms already implemented.\n"+
			"The available methods depend on the collection\nand server in use.\n"+
			"The Return choice lets you choose the maximum\nnumber of images to return.\n"+
			"The Prec. scrollbar lets you increase the\nnumber of images retrieved if too little\n"+
			"images were returned by a previous query.";
		hc.add("Result List");
		helps[3] = "This tab in the central area shows\nthe results of the queries in the form\n"+
			"of an array of images. The matches are ranked\nleft to right and top to bottom.\n"+
			"Simply clicking on an image adds this image\nto the query as a positive exemple,\n"+
			"double clicking clears the current query\nand runs a new one with the double-clicked\n"+
			"image as unique positive exemple. Right-clicking\nbrings up a popup menu with options:\n"+
			"Exclude adds the image as negative exemple,\nInclude adds it as positive exemple,\n"+
			"Add to basket adds the image to your personal\nbasket of images, View in the normal\n"+
			"version of the application views the image\nin the browser in high-resolution,\n"+
			"Send to Sketch allows editing the image\nin the sketch Tab, Send to Color allows\n"+
			"editing in the color editing Tab.\n";
		hc.add("Result Orbit");
		helps[4] = "The Orbit tab shows the results of a\nquery as a cloud of points in space.\n"+
			"The query is a point at (0,0) (lower-left\ncorner) and the results are displayed at\n"+
			"points measuring their similarity to the\nquery according to several different abstract\n"+
			"notions like color, texture, layout or shape.\nBy moving the mouse pointer over each\n"+
			"point the image is displayed as a ToolTip.\nThe controls on the left allow you to\n"+
			"choose which notion to show on which axis.\n";
		hc.add("Adavanced Query Editor");
		helps[5] = "The Query Editor tab lets you to view\n and review the current query, remove images\n"+
			"from it and modify query settings. It allows you\n to specify keyword queries and,\n"+
			"in the normal version of the application, add\nimages to the query that are not part of\n"+
			"the collection, but are available through a URL\non the internet.";
		hc.add("Basket");
		helps[6] = "The Basket tab is where you can put images\nYou are interested in. This is done by\n"+
			"right-clicking on an image and choosing the\nAdd to basket menu item. From this view you can\n"+
			"open the images in your browser remove them,\nannotate them locally. Since the images in our\n"+
			"databases are copyright protected, the option\nto open the images in you browser for download\n"+
			"has been disabled in this demo.\n";
		hc.addItemListener(this);

		ht = new TextArea(10,50);
		ht.setEditable(false);
		ht.setText(helps[0]);
		help.add(hc,BorderLayout.NORTH);
		help.add(ht,BorderLayout.CENTER);

		add(help,BorderLayout.CENTER);		
		add(new DrawnButton(logo,256,64,0,null,null),BorderLayout.SOUTH);

		pack();
		WindowAdapter wa = new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				setVisible(false);
			}
		};
		addWindowListener(wa);
		Dimension ss = getToolkit().getScreenSize();
		Dimension me = getSize();
		setLocation((ss.width-me.width)/2,(ss.height-me.height)/2);
		setVisible(true);
	}

	public void itemStateChanged(ItemEvent e){
			if(e.getSource()==hc) {
					int i = hc.getSelectedIndex();
					ht.setText(helps[i]);
			}
	}

	public void setHelpState(int What) {
			hc.select(What);
			ht.setText(helps[What]);
	}

}
