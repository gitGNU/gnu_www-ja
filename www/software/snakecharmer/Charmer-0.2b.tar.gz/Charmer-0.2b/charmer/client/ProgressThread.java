// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;

public class ProgressThread
    extends Canvas
{
    public int cw = 0; // screen width of progress bar

    public int m_val; //maximum value of progress.

    public int c_val; // current value of progress.
    int pcw=0;
    public String message; //Informative SHORT string.
		
    public Dimension d = new Dimension(200,18);
		
    public ProgressThread(int max, String message){
				m_val=max;
				c_val=0;
				cw = 0;
				pcw=0;
				this.message = message;				
				setFont(new Font("Dialog",Font.PLAIN,10));
    }
		
    public Dimension getPreferredSize() {
				return d;
    }

    public Color pcol = new Color(128,128,200);

    public void update(Graphics g) {
				if(g != null) {
						Dimension ds = getSize();
						g.clearRect(0,0,ds.width,ds.height);
						paint(g);
						g.dispose();
				}
    }

    public void paint(Graphics g){
				Dimension ds = getSize();
				String rs = " "+message+" ";
				int sw = g.getFontMetrics().stringWidth(rs);
				g.drawString(rs,2,14);
				ds.width = ds.width - sw - 4;
				cw = (int)((ds.width-6)*((float)c_val/m_val));
				g.setColor(pcol);
				g.fillRect(sw+3+pcw,2,cw-pcw,ds.height-5);
    }

    public void setMaxProgress(int nm) {
				m_val = nm;
				c_val = 0;
				cw = 0;
				Graphics g = getGraphics();
				update(g);
				//				repaint(0);
    }
		
    public void updateMaxProgress(int nm) {
				m_val += nm;
				Graphics g = getGraphics();
				update(g);
				//				repaint(0);
    }

    public void setProgress(int nv) {
				pcw = cw;
				c_val = nv;
				Graphics g = getGraphics();
				update(g);
				//				repaint(0);
    }
		
    public void incrementProgress() {
				pcw=cw;
				c_val = c_val+1;				
				Graphics g = getGraphics();
				if(g != null) {
						paint(g);
						g.dispose();
				}
				//				repaint(0);
    }
		
    public void incrementProgress(int v) {
				pcw=cw;
				c_val = c_val+v;				
				Graphics g = getGraphics();
				if(g!=null) {
						paint(g);
						g.dispose();
				}
				//				repaint(0);
    }
		
    public void setMessage(String nmess) {
				message = nmess;
				Graphics g = getGraphics();
				update(g);
    }
		
    public int getProgress() { return c_val; }
		
}
