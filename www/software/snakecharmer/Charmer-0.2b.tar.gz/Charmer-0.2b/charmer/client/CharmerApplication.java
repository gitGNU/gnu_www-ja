// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import  charmer.mrml.*;
//import  charmer.client.VectorListener;

import java.*;
import java.applet.*;
import java.util.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import charmer.*; //For CharmerConnectionMRML

/*
<applet 
codebase = ""
code="charmer.client.Charmer.class" 
width=780 height=600
>
<param 
name="RPort" 
value="23451"
>
<param 
name="server" 
value="pc7143.unige.ch"
>
</applet>
*/

public class CharmerApplication
    extends java.awt.Frame
    implements VectorListener //For updating of result lists etc.							 
{
    final private static boolean debug=false;
    final private static boolean gdebug=false;

    final static Cursor waitC = new Cursor(Cursor.WAIT_CURSOR);
    final static Cursor normC = new Cursor(Cursor.DEFAULT_CURSOR);

    public ActiveVector getResults(){return results;}
    public ActiveVector getQuery(){return query;}
    public boolean connected() {return (ccmrml!=null && ccmrml.isValidAndRunning());}

    private Cpoint cpoints[];
    private int infolines =0;
    private int port = 43210;
    private ActiveVector results;
    private ActiveVector query;
    private ActiveVector basket;
    private TextArea information;
    private CharmerConnectionMRML ccmrml;
    private int qt = 0;
    private int counter=0;
    private int method=2;
    private boolean connected = false;
    private String Collectionlist;
    private String base;

    public MainFrame mf;
    public CharmerAbout Awin;
    public HistoryWindow Hwin;
    public PersonalChoice Pwin;

    private QueryObject testres[];
  

    //--------------------------------
    // execution control and threading routines
    public void stop() {
	String mess[] = new String[2];
	mess[0] = "This will disconnect you from the server.";
	mess[1] = "Are you sure you want to exit?";
	if(InfoDialog.showQuestion(mess,mf)==1) {
	    closeConnection();
	    mf.setVisible(false);
	    super.stop();
	    if(getParent() != null) System.exit(0);
	}			
    }


    //Initialisation
    public void init(){
	try{
	    mf.setPort(Integer.valueOf(getParameter("RPort")).intValue());
	    System.out.print("RPort read as ");
	    System.out.println(port);
	    
	}catch(Exception e) {
	    port = 12789;
	}
	String urls[] = {
	    "http://lcavwww.epfl.ch/daub.jpg",
	    "http://www.microsoft.com/library/homepage/images/bnr_all.gif",
	    "http://www.sun.com/2000-0118/hp01-18.gif",
	    "http://www.corbis.com/content/home/1_17/send_it/pic_1_flag.jpg",
	    "http://cuiwww.unige.ch/~vision/logos/visgroup5.gif",	
	    "http://a388.g.akamaitech.net/7/388/21/aaa7a80f016a2c/cnn.com/images/1999/07/cnn.com.logo.gif",
	    "http://av.com/i/logo_s.gif",
	    "http://web.mit.edu/lavalamp_anim.gif",
	    "http://a1.g.a.yimg.com/7/1/31/000/us.yimg.com/i/main4s3.gif",
	    "http://java.sun.com/images/logos/javalogo52x88.gif"
	};
	testres = new QueryObject[10];
	for(int z=0; z<10;z++) {
	    testres[z] = new QueryObject();
            QueryObject qo = testres[z]; //naming facility
            try {
                qo.location = new URL(urls[z]);
            }catch(MalformedURLException mue){
                qo.location = null;
            }
	    qo.loader=this;
            qo.type = (z%2==1?1:0);
            qo.fname = urls[z].substring(urls[z].lastIndexOf('/')+1,urls[z].length());
            qo.cdist=Math.random();
	    qo.ldist=Math.random();
	    qo.tdist=Math.random();
            qo.dist=qo.cdist*qo.cdist+qo.ldist*qo.ldist+qo.tdist*qo.tdist;
            String qualif = qo.mCalculatedSimilarity.toString();
            qo.title = qo.fname+"    "+qualif;
            qo.description = "unavailable";
            qo.tip = qo.location.toString();
	}
	InfoDialog.check_load_icons(this);

	setLayout(new BorderLayout(5,5));

        results = new ActiveVector(200);
        basket = new ActiveVector(50);
	results.addVectorListener(this);
        query = new ActiveVector(20);
	query.addVectorListener(this);

        if(gdebug){
	    information = new TextArea("Wait while the main window opens up...\n",3,60);
	    information.setEditable(false);
	}

        mf = new MainFrame(this);

        Hwin = new HistoryWindow(this);

        Pwin = new PersonalChoice(mf,basket); // 

        if(gdebug)
	    add(information,BorderLayout.SOUTH);
	add(mf,BorderLayout.CENTER);
        mf.init(); //make the interface
    }

    //--------------------------------
    // Connection open/close
    public synchronized void closeConnection(){
	if(ccmrml != null){
	    ccmrml.close();
	    ccmrml = null;
	    System.gc();
	    connected=false;
	}
    }
    public boolean connect() {
	try {
	    ccmrml = new CharmerConnectionMRML(mf.getUser(),"",mf.getIPAdr(),this);
	    mf.mConnectionMRML=ccmrml;
	    mf.setCollections(ccmrml.getCollections());
        } catch(Exception e) {
            print("unforseen error during connect");
	    return false;
        }
	return connected();
    }
    

    //--------------------------------
    // Debuging output
    public void print(String m){
        if(debug) {
            System.err.println(m);
        } else if(gdebug){
            infolines++;
            if(infolines==250) {
                information.setText("Purged 250 lines...\n"+m+"\n");
                infolines=1;
            } else {
                information.append(m+"\n");             
            }
        }
    }
    
    //--------------------------------
    // query managing
    public void forgetQuery() {
        query.removeAllElements();
    }

    static public void transferRelevanceJudgements(ActiveVector inResult,
						   ActiveVector inQuery,
						   Hashtable      outResult){

	int lOutCounter=0;
	// ok this is what you see,
	for(int i=0;i<inResult.size();i++) {
	    outResult.put(((QueryObject)inResult.elementAt(i)).location,
			  (QueryObject)inResult.elementAt(i));
	}

	
	for(int i=0;i<inQuery.size();i++) {
	    outResult.put(((QueryObject)inQuery.elementAt(i)).location,
			  (QueryObject)inQuery.elementAt(i));
	    }
    }

    public void addToQuery(QueryObject qo){
        if(query.contains(qo)) return;
        QueryObject clone = QueryObject.Clone(qo);
	clone.button=null;
	//clone.title = new String(qu.title);
        query.addElement(clone);
    }

    public void addToBasket(QueryObject qo){
        if(basket.contains(qo)) return;
        QueryObject clone = QueryObject.Clone(qo);
	clone.button=null;
	clone.title = "User's choice";
        basket.addElement(clone);
    }

    public void removeFromQuery(QueryObject qo){
        query.removeElement(qo);
    }



    //--------------------------------
    // Query running
    public void getRandom(int number,
			  String inAlgorithmID,
			  String inCollectionID,
			  CPropertyElement inPropertyElement) {
	if(debug || gdebug || connected()) {
	    results.removeAllElements();
	    QueryObject res[] = (debug||gdebug)?testres:ccmrml.getRandomImages(number,
									       inAlgorithmID,
									       inCollectionID,
									       inPropertyElement
									       );
						
	    for(int i=0; i<res.length;i++){
		//System.out.println("Adding "+res[i]);
		results.addElement(res[i]);
	    }
	    Hwin.addEvent(3,"Random for "+number+" images from collection : \n"+
			  mf.getCollectionName()+" Algorithm : "+mf.getAlgorithmName()+"\n");
	}
    }


    public void doQuery(int inResultSize, 
			String inMethod, 
			String inCollection,
			String inDescription, 
			CPropertyElement inPropertyRoot){ 
	if(connected()){
	    //results.removeAllElements();
	    
	    
	    Hashtable lQuery=new Hashtable();

	    transferRelevanceJudgements(results,query,lQuery);

	    System.out.print("lQUERY SIZE ");
	    System.out.println(lQuery.size());
	    System.out.print("RESULT SIZE ");
	    System.out.println(results.size());

 	    QueryObject qu[] = new QueryObject[lQuery.size()];
	    {
		int i=0;
		for(Enumeration e=lQuery.elements();
		    e.hasMoreElements();){
		    QueryObject lNewElement=(QueryObject)(e.nextElement());
		    qu[i]=lNewElement;
		    i++;
		}
	    }

	    Hwin.addEvent(3,"Query for "+ inResultSize +" images max\n"+// WM " or closer than "+threshold/100.0f+"\n"+
			  "Collection : "+mf.getCollectionName()+" Algorithm : "+mf.getAlgorithmName()+"\n");
	    QueryObject res[] = ccmrml.doSimilaritySearch(qu,
							  inResultSize,
							  inMethod,
							  inCollection,
							  inPropertyRoot,
							  "<mpeg-7-qbe>"+inDescription+"</mpeg-7-qbe>"
							  );

	    results.removeAllElements();
	    for(int i=0; i<res.length; i++) {
 		for(int z=0;z<query.size();z++) {
 		    QueryObject t = (QueryObject)query.elementAt(z);
 		    if(res[i].location.equals(t.location)) {
 			res[i].type=t.type;			
 			System.out.println(t.type);
 			System.out.println("FOUND2");
			
 			break;
 		    }		    
		}
		results.addElement(res[i]);
	    }
	}
    }
		
    public void lexical(String des){
				
    }

    public void doFromString(String res, String name, ActiveVector vec){
				//just redisplay
	mf.recreateDisplay();
	mf.setCursor(normC);
    }
  
    //--------------------------------
    //   PRIVATE
    //--------------------------------

    //--------------------------------
    // Utility routines

    private int parseMessage(String mess, String base, ActiveVector vec){
	try{
	    for(int i=0; i< vec.size(); i++) {
		QueryObject qo = (QueryObject)vec.elementAt(i);
		if(qo != null && qo.image !=null) qo.image.flush();
	    }
	    vec.removeAllElements();
	    //System.gc();
	}catch(Exception e){
	    System.out.println("Exception flushing images...");
	    e.printStackTrace();			
	    vec.removeAllElements();
	}
	StringTokenizer st = new StringTokenizer(mess,"\n",false);
        int tokens = st.countTokens();
	boolean first=true;
	double xc=0.0;
	double yc=0.0;
        for(int i=0;i<tokens;i++) {
            QueryObject t = new QueryObject();
	    String entry=null;
	    try {
		entry = st.nextToken();
	    } catch (Exception fste){
		System.out.println("Line split not working!");
	    }
	    //System.out.println(entry);
	    
            StringTokenizer locst = new StringTokenizer(entry,",",false);
            t.type=0;
            t.fname = locst.nextToken();
	    t.loader = this;
            try {
		//print(base+t.fname);
                t.location = new URL(base+t.fname);
            } catch(Exception e) {
                print("Wrong URL "+base+t.fname+"in parseMessage");
            }
	    String dist=null,cdist=null,ldist=null,tdist=null;
	    try {
		dist = locst.nextToken();
		cdist = locst.nextToken();
		ldist = locst.nextToken();
		tdist = locst.nextToken();						
		//System.err.println(cdist+" "+ldist);
	    } catch (Exception tste){
		System.out.println("Comma split not working for Dists!");
	    }
	    
            t.title = i+"   d= "+dist;
	    try {
		if(first){
		    t.cdist=0.0;
		    t.ldist=0.0;
		    xc=(Double.valueOf(cdist).doubleValue());
		    yc=(Double.valueOf(ldist).doubleValue());
		    first=false;
		}else {
		    t.cdist=(Double.valueOf(cdist).doubleValue())-xc;
		    t.ldist=(Double.valueOf(ldist).doubleValue())-yc;
		}
		t.tdist=(Double.valueOf(tdist).doubleValue());
		t.dist=Double.valueOf(dist).doubleValue();
	    }catch(Exception ne) {
		t.dist=t.cdist=t.ldist=t.tdist=i;
	    }
	    String size = null;
	    size = locst.nextToken();
            t.description = locst.nextToken("\n");
	    t.tip = t.fname+" ("+size+") :\n";
	    try{
		StringTokenizer locst2 = new StringTokenizer(t.description,":",false);
		while(locst2.hasMoreTokens())
		    t.tip += locst2.nextToken()+"\n";
	    }catch(Exception spe) {
	    }
	    
	    if(query.contains(t)) {
		t.type=1;
		t.title += "(Q)";
	    }
	    vec.addElement(t);
	    if(i%10==9) mf.incrementProgress();
        }
	mf.resetMaxProgress(vec.size());
	mf.recreateDisplay();
	mf.setCursor(normC);
        return tokens;
    }


    //--------------------------------
    //Vector update listner methods

    public void elementAdded(ActiveVector source, Object el, int position){
	if(source == results) {
	    QueryObject qo = (QueryObject)el;
	    try{
		mf.getGrapher().addPoint(0,(qo.cdist),(qo.ldist),qo);
	    }catch(Exception e) {
		e.printStackTrace();
	    }
	}
    }


    public void elementRemoved(ActiveVector source, Object el){
	if(source == results) {
	    System.err.println("QueryObjects should never be removed from the results list");
	}		
    }

    public void vectorEmptied(ActiveVector source){
	if(source == results) {
	    try{
		System.err.println("results are being emptied...");
		mf.getGrapher().removeAllPoints(0);
		mf.scrollTop();
		mf.showTab("results");
	    }catch(Exception e) {
		e.printStackTrace();
	    }
	} else {			
	    Enumeration e = results.elements();
	    while(e.hasMoreElements()) {
		QueryObject qo = (QueryObject)e.nextElement();
		qo.type=0;
		if(qo.button != null) 
		    qo.button.setColors(DrawnButton.Ncolor);
	    }
	    mf.recreateDisplay();
	}
    }
    
    public void elementAccessed(ActiveVector source, Object el, int position){
	System.err.println("Update ignored for now.");
    }

    
    //--------------------------------
    // Overloaded getImage functions.
    public Image getImage(URL ul){
	if(mf != null) mf.incrementProgress();				
	return super.getImage(ul);
    }

    public Image getImage(URL ul, String aft){
	if(mf != null) mf.incrementProgress();				
	return super.getImage(ul,aft);
    }

    
}
