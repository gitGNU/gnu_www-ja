// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.net.URL;
import java.awt.Image;
import java.io.Serializable;

/** stores basic data about an image object.
	All data members are public and the only method is used to copy instances.
	@author Zoran Pecenovic
	@version 1.0
*/
public class QueryObject
		extends Object
		implements Cloneable,Serializable
{
		public int type=0;			// 1=relevant, 0=neutral, -1=irrelevant
		public String description;	// The text if it is the text
		public String tip;			// The tip to show in bar
		public String fname;		// The filename (last part of location URL)
		public String title;		// A title of the image (name or other...)
		public URL location;		// Where to find the thing
		public URL mThumbnailLocation;  // Where to find the thing
		public Image image;		// Displayable version if image
		public boolean tag[] = new boolean[6];			// specially marked image
		public DrawnButton button=null;	// The correspondin visual component
		public String reason;		// the reason for similarity
		public double dist=0.0;
		public double cdist=0.0;
		public double ldist=0.0;
		public double tdist=0.0;
                public Double mCalculatedSimilarity=new Double(0.0);
		public java.applet.Applet loader = null;
		public static QueryObject Clone(QueryObject orig){
				QueryObject temp = null;
				try {
						temp = (QueryObject)orig.clone();
				} catch(Exception e) {
						System.err.println("Impossible to clone QueryObject : returning null.");
				}
				return temp;
		}

		public boolean equals(Object o){
				if(o instanceof QueryObject) {
						QueryObject qo = (QueryObject)o;
						return location.equals(qo.location);
				} else return false;
		}
}
  
  
