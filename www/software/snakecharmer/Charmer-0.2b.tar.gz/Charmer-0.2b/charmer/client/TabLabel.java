// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;

public class TabLabel 
		extends Canvas 
{

		//-------------------------------------------------Constants
		public static final int LEFT = 0;
 	 	public static final int CENTER = 1;
		public static final int RIGHT = 2;
 	
 	
		//----------------------------------------Private attributes
		// caption displayed in the tab label
		private String caption;

		// current alignment mode (default value)
		private int alignment = LEFT;
		private boolean selected=false;
		// caption font metrics for display
		private int baseline;
		private int width;
		private int height;

		// tab background color
		private Color bgCol = null;
 	
		public TabLabel(String caption) {
				this.caption = caption;
				setSize(100,23); //arbitrary at first, force size update and paint...
				repaint();	
		}

		public void setSelected(boolean state){
				selected=state;
				if(state==true) bgCol = null;
				if(isShowing()) repaint();
		}

		public boolean isSelected(){
				return selected;
		}


		public void paint(Graphics g) {
				int mw = getSize().width;
				int mh = getSize().height;
				if(bgCol==null) bgCol = getBackground();
				if(!selected) bgCol = bgCol.darker();
				// fill tab
				g.setColor(BorderedPanel.brighten(bgCol));
				g.drawRoundRect(0,0,mw-1,mh+10,10,10);
				g.setColor(bgCol);
				g.fillRoundRect(1,1,mw-1,mh+10,10,10);
				g.setColor(BorderedPanel.darken(bgCol));
				g.drawLine(mw-1,4,mw-1,mh-2);
				if(!selected) {
						g.setColor(BorderedPanel.brighten(bgCol));
						g.drawLine(0,mh-1,mw-1,mh-1);
				}
				// draw caption depending on alignment
				g.setColor(getForeground());
				switch(alignment) {
				case LEFT: {
						g.drawString(caption,5,baseline);
						break;
				}
				case CENTER: {
						g.drawString(caption,(int)(mw/2-width/2),baseline);
						break;
				}
				case RIGHT: {
						g.drawString(caption,mw-width-5,baseline);
						break;
				}
				}
				// draw bounds
				bgCol = null;
		}

		public void setAlignment(int mode) {
				alignment = mode;
				repaint();
		}

		public void setBackground(Color color) 
		{
				bgCol = color;
				repaint();	
		}

		public void setFont(Font font) {
				super.setFont(font);
				setMetrics();
				repaint();
				if(isShowing()) getParent().invalidate();
		}

		private void setMetrics() {
				FontMetrics fontMetrics = getToolkit().getFontMetrics(this.getFont());
				// set caption dimensions
				height = fontMetrics.getHeight();
				width = fontMetrics.stringWidth(caption);

				// set baseline for display
				baseline = fontMetrics.getMaxAscent()+3;

				// resize component
				dim.width=width+20;
				dim.height=height+7;
				setSize(dim);				
		}

		private Dimension dim=new Dimension(100,23); //initial size ...
		public Dimension getPreferredSize(){ return dim;}

		public void setText(String caption) {
				this.caption = caption;
				setMetrics();
				repaint();
	
		}
}
