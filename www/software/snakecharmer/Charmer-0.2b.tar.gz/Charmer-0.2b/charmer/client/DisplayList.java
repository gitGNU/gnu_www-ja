// -*- mode: java -*- 
/* 

   SnakeCharmer, and MRML complient JAVA interface for CBIRs
   Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.net.*;
import java.math.*;
import java.util.*;


public class DisplayList
    extends BorderedPanel
    implements AdjustmentListener
{
    ClickListener clicker;
    TipListener tipper;
    int cols;
    int lines;
    int vlines;
    int w,h;
    Panel images;
    int nbImages  = 0;
    int limit = 20;
    Scrollbar dispmanager;
    ActiveVector data;

    public void adjustmentValueChanged(AdjustmentEvent e){
	recreateDisplay();
    }
	
    public DisplayList(ClickListener clicker,
		       TipListener tipper,
		       ActiveVector data){
	super(BorderedPanel.B_ETCH_IN);
	Construct(clicker,tipper,data,5,120,120);
    }	

    public DisplayList(ClickListener clicker,
		       TipListener tipper,
		       ActiveVector data, 
		       int columns, 
		       int bw,int bh){
	super(BorderedPanel.B_ETCH_IN);
	Construct(clicker,tipper,data,columns,bw,bh);
    }
	
	
    private void Construct(ClickListener clicker,
			   TipListener tipper,//Click/Tip Listener
			   ActiveVector data,
			   int c, // number of columns
			   int bw,int bh) // Button dimensions
    {
	cols = c;
	nbImages = 0;
	w = bw;
	h = bh;
	this.clicker = clicker;
	this.tipper = tipper;
	this.data=data;
	images = new Panel();
	images.setBackground(Color.gray);
	images.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));

	dispmanager = new Scrollbar(Scrollbar.VERTICAL,0,1,0,1);
	dispmanager.addAdjustmentListener(this);
	dispmanager.setUnitIncrement(1);
	dispmanager.setBlockIncrement(1);

	setLayout(new BorderLayout(1,0));
	add(dispmanager,BorderLayout.EAST);
	add(images,BorderLayout.CENTER);
	ComponentAdapter ca = new ComponentAdapter(){
	    public void componentResized(ComponentEvent e){
		updateValues();
		recreateDisplay();
	    }
	};
	addComponentListener(ca);
	if(data !=null) recreateDisplay();
	validate();
    }

    public void setData(ActiveVector v){
	data=v;
	recreateDisplay();
	validate();
    }

    private void updateValues(){
	if(data == null) return;
	int topleft = dispmanager.getValue()*cols;
	int nbImages = data.size();
	int ncols = (int)Math.floor((double)(getSize().width
					     -dispmanager.getSize().width)
				    /(w+2));
	int nvlines = (int)Math.ceil((double)getSize().height/(h+2));
	int nlines = (int)Math.ceil((double)nbImages/cols);
	if(ncols!=cols || nvlines!=vlines || nlines!=lines ) {
	    cols=Math.max(1,ncols);
	    vlines = Math.max(1,nvlines);
	    lines = Math.max(1,nlines);
	}
	topleft /=Math.max(1,cols);
				/*System.out.println(" ncols "+ncols+
				  ", cols  "+cols+
				  "\n nlines "+nlines+
				  ", lines "+lines+
				  "\n nvlines "+nvlines+
				  ", vlines "+vlines);*/
	dispmanager.setValues(topleft,vlines,0,lines+1);
	if(vlines-1>0){
	    dispmanager.setBlockIncrement(vlines-1);
	}else{
	    dispmanager.setBlockIncrement(1);
	}
    }

    public Dimension getMinimumSize(){ 
	Dimension d = new Dimension(w+32,h+8);
	return d;
    }
		
    public Dimension getPreferredSize(){ 
	Dimension d = new Dimension(cols*(w+2)+32,lines*(h+8));
	return d;
    }
    public boolean labelem = true;
		

    public void recreateDisplay(){
	updateValues();
	images.removeAll();
				//images.setLayout(new GridLayout(vlines,cols,1,1));
	int firstim = dispmanager.getValue()*cols;
	for(int i=firstim; i<firstim+cols*vlines; i++){
	    try{
		QueryObject qo = (QueryObject)data.elementAt(i);
		if(qo.button==null) qo.button=new DrawnButton(qo,w,h,((labelem)?2:0));
		qo.button.setBackground(Color.lightGray);
		//hack
		if(!labelem) qo.button.setLabel(null);
		qo.button.setForeground(Color.darkGray);
		qo.button.setBorderType(BorderedPanel.B_ETCH_IN);
		qo.button.addClickListener(clicker);
		qo.button.addTipListener(tipper);
		images.add(qo.button);
	    }catch(ArrayIndexOutOfBoundsException e){
		images.add(new Panel());
	    }
	}
				//invalidate();
	images.validate();
				//images.repaint();
    }

    public void scrollTop(){
	dispmanager.setValue(0);
	recreateDisplay();
    }
}

