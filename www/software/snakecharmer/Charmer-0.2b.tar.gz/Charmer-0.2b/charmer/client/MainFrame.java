// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;
import charmer.*;
import charmer.client.*;
import charmer.mrml.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.*;
import java.net.*;
import java.applet.*;
import java.util.*;

/**

 */
class CIsChanged{
    boolean mIsChanged=false;
    /** set the changed bit */
    public void setChanged(){
	mIsChanged=true;
    };
    /** set the changed bit */
    public void clearChanged(){
	mIsChanged=false;
    };
    /** */
    public boolean isChanged(){
	return mIsChanged;
    }
}

public class MainFrame 
    extends Panel
    implements 
	TipListener, //For displaying tip windows
	ClickListener, //For recieving events from the toolbar and other DrawnButtons
	ActionListener //For standard action events
{

    CIsChanged mIsChangedAlgorithm=new CIsChanged();

    //Default application font (same look on all platforms...)
    public static final Font dfont = new Font("Helvetica",Font.PLAIN,10);


		//--------------------------------
		// General access and modifier methods

    public void recreateDisplay(){
	Pmain.recreateDisplay();
	Qwin.images.recreateDisplay();
	dtg.g.repaint();				

    }

    public ActiveGraph getGrapher() {return dtg.g;}

    public int getPort(){
	System.out.print("PORT REQUESTED IN GETPORT");
	System.out.println(port);
	return port;
    }
    public String getUser(){return user;}
    public String getIPAdr(){return IPadr;}
    public void setPort(int p){port=p;}
    public void setUser(String un){user=un;}
    public void setIPAdr(String ia){IPadr=ia;}

    public void showTab(String name) {tp.showTab(name);}

    public void scrollTop() {Pmain.scrollTop();}

    public void incrementProgress() {if(prg!=null) prg.incrementProgress();}
    public void resetMaxProgress(int nm) {
	prg.setMaxProgress(nm);
	prg.setProgress(0);
    }
		

    //--------------------------------
    // access to algorithm management and properties

    public String getCollectionID(){return (String)ColName2ID.get(getCollectionName());}

    public String getCollectionName(){return Ccollections.getSelectedItem();}

    public String getAlgorithmID(){return (String)AlgoName2ID.get(getAlgorithmName());}

    public String getAlgorithmName(){return Cmethod.getSelectedItem();}

    public void setCollections(Hashtable cols){
	colSpecs = cols;
	AlgoName2ID = new Hashtable();
	ColName2ID = new Hashtable();
	recreateCollectionList();
	oldstyle=false;
    }

    public CPropertyElement createAlgorithmProperties(String inAlgorithmID) {

	if(mConnectionMRML!=null){
	    CXMLElement lPropertySheet=mConnectionMRML.getPropertySheet(inAlgorithmID);
	    if(lPropertySheet!=null){
		CXEVProperty lVisitor=new CXEVProperty();
		
		lPropertySheet.traverse(lVisitor);
		
		System.out.println("success!");

		CXEVMRMLBuilder lMRMLBuilder=new CXEVMRMLBuilder ();

		lVisitor.getPropertyElement().traverse(lMRMLBuilder);

		System.out.print("MRMLBuilder: ");
		System.out.println(lMRMLBuilder.getGenerated());
		
		return lVisitor.getPropertyElement();
	    }
	    System.out.println("failure I");
	}
	System.out.println("failure II");

	CPropertyElement lReturnValue=new CPropertyPanel("configuration failed");
	return lReturnValue;
    }

    public void recreateCollectionList(){
        Ccollections.removeAll();
	Enumeration e = colSpecs.elements();
	while(e.hasMoreElements()){
	    CharmerConnectionMRML.CollectionSpec cs = 
		(CharmerConnectionMRML.CollectionSpec)e.nextElement();
	    Ccollections.add(cs.Name);
	    ColName2ID.put(cs.Name,cs.ID);						
	}
	Ccollections.select(0);
	Ccollections.setEnabled(true);
	recreateAlgorithmList();
    }  

		
    public void recreateAlgorithmList(){
	String colID = getCollectionID();
	Cmethod.removeAll();
	AlgoName2ID.clear();
	CharmerConnectionMRML.CollectionSpec cs = 
	    (CharmerConnectionMRML.CollectionSpec)colSpecs.get(colID);
	for(int i=0; i<cs.Algorithms.size(); i++) {
	    CharmerConnectionMRML.AlgorithmSpec as = 
		(CharmerConnectionMRML.AlgorithmSpec)cs.Algorithms.elementAt(i);
	    Cmethod.add(as.Name);
	    AlgoName2ID.put(as.Name,as.ID);
	}
	Cmethod.addItemListener(new ItemListener(){
		public void itemStateChanged(ItemEvent e){
		    mCurrentPropertyRoot=createAlgorithmProperties(getAlgorithmID());
		    mPropertyWindow.changeControls(mCurrentPropertyRoot.getThisPanel());
		    mIsChangedAlgorithm.setChanged();
		}
	    });


	Cmethod.select(0);
	Cmethod.setEnabled(true);

	mCurrentPropertyRoot=createAlgorithmProperties(((CharmerConnectionMRML.AlgorithmSpec)cs.Algorithms.elementAt(0)).ID);

	mPropertyWindow.changeControls(mCurrentPropertyRoot.getThisPanel());
    }
		

    //--------------------------------
    // action handlers, mouse listeners, tip listeners, etc.

    public void actionPerformed(ActionEvent e) {
	if(e.getSource() instanceof TextField ||
	   e.getSource() instanceof Button)
	    parent.lexical(TFdesc.getText());
	else {
	    MenuItem pm = (MenuItem)e.getSource();
	    DrawnButton db = (DrawnButton)pm.getParent();
	    if(e.getActionCommand().equals("userchoice")) {
		parent.addToBasket(db.referto);
		tp.setCaption("basket", " Your Selection of Images "+parent.Pwin.basketSize()+" ");
		parent.Pwin.images.recreateDisplay();
	    }else if(e.getActionCommand().equals("positive")){
                if(db.referto.type != 1) {
		    System.out.print("marked positive:");
		    System.out.println(db.referto.fname);
                    db.setColors(DrawnButton.Rcolor);
                    db.referto.type = 1;
                    parent.addToQuery(db.referto);
                } else {
		    System.out.print("marked neutral:");
		    System.out.println(db.referto.fname);
                    db.setColors(DrawnButton.Ncolor);
                    db.referto.type = 0;                    
                    parent.removeFromQuery(db.referto);
                }
		Qwin.images.recreateDisplay();
	    } else if(e.getActionCommand().equals("negative")){
                if(db.referto.type != -1) {
                    db.setColors(DrawnButton.Icolor);
                    db.referto.type = -1;
                    parent.addToQuery(db.referto);
                } else {
                    db.setColors(DrawnButton.Ncolor);
                    db.referto.type = 0;
                    parent.removeFromQuery(db.referto);
                }
		Qwin.images.recreateDisplay();
	    } else if(e.getActionCommand().equals("squery")){
		queryAtOnce(db);
	    } else {
		parent.print("NOT YET IMPLEMENTED");
	    }
	}
    }

    public void mouseLClicked(DrawnButton source, Point where, int count){
        if(source == Dbuts[0]) { //Connect
            if(parent.connected()) {
                TFstatus2.setText("Disconnected");
                parent.closeConnection();
		source.setState(false);
            } else {
		String dserver=null;
		// HACK: WOLFGANG M�LLER
		try{
		    setPort(Integer.valueOf(parent.getParameter("RPort")).intValue());
		    System.out.print("RPort read as ");
		    System.out.println(getPort());
		}catch(Exception e) {
		    setPort(12789);
		}

		if((dserver=parent.getParameter("server")) == null) {
		    URL cb = parent.getCodeBase();
		    dserver = cb.getHost();
		}
		if(dserver.equals("")) dserver="localhost";
		condiag = new ConnectDialog(this,
					    dserver,
					    getPort());
                condiag.show();
		if(!condiag.canceled) {
		    if(parent.connect()) {
			//make sure that at the next query an 
			// configure-session
			// signal will be sent
			mIsChangedAlgorithm.setChanged();
			source.setState(true);
		    }
		}
            }
        } else if(source == Dbuts[1]) { //Random
	    int toret = 20;
            try{
		toret = Integer.parseInt(Cnumber.getSelectedItem());
	    }catch(Exception ne) {
		toret=-1;
	    }


	    if(null!=mCurrentPropertyRoot){
		if(mIsChangedAlgorithm.isChanged() 
		   || mCurrentPropertyRoot.isChanged()){
		    mIsChangedAlgorithm.clearChanged(); 
		    mCurrentPropertyRoot.clearChanged();
		    parent.getRandom(toret,getAlgorithmID(),getCollectionID(),mCurrentPropertyRoot);
		}else{
		    parent.getRandom(toret,getAlgorithmID(),getCollectionID(),null);
		}
	    }else{
		parent.getRandom(toret,getAlgorithmID(),getCollectionID(),null);
	    }
	} else if(source == Dbuts[3]) { 
            //Execute
	    if(parent.connected()){
		try{
		    System.out.println("querying");
		    System.out.println("1");
		    TFstatus2.setText("Querying");
		    int toret=20;
		    try{
			System.out.println("2");
			toret = Integer.parseInt(Cnumber.getSelectedItem());
		    } catch (Exception ne) {
			toret=-1;
		    }
		    System.out.println("3");
		    System.out.println("4");
		    //int feedback = Crfmethod.getSelectedIndex();
		    System.out.println("5");
		    //int rank = Crank.getSelectedIndex();
		    System.out.println("6");
		    int thresh = 0; //Sprec.getValue();
		    System.out.println("6");
		    //int levels = Clevels.getSelectedIndex();
		    System.out.println("6");
		    String desc = TFdesc.getText();
		    System.out.println("calling send almost");

		    if(null!=mCurrentPropertyRoot){
			if(mIsChangedAlgorithm.isChanged() 
			   || mCurrentPropertyRoot.isChanged()){
			    mIsChangedAlgorithm.clearChanged();
			    mCurrentPropertyRoot.clearChanged();
			    parent.doQuery(toret,
					   getAlgorithmID(),
					   getCollectionID(),
					   desc,
					   mCurrentPropertyRoot);
			}else{
			    parent.doQuery(toret,
					   getAlgorithmID(),
					   getCollectionID(),
					   desc,
					   null);
			}
		    }else{
			parent.doQuery(toret,
				       getAlgorithmID(),
				       getCollectionID(),
				       desc,
				       null);
		    }

		} catch(Exception ex){ex.printStackTrace();}
		recreateDisplay();
	    }
	} else if(source == Dbuts[4]) { //Forget query
            parent.print("Forgeting everything and deleting query");
            parent.forgetQuery();
        } else if(source == Dbuts[13]) { //Exit
            parent.stop();
        } else if(source == Dbuts[10]) { //Next
	    parent.Hwin.following();
        } else if(source == Dbuts[9]) { //Previous
            parent.Hwin.previous();
        } else if(source==Dabout){
            if(parent.Awin == null)  {
                parent.Awin=new CharmerAbout(logo,this);
                return;
            }
            parent.Awin.pack();
            parent.Awin.setVisible(!parent.Awin.isShowing());
            
        } else { //one of the result images is calling this
            if(count == 2) {
		queryAtOnce(source);
            } else {
                if(source.referto.type != 1) {
                    source.setColors(DrawnButton.Rcolor);
                    source.referto.type = 1;
                    parent.addToQuery(source.referto);
                } else {
                    source.setColors(DrawnButton.Ncolor);
                    source.referto.type = 0;                    
                    parent.removeFromQuery(source.referto);
                }
            }
        }
    }

    public void mouseRClicked(DrawnButton who, Point where, int count){
	PopupMenu pm = new PopupMenu("Operations...");
	pm.setFont(new Font("Dialog",Font.PLAIN,11));

	MenuItem mi = new MenuItem("Exclude");
	mi.setActionCommand("negative");
	pm.add(mi);

	mi = new MenuItem("Include");
	mi.setActionCommand("positive");
	mi.setFont(new Font("Dialog",Font.BOLD,11));
	pm.add(mi);

	mi = new MenuItem("Query this only (2xclick)");
	mi.setActionCommand("squery");
	mi.setFont(new Font("Dialog",Font.ITALIC,11));
	pm.add(mi);

	pm.addSeparator();
	mi = new MenuItem("Add to basket");
	mi.setActionCommand("userchoice");
	pm.add(mi);
	pm.add(new MenuItem("View"));

	who.add(pm);
	pm.show(who,where.x-5,where.y-5);
	pm.addActionListener(this);
    }

    public void mouseMClicked(DrawnButton who, Point where, int count){}
    
    public void displayTip(Component source, Object Tip, Point where){
				//This code has been removed due to bugs with Internet explorer
				//and other focus like problems
				/*if(source==Tip) {
				  if(tipw!=null) tipw.setPoint(where);
				  } else if(tipw == null && Tip != null) {
				  Tipper=source;
				  Point sl = source.getLocationOnScreen();
				  tipw = new TipThread(getFrame(),Tip,source,where);
				  if(Tip instanceof Image) tipw.setDelay(0);
				  tipw.start();
				  } else {
				  if(tipw!=null) {
				  tipw.stop();
				  tipw.close();
				  tipw=null;
				  Tipper=null;
				  }			
				  }*/
        if(Tip instanceof String) TFstatus.setText((String)Tip);
    }



    //gets the frame the interface is using (Appletviewer or NEtscape or whatever...)
    //usually fortip display.
    public Frame getFrame(){
	Component parent = this;
	Frame p = null;
	if(parent instanceof Frame) return (Frame)parent;
	while((parent=parent.getParent()) != null) {
	    if(parent instanceof Frame) p = (Frame)parent;
	}
	return p;
    }

    //--------------------------------
    // Construction and initialization$

    public MainFrame(Charmer mp){
        parent = mp;
        setFont(dfont);
        String descs = 
            "Establish or tear down connection to the server."+
            "Fetch a random set of images."+
            "View/edit current query."+
            "Execute the current query."+
            "Clear current query."+
            "Clear current query."+
            "Show/Hide history window."+
            "Open help page in browser."+
            "Add an url to the display list."+
            "Show the previous results."+
            "Show the next results."+
            "Show the previous 20 images in the display list."+
            "Show the next 20 images in the display list."+
            "Disconnect and close this window."+
            "Start Sketch Extension."+
            "Start Colros Extension.";
    
        Dbuts = new DrawnButton[16];
        icons = new Image[16];
        StringTokenizer st = new StringTokenizer(descs,".",false);
        if(st.countTokens() != 16) {
            parent.print("Not enough tips...");
        }
        try {
            parent.print("Loading icons from :"+mp.getCodeBase());
	    Dbuts[13]=makeToolbarButton("icons/00exit.gif","Close connection and exit CHARMER.",13,false);
	    Dbuts[0]=makeToolbarButton("icons/01connect.gif","Open/Close connection.",0,false);
	    Dbuts[0].setToggle(true);
	    Image disim;
	    try{
		URL u = new URL(parent.getCodeBase(),"icons/01disconnect.gif");
		disim = parent.getImage(u);
	    } catch(Exception e) {
		disim=null;
		e.printStackTrace();
	    }						
	    Dbuts[0].setToggleImage(disim);
						
	    Dbuts[1]=makeToolbarButton("icons/02random.gif","Fetch a random set of images.",1,true);
	    Dbuts[3]=makeToolbarButton("icons/03search.gif","Execute query.",3,true);
	    Dbuts[4]=makeToolbarButton("icons/04undo.gif","Reset or undo query.",4,true);
	    Dbuts[9]=makeToolbarButton("icons/05back.gif","View previous results.",9,false);
	    Dbuts[10]=makeToolbarButton("icons/06forward.gif","View next results.",10,false);
	    Dabout=makeToolbarButton("icons/07help.gif","Open short help window.",7,false);											
        } catch(Exception e) {
            parent.print("Error loading icons");
	    System.err.println("Error loading icons");
        }
        parent.print("done.");
    }


  
    public void init() {

        setBackground(new Color(193,193,207));
	dtg = new TAG(parent,this);
        try {
            logo = parent.getImage(parent.getCodeBase(),"icons/charmer.gif");
        } catch (Exception e) {
            parent.print("Bad url!");
        }

        sub = new BorderedPanel(BorderedPanel.B_IN_LIGHT);
	sub.setLayout(new BorderLayout(1,1));
        sub.add(CreateButtons(),BorderLayout.NORTH);
        sub.add(CreateChoices(),BorderLayout.CENTER);



	Qwin = new QueryWindow(parent,new Panel()); 
	mPropertyWindow = new CPropertyWindow(new Panel()); 
		
	Pmain = new DisplayList(this,this,parent.getResults());
				
	setLayout(new BorderLayout(0,0));
	add(sub,BorderLayout.NORTH);

	tp = new TabbedPanel();
	tp.addTab("results"," Query by Example",Pmain);
	//tp.addTab("graph"," Orbital Results ",dtg);
	tp.addTab("query"," Query Images ",Qwin);
	tp.addTab("options"," Options ",mPropertyWindow);
	tp.addTab("basket"," Your Selection of Images  0 ",parent.Pwin);
	tp.addTab("history"," History ",parent.Hwin);
				//
	tp.showTab("results");

	add(tp,BorderLayout.CENTER);		

	add(createStatus(),BorderLayout.SOUTH);
    }
  
    //--------------------------------
    //  PRIVATE
    //--------------------------------
    //Interface construction code...

    private DrawnButton makeToolbarButton(String imName,String tip,int id,boolean dsize){
				
	try{
	    URL u = new URL(parent.getCodeBase(),imName);
	    icons[id] = parent.getImage(u);
	} catch(Exception e) {
	    icons[id]=null;
	    parent.print("Damn : "+e.getClass().getName());
	}
				//mp.prepareImage(icons[i],this);
	DrawnButton ret = new DrawnButton(icons[id],(dsize?70:40),40,0,null,tip);
	ret.addClickListener(this);
	ret.addTipListener(this);
	return ret;
    }
  
    private Panel CreateTexts() {
        Panel rest = new BorderedPanel(BorderedPanel.B_ETCH_IN);
	rest.setLayout(new FlowLayout());
        lprec = new Label("Recall : ",Label.LEFT);
        rest.add(lprec,BorderLayout.WEST);
        Sprec  = new Scrollbar(Scrollbar.HORIZONTAL,20,5,0,100){
		public Dimension getPreferredSize(){ return new Dimension(175,15);}
	    };
        Sprec.addAdjustmentListener( new AdjustmentListener(){
		public void adjustmentValueChanged(AdjustmentEvent e) {
		    lprec.setText("Recall : "+Sprec.getValue());
		}
	    });
        rest.add(Sprec,BorderLayout.EAST);
        return rest;
    }
  
    private Panel CreateButtons() {
        Panel pbuttons = new BorderedPanel(BorderedPanel.B_OUT_LIGHT);
	pbuttons.setLayout(new BorderLayout(1,3));
	Panel buttons = new Panel(new FlowLayout(FlowLayout.LEFT,10,2));
	buttons.add(Dbuts[13]);
	buttons.add(Dbuts[0]);
	buttons.add(Dbuts[1]);
	buttons.add(Dbuts[3]);
	buttons.add(Dbuts[4]);
	buttons.add(Dbuts[9]);
	buttons.add(Dbuts[10]);

	pbuttons.add(buttons,BorderLayout.WEST);
	pbuttons.add(Dabout,BorderLayout.EAST);
        return pbuttons;
    }
  
    private Panel CreateChoices(){
	Panel p = new BorderedPanel(BorderedPanel.B_OUT_LIGHT);
	p.setLayout(new BorderLayout(1,3));
        Panel choicepanel = new Panel();
        GridBagLayout gbl = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();

        choicepanel.setLayout(gbl);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth = 1;
	gbc.insets = new Insets(1,5,1,5);

        Ccollections = new Choice();
        Ccollections.addItem("----------------");
        Ccollections.select(0);
				//hack to avoid errors...
	Ccollections.addItemListener(new ItemListener(){
		public void itemStateChanged(ItemEvent e) {
		    if(oldstyle) System.out.println("Old style");
		    else{
			mIsChangedAlgorithm.setChanged();
			recreateAlgorithmList();
		    }
		}
	    });
        Cmethod = new Choice();
        Cmethod.addItem("Color/Layout");
        Cmethod.addItem("Shape/Texture");
        //Cmethod.addItem("Classic");
        //Cmethod.addItem("Wavelet*");
				//Cmethod.addItem("Yann's");
				//Cmethod.addItem("Region based");
        Cmethod.select(0);
	Cmethod.setEnabled(false); //no direct manipulation for demo

        Cnumber = new Choice();
        Cnumber.addItem("10");
        Cnumber.addItem("20"); 
        Cnumber.addItem("30");
        Cnumber.addItem("50");
        Cnumber.addItem("100");
        Cnumber.addItem("250");
        Cnumber.select(2);
		
	Label t = new Label("Collection",Label.LEFT);
	gbl.setConstraints(t,gbc);
        choicepanel.add(t);
	gbl.setConstraints(Ccollections,gbc);		
        choicepanel.add(Ccollections);

	t = new Label("Method",Label.LEFT);
	gbl.setConstraints(t,gbc);
        choicepanel.add(t);
	gbl.setConstraints(Cmethod,gbc);
        choicepanel.add(Cmethod);

	t = new Label("Return",Label.LEFT);
	gbl.setConstraints(t,gbc);
        choicepanel.add(t);
	gbl.setConstraints(Cnumber,gbc);
        choicepanel.add(Cnumber);

        Button lb = new Button("XML");
	lb.setEnabled(oldstyle);
        lb.addActionListener(this);
        gbl.setConstraints(lb,gbc);
        choicepanel.add(lb);

        TFdesc = new TextField();   
	TFdesc.setEditable(oldstyle);
        TFdesc.addActionListener(this);
        gbc.weightx=1.0;
        gbl.setConstraints(TFdesc,gbc);
        choicepanel.add(TFdesc);

	p.add(choicepanel,BorderLayout.CENTER);
	p.add(new Canvas(),BorderLayout.NORTH);
	p.add(new Canvas(),BorderLayout.SOUTH);

        return (Panel)p;
    }
	
    private Panel createStatus(){
	GridBagLayout gbl = new GridBagLayout();
	GridBagConstraints gbc = new GridBagConstraints();
	Panel spanel = new Panel(gbl);
        TFstatus = new TextField(50);
        TFstatus.setEditable(false);
				//gbc.insets = new Insets(-1,-1,-1,-1);
	gbc.fill=GridBagConstraints.HORIZONTAL;
				//gbc.gridx = 0;
				//gbc.gridy = 0;
				//gbc.gridwidth = 2;
	gbc.weightx = 1.0;
	gbl.setConstraints(TFstatus,gbc);
	spanel.add(TFstatus);

	gbc.weightx=0.0;
        TFstatus2 = new TextField(20);
        TFstatus2.setEditable(false);
        gbl.setConstraints(TFstatus2,gbc);
	spanel.add(TFstatus2);

	BorderedPanel bp = new BorderedPanel(BorderedPanel.B_IN);
	bp.setLayout(new BorderLayout());				
	prg = new ProgressThread(100,"Progress");
	bp.add(prg,BorderLayout.CENTER);
	gbl.setConstraints(bp,gbc);
	spanel.add(bp);

	return spanel;
    }

    private Panel CreateChoices2(){
        Panel choicepanel = new BorderedPanel(BorderedPanel.B_ETCH_IN);
	choicepanel.setLayout(new GridLayout(3,2));

	CBcolor = new Checkbox("Color",true);	   
	CBlayout = new Checkbox("Layout",true);
	CBtexture = new Checkbox("Texture",true);
	CBshapes = new Checkbox("Shapes");
	CBshapes.setEnabled(false);
        Clevels = new Choice();
        Clevels.addItem("All ");
        for(int i=1; i<7; i++)
            Clevels.addItem("L "+i);
        Clevels.select(0);
				
        Crank = new Choice();
        Crank.addItem("L2  "); 
        Crank.addItem("cos ");
        Crank.addItem("L1  ");
        Crank.addItem("Linf");
        Crank.addItem("Vote");
        Crank.select(0);
    
        Crfmethod = new Choice();
        Crfmethod.addItem("Mean   ");
        Crfmethod.addItem("Weights"); 
        Crfmethod.addItem("Set Op.");
        Crfmethod.addItem("Testing");
        Crfmethod.select(0);
				
	Panel p = new Panel(new GridLayout(1,2));
	p.add(new Label("WLevel"));
	p.add(Clevels);

	choicepanel.add(new Label("Execute query using : "));
	choicepanel.add(p);

	p = new Panel(new GridLayout(1,2));
	p.add(CBcolor);
	p.add(CBlayout);
	choicepanel.add(p);
				
	p = new Panel(new GridLayout(1,2));
	p.add(new Label("Feedback"));
	p.add(Crfmethod);
	choicepanel.add(p);

	p = new Panel(new GridLayout(1,2));
	p.add(CBtexture);
	p.add(CBshapes);
	choicepanel.add(p);

	p = new Panel(new GridLayout(1,2));
	p.add(new Label("Ranking"));
	p.add(Crank);
	choicepanel.add(p);
        return (Panel)choicepanel;
    }

    private void queryAtOnce(DrawnButton source){
	int toret = 20;
	try{
	    toret = Integer.parseInt(Cnumber.getSelectedItem());
	}catch(Exception ne) {
	    toret=-1;
	}
//WM 	int feedback = Crfmethod.getSelectedIndex();
//WM 	int rank = Crank.getSelectedIndex();
//WM 	int thresh = Sprec.getValue();
//WM 	int levels = Clevels.getSelectedIndex();
	String desc = TFdesc.getText();
	parent.forgetQuery();
	source.referto.type=1;
	source.setColors(DrawnButton.Rcolor);
	parent.addToQuery(source.referto);

	
	if(null!=mCurrentPropertyRoot){
	    if(mIsChangedAlgorithm.isChanged() 
	       || mCurrentPropertyRoot.isChanged()){
		mIsChangedAlgorithm.clearChanged();
		mCurrentPropertyRoot.clearChanged();

		parent.doQuery(toret,
			       getAlgorithmID(),
			       getCollectionID(),
			       desc,
			       mCurrentPropertyRoot);
	    }else{
		parent.doQuery(toret,
			       getAlgorithmID(),
			       getCollectionID(),
			       desc,
			       null);
	    }
	}else{
	    parent.doQuery(toret,
			   getAlgorithmID(),
			   getCollectionID(),
			   desc,
			   null);
	}

	Qwin.images.recreateDisplay();
    }

    //Algorithm and properties data...
    private Hashtable colSpecs;
    private Hashtable AlgoName2ID;
    private Hashtable ColName2ID;
    private boolean oldstyle=true;
    private String user="change-here-if-you-like";
    private String IPadr="localhost:4321";
    private int port;

    // The central applet
    public Charmer parent;
    // this is a @#%& HACK by wolfgang m�ller
    public CharmerConnectionMRML mConnectionMRML;


    //The GUI elelments
    private ConnectDialog condiag = null;
    private TabbedPanel tp;
    private Label lprec;
    private TAG dtg=null;
    private DrawnButton Dabout;
    private DrawnButton Dbuts[];
    private Choice Cnumber,Crank,Crfmethod,Cmethod,Clevels,Ccollections,Ccategory;
    private Checkbox CBcolor,CBlayout,CBtexture,CBshapes;
    private TextField TFdesc,TFurl,TFstatus,TFstatus2;
    private ProgressThread prg;
    private Scrollbar Sprec;
    private DisplayList Pmain;
    private CPropertyWindow mPropertyWindow;
    private CPropertyElement mCurrentPropertyRoot;
    private QueryWindow Qwin;
    private Panel Pimage;
    private Panel sub;
    private Panel Pquery;
    public Panel status;

		//image data for buttons and logos etc.
    public Image logo;
    public Image icons[];


}
