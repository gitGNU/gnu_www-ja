// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;

public class TipThread
extends Thread
{

    static final int TIP_DELAY=1250; //MILLISECONDS
    private int td = TIP_DELAY;
		private int dura = TIP_DELAY*4;
    private TipWindow tw=null;
    private Point where;
		private Component source;

    public TipThread(Frame mf, Object tip, Component source, Point where){
				tw = new TipWindow(mf,tip); //Create the display area
				this.source=source;
				this.where=where;
				td = TIP_DELAY;
    }
		
    public void setDelay(int ntd) {td=ntd;}
    public void setDuration(int ntd) {dura=ntd;}
    public void setPoint(Point w) {where=w;}

    public int getDelay() {return td;}
    public int getDuration() {return dura;}
    public Point getPoint() {return where;}
		
    public void run(){
				//Compute location from component and click location
				Rectangle d = tw.getBounds();
				Dimension ds = Toolkit.getDefaultToolkit().getScreenSize();
				Point sl;

				if(source.isVisible()) 
						sl = source.getLocationOnScreen();
				else 
						sl=new Point(ds.width/2,ds.height/2);
				where.translate(sl.x,sl.y+8);
				where.x = Math.max(0,where.x);
				where.y = Math.max(0,where.y);
				if(where.x+d.width>ds.width) where.x = ds.width-d.width-1;
				if(where.y+d.height>ds.height) where.y = ds.height-d.height-1;

				//Wait for td milliseconds
				try {
						sleep(td);
				} catch(Exception e){}
				//show the window
				tw.setLocation(where);
				tw.show();

				//wait for dura milliseconds and
				try {
						sleep(dura);
				} catch(Exception e){}
				
				//finally close the display window
				close();
    }
		
    public void close(){
				tw.setVisible(false);
				tw.dispose();
    }
}
