package charmer.client;
// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

import java.util.*;

//import client.VectorListener;

/**
 * 
 * @author  Zoran Pecenovic
 * @version $Id: $
 */
public class ActiveVector 
{
	Vector data;
	private boolean shouldNotify = false;
	private VectorListener vl = null;

	public ActiveVector(int param1_, int param2_) {
		data = new Vector(param1_, param2_);
	}

	public ActiveVector(int param1_) {
		data = new Vector(param1_);
	}

	public ActiveVector() {
		data = new Vector();
	}

	public void setUpdateNotify(boolean notify) {
		shouldNotify = notify;
	}

	public void addVectorListener(VectorListener vl){
		this.vl = vl;
	}
	/*
	 * --- overwritten methods of class 'java.util.Vector' ---
	 */

	public synchronized Object elementAt(int param1_) {
		Object ret = data.elementAt(param1_);
		if(vl !=null && shouldNotify) vl.elementAccessed(this,ret,param1_);
		return ret;
	}

	public synchronized Object firstElement() {
		try{
			Object ret = data.firstElement();
			if(vl !=null && shouldNotify) vl.elementAccessed(this,ret,0);
			return ret;
		} catch (Exception e) {
			return null;
		}
	}

	public synchronized Object lastElement() {
		Object ret = data.lastElement();
		if(vl !=null && shouldNotify) vl.elementAccessed(this,ret,data.size());
		return ret;
	}

	public synchronized void setElementAt(Object param1_, int param2_) {
		data.setElementAt(param1_,param2_);
		if(vl !=null && shouldNotify) vl.elementAccessed(this,param1_,param2_);
	}

	public synchronized void removeElementAt(int param1_) {
		Object ret = data.elementAt(param1_);		
		data.removeElementAt(param1_);
		if(vl!=null) vl.elementRemoved(this,ret);
	}

	public synchronized void removeElement(Object el) {
		data.removeElement(el);
		if(vl!=null) vl.elementRemoved(this,el);
	}

	public int size() {return data.size();}

	public synchronized void insertElementAt(Object param1_, int param2_) {
		data.insertElementAt(param1_,param2_);
		if(vl!=null) vl.elementAdded(this,param1_,param2_);
	}

	public synchronized void addElement(Object param1_) {
		data.addElement(param1_);
		if(vl!=null) vl.elementAdded(this,param1_,data.size()-1);		
	}

	public synchronized void removeAllElements() {
		data.removeAllElements();
		if(vl!=null) vl.vectorEmptied(this);
	}

	public boolean contains(Object o) {
		return data.contains(o);
	}
	public Enumeration elements() {
		return data.elements();
	}
}
