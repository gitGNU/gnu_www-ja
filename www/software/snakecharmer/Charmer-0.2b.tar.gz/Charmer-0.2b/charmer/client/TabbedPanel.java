// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;


public class TabbedPanel 
		extends Panel 
{

		//----------------------------------------Private attributes
		// tab control associated to the tabbed panel
		private TabbedPanelControl tabControl;

		// tab header containing label acting as buttons for this
		// tabbed panel
		private TabHeader tabHeader;

		// panel containing information associated to tabs
		// tabs are stored in a card layout which allows to
		// easily switch from one to another.
		private CardLayout tabPageLayout;
		private Panel tabPage;

		public TabbedPanel() {
				initialize();
	
		}

		public void addTab(String name, String caption, Panel page) {

				// don't allow new tabs if maximum size has been
				// reached
				if(!tabControl.isFull()) {
						tabPage.add(page,name);
						page.setBackground(getBackground());
						// set the tab caption to the first empty tab
						tabHeader.addTabLabel(name,caption);
				}

		}

		public TabbedPanelControl getControl() {
				return tabControl;
		}
	
		private void initialize() {

				// create graphic subcomponents
				tabPageLayout = new CardLayout();
				tabPage = new Panel(tabPageLayout);
				tabHeader = new TabHeader();

				// create component control and associate it to subcontrols
				tabControl = new TabbedPanelControl(this);
				tabHeader.setControl(tabControl);

				// add subcomponents
				BorderedPanel ip = new BorderedPanel(BorderedPanel.B_CUP);
				ip.setLayout(new BorderLayout(3,3));
				ip.add(tabPage,BorderLayout.CENTER);
				//just for spaing out should use insets instead...
				ip.add(new Canvas(),BorderLayout.WEST);
				ip.add(new Canvas(),BorderLayout.EAST);
				ip.add(new Canvas(),BorderLayout.NORTH);
				ip.add(new Canvas(),BorderLayout.SOUTH);

				Panel tp = new Panel(new BorderLayout(0,0));
				tp.add(tabHeader,BorderLayout.NORTH);
				tp.add(ip,BorderLayout.CENTER);

				setLayout(new BorderLayout(3,5));
				add(tp,BorderLayout.CENTER);
				add(new Canvas(),BorderLayout.WEST);
				add(new Canvas(),BorderLayout.EAST);
				add(new Canvas(),BorderLayout.NORTH);
				add(new Canvas(),BorderLayout.SOUTH);
	
		}

		public void setControl(TabbedPanelControl eventListener) {
				tabControl = eventListener;
		}


		public void showTab(String name) {
				//show the taba ssociated to the name
				tabControl.changeTabControl(name);
				tabHeader.changeSelection();
				tabPageLayout.show(tabPage,name);

		}

		public void setCaption(String name, String caption){
				tabHeader.setCaption(name,caption);
		}

		public int getSelectedIndex(){
				return tabHeader.changeSelection();
		}
}
