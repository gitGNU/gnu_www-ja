// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;

public class GPoint
    extends Object
{

    public static final Color Nobj = Color.blue;
    public static final Color Sobj = Color.red;
    public static final Color Cobj = Color.green;

    public double x; //real coords
    public double y;
    public int xp; //display coords
    public int yp;
    Object data;
    public Color mycol;

    public GPoint(double x, double y, Object data){
				this.x = x;
				this.y = y;
				this.data = data;
				mycol = Nobj;
    }
    public void paintPoint(Graphics g){
				g.setColor(mycol);
				g.fillRect(xp-2,yp-2,5,5);
    }
}
