// -*- mode: java -*- 
/* 

   SnakeCharmer, and MRML complient JAVA interface for CBIRs
   Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.net.*;
import java.applet.Applet;
import java.io.Serializable;
import java.applet.Applet;

/** implements a button that has an image as the label.
* This class can be used in general applications, although 
* its layout is tailored to the Charmer applications.
* 
* It calls two distinct interface listeners:
* @see java.lang.ActionListener
* @see charmer.client.TipListener
* The first one is invoked when the button is clicked
* the second when the tip should be displayed (ie. when mouse enters).
* 
* @author Zoran Pecenovic
* @version 1.1
*/
public class DrawnButton 
    extends BorderedPanel
    implements MouseListener,Serializable, MouseMotionListener, ImageObserver
{
    public boolean direct=false;
    public final static Color Ncolor = new Color( 0xffffff );
    //    public final static Color Ncolor = new Color( (int)214, (int)214, (int)214);
    public final static Color Nshad  = new Color( 0x3f3f3f );
    public final static Color Rcolor = new Color( 0x64f264 );
    public final static Color Rshad  = new Color( 0x327932 );
    public final static Color Icolor = new Color( 0xf26464 );
    public final static Color Ishad  = new Color( 0x793232 );

    public Dimension getMinimumSize(){
        return new Dimension(width,height);
    }

    public Dimension getPreferredSize(){
        return new Dimension(width,height);
    }
    
    /** tells the drawnbutton what to do when cliked on.
        This method should be called by teh object that implements 
        the callback function, that is called when th button is clicked.
        @param l the reference to the object that implements the callback.
    */
    public void addClickListener(ClickListener l) {cl = l;}
    public void removeClickListener() {cl = null;}
    
    /** tells the drawnbutton what to do when the mouse enters or exits its display are.
        This method should be called by the object that implements
        the callback function displayTip, that is called when the mouse enters the 
        drawn button. This is basically used to display a tip (cff Windows toolbars...).
        @param l the reference to the object that implements the callback.
    */
    public void addTipListener(TipListener l) {tl = l;}
    
    /** Constructs a default size button with the data supplied in the QueryObject.
        This constructor uses default size and borders. It gets tooltip information, 
        and the image from the Queryobject passed as asrgument.
        @param mydata A queryObject that contains the image to display and other data.
        @see QueryObject
    */
    public DrawnButton(QueryObject mydata)
    {
        referto=mydata;
        if(referto != null) {
            mydata.button=this;
            if(referto.type==1) setColors(Rcolor);
            else if(referto.type==-1) setColors(Icolor);
            else setColors(Ncolor);
        }
        Construct(mydata.image,100,100,2,mydata.tip,mydata.title);
    }
    /** Same as single argument version but specifies the size of the image.
     */
    public DrawnButton(QueryObject mydata,int bw, int bh)
    {
        referto=mydata;
        if(referto != null) {
            referto.button=this;
            if(referto.type==1) setColors(Rcolor);
            else if(referto.type==-1) setColors(Icolor);
            else setColors(Ncolor);
        }
        Construct(mydata.image,bw,bh,2,mydata.tip,mydata.title);  
    }

    public DrawnButton(QueryObject mydata,int bw, int bh,int border)
    {
        referto=mydata;
        if(referto != null) {
            referto.button=this;
            if(referto.type==1) setColors(Rcolor);
            else if(referto.type==-1) setColors(Icolor);
            else setColors(Ncolor);
        }
        Construct(mydata.image,bw,bh,border,mydata.tip,mydata.title);  
    }

    /** Constructor that avoids using QueryObjects.
        @param im an image that cannot be null and should a value returned by getImage.
        @param w the maximum width.
        @param h the maximum height.
        @param bw the width of the 3D border drawn around the image.
        @param cap text to display under the image (should be short, otherwise it will be cut...)
        @param tip text that will be passed to the TipListener and displayed when mouse enters the button.
    */
    public DrawnButton(Image im, 
                       int w, int h, int bw, 
                       String cap, String tip)  
    {
	baseC=Ncolor;
	setColors(baseC);
        referto = null;
        Construct(im,w,h,bw,tip,cap);   
    }

    /** change the label of a given button.
        @param im The new image to display.
    */
    public void changeLabel(Image im) 
    {
        if(im != null && im != label) {
            label=im;
            calc_dims();
            repaint();
        }
    }

    public void setLabel(String t) {
	tlabel=t;
	repaint();
    }

    //just for smooth image display
    public void update(Graphics g) { 
        paint(g);
    }
    
    private Applet getAppletParent(){       
        Container cp=this.getParent();
        do{
            //System.out.println("Parent is : "+cp);
            if(cp instanceof Applet) break;
            cp = cp.getParent();
        }while(cp != null);
            
        return (Applet)cp;
    }
    
    public void paint(Graphics g)
    {
	Insets is = getInsets();
	Dimension bd = getSize();
	Rectangle R = new Rectangle(is.left,is.top,bd.width-is.left-is.right-1,bd.height-is.top-is.bottom);
        if(state) g.setColor(getBackground().darker().darker());
        else g.setColor(getBackground());
        g.fillRect(0,0,R.width,R.height);
	if(baseC == Ncolor) {
	    baseC = getBackground(); //this will call paint again so return 
	    highC = brighten(baseC);
	    lowC = darken(baseC);
	}
        if(label == null && referto != null) {
            if(referto.image == null) {
                try{
                    referto.image = referto.loader.getImage(referto.mThumbnailLocation);
                } catch(Exception exc) {
                    
                }
            }
            label = referto.image;
        }
        
        //Select Image 
	Image im =label;
				//System.out.println(this+" : "+isToggle+" "+state+" "+pressed+" "+inlabel);
	if(isToggle && inlabel!=null && (state || pressed)) 
	    im = inlabel;
        //Draw 3D rect with the specified width
        g.setColor(highC);
        calc_dims(); // get the dimensions right...
        for(int i=borderWidth;i>=1;i--) {       
            g.drawLine(xoff-i,yoff-i,xoff-i,yoff+imh+i-1);
            g.drawLine(xoff-i,yoff-i,xoff+imw+i-1,yoff-i);
            g.setColor(g.getColor().darker());
        }
        g.setColor(lowC);
        for(int i=borderWidth;i>=1;i--) {       
            g.drawLine(xoff+imw+i-1,yoff+imh+i-1,xoff+imw+i-1,yoff-i-1+borderWidth);
            g.drawLine(xoff+imw+i-1,yoff+imh+i-1,xoff-i,yoff+imh+i-1);
            g.setColor(g.getColor().brighter());
        }
				
        //Draw Caption if present or non empty
        if(tlabel != null && tlabel != "") {
            FontMetrics fm = g.getFontMetrics();
	    g.setColor(getForeground());
            g.drawString(tlabel,
                         xoff,
                         R.height-fm.getDescent()+is.top);
        }   
        if(im != null){
	    if(prepareImage(im,imw,imh,this))								
		g.drawImage(im,xoff,yoff,imw,imh,null);
	}
	super.paint(g);
    }
  
    public boolean imageUpdate(Image img,
			       int infoflags,
			       int x,
			       int y,
			       int width,
			       int height)
    {
	if((infoflags&ALLBITS)==ALLBITS){
	    Graphics g = getGraphics();
	    paint(g);
	    g.dispose();
	    return false;
	}
	return true;
    }

    /** Change the colors of the 3D Border. 
        @param hilight the upper and left color.
        @param shaddow the lower and right color.
    */
    public void setColors(Color col)
    {
        highC=col.brighter().brighter();
        lowC=col.darker().darker();
	baseC = col;
        repaint();
    }

    /** returns the reference to the image of this button.
     */
    public Image getLabel()  { return label; }


    public void mouseMoved(MouseEvent e) {
				//if(tl != null) tl.displayTip(this,this,e.getPoint());
    }

    private boolean isFocusMine(){
        Container a = getParent();
        while(a != null ) {
            if(a instanceof Window){
                Window w = (Window)a;
                if(w.getFocusOwner()!=null) return true;
            }
            a = a.getParent();
        }
        return false;
    }

    public void mouseDragged(MouseEvent e) {
    }
    
    public void mouseEntered(MouseEvent e) {

	if(tl != null) 
	    tl.displayTip(this,Tip,e.getPoint());
    }
    
    public void mouseExited(MouseEvent e) {
        if(tl != null) {
            tl.displayTip(this,null,null);
            tipping=false;
        }
    }
    

    private Point reAdjust(Point e){
        Point ret = new Point(e);
        ret.translate(-xoff,-yoff);
        int w = label.getWidth(null);
        int h = label.getHeight(null);
        ret.setLocation((int)(((float)(ret.x)*w)/imw),(int)(((float)(ret.y)*h)/imh));
        return ret;
    }
    
    public void mouseClicked(MouseEvent e) {
        then = -1;
        Rectangle r = new Rectangle(xoff,yoff,imw,imh);
	if(isToggle) {
	    state = !state;
	    swapColors();
	}
        if(cl != null && r.contains(e.getPoint())) {
            if((e.getModifiers() & MouseEvent.BUTTON1_MASK) != 0) {
                Point where = (label!=null ? reAdjust(e.getPoint()) : e.getPoint());
                cl.mouseLClicked(this,where,e.getClickCount());
            } else if((e.getModifiers() & MouseEvent.BUTTON2_MASK) != 0) {
                cl.mouseMClicked(this,e.getPoint(),e.getClickCount());
            } else if((e.getModifiers() & MouseEvent.BUTTON3_MASK) != 0) {
                cl.mouseRClicked(this,e.getPoint(),e.getClickCount());
            }
        }
	repaint();
    }
    
    public void mousePressed(MouseEvent e) {
        Rectangle r = new Rectangle(xoff,yoff,imw,imh);
        if(r.contains(e.getPoint())) {
	    pressed=true;						
	    swapColors();
	    if(borderWidth==0) setBorderType(B_IN_LIGHT);
	}
    }
		
    public void mouseReleased(MouseEvent e) {
        Rectangle r = new Rectangle(xoff,yoff,imw,imh);
        if(r.contains(e.getPoint())) {
	    pressed=false;
	    swapColors();
	    if(borderWidth==0) setBorderType(B_OUT_LIGHT);
	}
    }
    

    public void setPressedImage(Image im) {inlabel=im;}
    public Image getPressedImage(){return inlabel;}
		
    public void setState(boolean state){
	this.state=state;
	swapColors();
	repaint();
    }
    public boolean getState(){return state;}
    public void setToggle(boolean state){isToggle=state;}
    public void setToggleImage(Image tim){setPressedImage(tim);}
    public boolean isToggle(){return isToggle;}
    public void setClientData(Object o) {clientData=o;}
    public Object getClientData() {return clientData;}
    public String getTip(){return Tip;}
    // Private data and methods
    
    Image label;                // The image to be displayed
    Image inlabel=null;			// and the one for pressed
    int imw,imh;                // The displayed size of image to fit
    int width,height;           // The dimensions of DrawnButton
    int borderWidth;
    int xoff,yoff;              // The coords of pixel 0,0 of image
    Color highC,lowC,baseC;
    String Tip;
    int coordX=-1;              // Coords of last mouse press...
    int coordY=-1;
    ClickListener cl;
    TipListener tl;
    long when;
    long then=0;
    boolean tipping=false;
    boolean pressed=false;
    boolean isToggle=false;
    boolean state=false;
    public String tlabel;
    public QueryObject referto; // Inited by shorter contructor
    private Object clientData=null;
    private int max(int a, int b) { return Math.max(a,b); }

    private void Construct(Image im, 
                           int w, int h, int bw,
                           String tip, String cap)
    {
        label=im;
        width = w;
        height = h;
        borderWidth = bw;
	if(bw==0) setBorderType(B_OUT_LIGHT);
        Tip = tip;
        tlabel = cap;
        setSize(w,h);
        calc_dims();
        //setBackground(new Color(214,214,214));
        addMouseListener(this);
        addMouseMotionListener(this);
    }

    public void changeSize(Dimension s){
	int m = Math.min(s.width,s.height);
	width=m-20;
	height=m-20;
	setSize(width,height);
        calc_dims();
	repaint();
    }

    private void swapColors(){
        Color tc = highC;
        highC = lowC;
        lowC = tc;
	Graphics g = getGraphics();
	if(g!=null) {
	    paint(g);
	    g.dispose();
	}
    }

    private void calc_dims()
    {
	Insets is = getInsets();
	Dimension bd = getSize();
	Rectangle R = new Rectangle(is.left,is.top,bd.width-is.left-is.right-1,bd.height-is.top-is.bottom);
				//width=R.width;
				//height=R.height;
        double t;
        if(label != null) {
            imw=label.getWidth(null);
            imh=label.getHeight(null);
        } else {
	    imh=imw=-1;
	}
        int red =0;
        if(tlabel != null && !tlabel.equals("")) red=20;
        if(imh>0 && imw>0) {
            if(imw>imh) {
                t=(double)(width-2*borderWidth-red)/(double)imw;
                imh = (int)(t*imh);
                imw=width-2*borderWidth-red;
            } else {
                t=(double)(height-2*borderWidth-red)/(double)imh;
                imw = (int)(t*imw);
                imh=height-2*borderWidth-red;
            }
        } else {
            imh=height-2*borderWidth;
            imw=width-2*borderWidth;
	}
				
        xoff=(R.width-imw)/2-borderWidth+is.left;
        yoff=(R.height-red-imh)/2-borderWidth+is.top;
        if(tlabel != null && !tlabel.equals("")) yoff+=4;
    }


}

