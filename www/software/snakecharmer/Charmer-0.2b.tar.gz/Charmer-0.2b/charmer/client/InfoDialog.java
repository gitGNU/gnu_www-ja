// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

package charmer.client;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.applet.Applet;
import java.net.URL;
import java.io.*;

/**
 * 
 * @author  Zoran Pecenovic
 * @version $Id: $
 */
public class InfoDialog extends Dialog
	implements ActionListener,
			   WindowListener
{
	static Image WarningImage,InfoImage,ErrorImage,QuestionImage;
	Button YES_OK,NO,CANCEL;
	int buttonClicked; //0 for NO 1 for YES_OK -1 for CANCEL
	String message[];
	
	public static void check_load_icons(Applet loader){
		try {

			//JarImageLoader loader=new JarImageLoader();
			URL pre = loader.getCodeBase();
			WarningImage = loader.getImage(new URL(pre,"icons/Warning.gif"));
			InfoImage = loader.getImage(new URL(pre,"icons/info.gif"));
			ErrorImage = loader.getImage(new URL(pre,"icons/Error.gif"));
			QuestionImage = loader.getImage(new URL(pre,"icons/Question.gif"));
		} catch(Exception e) {}
	}

	static private Frame getFrame(Component parent){
		if(parent instanceof Frame) return (Frame)parent;
		Frame p = null;
		while((parent=parent.getParent()) != null) {
			if(parent instanceof Frame) p = (Frame)parent;
		}
		return p;
	}

	public static int showWarnning(String message[], Component parent){
		int ret;
		Frame pf = getFrame(parent);
		InfoDialog id = new InfoDialog(pf,true,message,0);		
		//id.pack();
		Point ploc = pf.getLocationOnScreen();
		Dimension dim = pf.getSize();
		Dimension mdim = id.getSize();
		id.setLocation(ploc.x+(dim.width-mdim.width)/2,
					   ploc.y+(dim.height-mdim.height)/2);
		id.show();
		ret = id.buttonClicked;
		return ret;
	}

	public static int showInfo(String message[], Component parent){
		int ret;
		Frame pf = getFrame(parent);
		InfoDialog id = new InfoDialog(pf,true,message,1);
		//id.pack();
		Point ploc = pf.getLocationOnScreen();
		Dimension dim = pf.getSize();
		Dimension mdim = id.getSize();
		id.setLocation(ploc.x+(dim.width-mdim.width)/2,
					   ploc.y+(dim.height-mdim.height)/2);
		id.show();
		ret = id.buttonClicked;
		return ret;
	}

	public static int showError(String message[], Component parent){
		int ret;
		Frame pf = getFrame(parent);
		InfoDialog id = new InfoDialog(pf,true,message,2);
		//id.pack();
		Point ploc = pf.getLocationOnScreen();
		Dimension dim = pf.getSize();
		Dimension mdim = id.getSize();
		id.setLocation(ploc.x+(dim.width-mdim.width)/2,
					   ploc.y+(dim.height-mdim.height)/2);
		id.show();
		ret = id.buttonClicked;
		return ret;
	}

	public static int showQuestion(String message[], Component parent){
		int ret;
		Frame pf = getFrame(parent);
		InfoDialog id = new InfoDialog(pf,true,message,3);
		Point ploc = pf.getLocationOnScreen();
		Dimension dim = pf.getSize();
		Dimension mdim = id.getSize();
		id.setLocation(ploc.x+(dim.width-mdim.width)/2,
					   ploc.y+(dim.height-mdim.height)/2);
		id.show();
		ret = id.buttonClicked;
		return ret;
	}

	/*public Insets getInsets(){
		return new Insets(5,5,5,5);
		}*/
	
	public InfoDialog(Frame parent, 
					  boolean isModal,
					  String mess[],
					  int type) {
		super(parent, "Your attention please...", isModal);
		setLayout(new BorderLayout());
		message=mess;
		YES_OK = new Button("OK");
		YES_OK.addActionListener(this);
		NO = new Button("NO");
		NO.addActionListener(this);
		CANCEL = new Button("CANCEL");
		CANCEL.addActionListener(this);

		Component b1=null,b2=null,b3=null;
		DrawnButton db=null;
		switch(type) {
		case 0: // Warnning
			db = new DrawnButton(WarningImage,42,42,0,null,null);
			b1 = new Panel();  b2 = YES_OK;	b3 = new Panel();
			break;
		case 1: // Info
			db = new DrawnButton(InfoImage,42,42,0,null,null);
			b1 = new Panel();  b2 = YES_OK;	b3 = new Panel();
			break;
		case 2: // Error
			db = new DrawnButton(ErrorImage,42,42,0,null,null);
			b1 = new Panel();  b2 = YES_OK;	b3 = new Panel();
			break;
		case 3: // Question
			b1 = YES_OK;   b2 = NO;   b3 = CANCEL;			
			db = new DrawnButton(QuestionImage,42,42,0,null,null);
			break;
		}
		Panel allp = new Panel(new BorderLayout());

		BorderedPanel pt = new BorderedPanel(BorderedPanel.B_ETCH_IN);
		pt.setLayout(new GridLayout(0,1)); // text
		for(int i=0;i<mess.length;i++)
			pt.add(new Label(mess[i],Label.CENTER));		

		GridBagLayout gbl = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.insets = new Insets(10,10,10,10);
		Panel p = new Panel(gbl); // text and icon
		gbl.setConstraints(db,gbc);
		gbc.weightx=1.0;
		gbc.weighty=1.0;
		gbl.setConstraints(pt,gbc);
		p.add(db);
		p.add(pt);

		Panel p2 = new Panel(new GridLayout(1,3,10,0)); // Buttons
		p2.add(b1);
		p2.add(b2);
		p2.add(b3);
		allp.add(p2,BorderLayout.SOUTH);
		allp.add(p,BorderLayout.CENTER);
		add(allp,BorderLayout.CENTER);
		add(new Panel(),BorderLayout.WEST);
		add(new Panel(),BorderLayout.EAST);
		add(new Panel(),BorderLayout.SOUTH);
		setSize(42+200,Math.max(mess.length*15,42)+52);
		pack();
	}

	/*
	 * --- implemented methods of class 'java.awt.event.ActionListener' ---
	 */

	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == YES_OK) {
			buttonClicked = 1;
		} else if(e.getSource() == NO) {
			buttonClicked = 0;
		} else if(e.getSource() == CANCEL) {
			buttonClicked = -1;
		} else {
			System.err.println("Invlaid Action in InfoDialog!");
		}
		this.dispose();
	}

	/*
	 * --- implemented methods of class 'java.awt.event.WindowListener' ---
	 */

	public void windowClosed(WindowEvent we) {
		buttonClicked=0;
		notify();
	}


	public void windowOpened(WindowEvent we) {}
	public void windowClosing(WindowEvent we) {}
	public void windowIconified(WindowEvent we) {}
	public void windowDeiconified(WindowEvent param1_) {}
	public void windowActivated(WindowEvent param1_) {}
	public void windowDeactivated(WindowEvent param1_) {}
}
