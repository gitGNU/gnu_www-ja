// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;
import java.awt.event.*;
import java.net.*;

public class ConnectDialog 
	extends Dialog
	implements ActionListener
{

	TextField serverAddress;
	TextField userName;
	Button connect;
	Button cancel;
	MainFrame parent;
		boolean canceled=true;

    public ConnectDialog(MainFrame parent,String dserv, int port){
	super(parent.getFrame(),"Connect to which server?",true);
	    
	Integer lPort=new Integer(port);

	this.parent = parent;
	setLayout(new BorderLayout(1,1));
		
	Panel cent = new Panel(new GridLayout(2,2));
		
	System.out.print("The current port number is: ");
	System.out.println(port);
	
	serverAddress = new TextField(dserv+":"+lPort.toString(),20);
	userName = new TextField(((parent.getUser()!=null)?parent.getUser():""));
	userName.requestFocus();
	connect = new Button("Try Connection");
	cancel = new Button("Cancel");
		
	serverAddress.addActionListener(this);
	userName.addActionListener(this);
	connect.addActionListener(this);
	cancel.addActionListener(this);
		
	cent.add(new Label("IPaddress:port "));
	cent.add(serverAddress);
	cent.add(new Label("Username "));
	cent.add(userName);
	Panel toto = new Panel(new GridLayout(1,2));
	toto.add(connect);
	toto.add(cancel);
	add(cent,BorderLayout.CENTER);
	add(toto,BorderLayout.SOUTH);
	pack();
	Point ploc = parent.getLocationOnScreen();
	ploc.translate(50,50);
	setLocation(ploc);
    }
		
	public void actionPerformed(ActionEvent e){
			if(e.getSource() == cancel) {
					setVisible(false);
					canceled = true;
			} else {
					if(userName.getText().equals("")) return;
					parent.setIPAdr(serverAddress.getText());
					parent.setUser(userName.getText());
					setVisible(false);
					canceled=false;
			}
	}
		
}
