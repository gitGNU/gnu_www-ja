// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;
import charmer.client SortMethod;


public class QSort 
{

    private static Object[] sort(Object a[], int lo0, int hi0, SortMethod sm)
    {
	int lo = lo0;
	int hi = hi0;
	Object mid;
      
	if ( hi0 > lo0){
	    // Arbitrarily establishing partition
	    // element as the midpoint of the array.
	    mid = a[ ( lo0 + hi0 ) / 2 ];
	    
	    // loop through the array until indices cross	    
	    while( lo <= hi ) {

		// find the first element that is greater
		// than or equal to the partition element starting from the left Index.		
		while( ( lo < hi0 ) && sm.lessThan(a[lo],mid)) ++lo;
		
		// find an element that is smaller than or equal to
		// the partition element starting from the right Index.		
		while( ( hi > lo0 ) && sm.lessThan(mid,a[hi])) --hi;
		
		// if the indexes have not crossed, swap		
		if( lo <= hi ) {
		    a=swap(a, lo, hi);
		    ++lo;
		    --hi;
		}
	    }

	    // If the right index has not reached the left side of array
	    // must now sort the left partition.          
	    if( lo0 < hi ) a=sort( a, lo0, hi, sm );
	    
	    // If the left index has not reached the right side of array
	    // must now sort the right partition.	    
	    if( lo < hi0 ) a=sort( a, lo, hi0, sm );
	}
	return (a);
    }

    private static Object[] swap(Object a[], int i, int j)
    {
	Object T;
	T = a[i]; 
	a[i] = a[j];
	a[j] = T;
	return (a);	
    }

    private static double[] sort(double a[], int lo0, int hi0, boolean ascending)
    {
	int lo = lo0;
	int hi = hi0;
	double mid;
      
	if ( hi0 > lo0){
	    // Arbitrarily establishing partition
	    // element as the midpoint of the array.
	    mid = a[ ( lo0 + hi0 ) / 2 ];
	    
	    // loop through the array until indices cross	    
	    while( lo <= hi ) {

		// find the first element that is greater
		// than or equal to the partition element starting from the left Index.		
		while( ( lo < hi0 ) && (ascending?(a[lo]<mid):((a[lo]>mid)))) ++lo;
		
		// find an element that is smaller than or equal to
		// the partition element starting from the right Index.		
		while( ( hi > lo0 ) && (ascending?(a[lo]>mid):((a[lo]<mid)))) --hi;
		
		// if the indexes have not crossed, swap		
		if( lo <= hi ) {
		    a=swap(a, lo, hi);
		    ++lo;
		    --hi;
		}
	    }

	    // If the right index has not reached the left side of array
	    // must now sort the left partition.          
	    if( lo0 < hi ) a=sort( a, lo0, hi, ascending);
	    
	    // If the left index has not reached the right side of array
	    // must now sort the right partition.	    
	    if( lo < hi0 ) a=sort( a, lo, hi0, ascending);	    
	}
	return (a);
    }

    private static double[] swap(double a[], int i, int j)
    {
				double T = a[i]; 
				a[i] = a[j];
				a[j] = T;
				return (a);	
    }
		
		public static java.util.Vector sort(java.util.Vector v, SortMethod sm){
				//By far not the best solution to this problem, but we will
				//manage to survive until SUN decides to include a sort method
				//on arrays or Vectors
				Object t[] = new Object[v.size()];
				v.copyInto(t);
				Object s[] = sort(t,0,t.length-1,sm);
				java.util.Vector ret = new java.util.Vector(s.length);
				for(int i=0; i<s.length; i++) 
						ret.addElement(s[i]);
				return ret;				
		}

    public static Object[] sort(Object a[], SortMethod sm)
    {
				return(sort(a, 0, a.length - 1, sm));
				
    }
		
    public static double[] sort(double a[], boolean ascending)
    {
				return(sort(a, 0, a.length - 1, ascending));
				
    }
}

