// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.applet.AppletContext;

public class PersonalChoice
		extends Panel
		implements ActionListener
{
		DisplayList images;
		AppletContext displayer;
		GridBagLayout gbl;
		GridBagConstraints gbc;
		Panel p;
		Button Bdeselect,Bdisplay,Bremove,Bclose;
		private ActiveVector data;

		public int basketSize(){
				return data.size();
		}
		
		public PersonalChoice(MainFrame disp, ActiveVector data){
				this.data=data;
				images = new DisplayList(disp,disp,data);
				displayer = disp.parent.getAppletContext();
				setLayout(new BorderLayout(5,5));
				gbl = new GridBagLayout();
				gbc = new GridBagConstraints();
				gbc.gridwidth = 1;
				gbc.gridheight = 1;
				BorderedPanel c2 = new BorderedPanel(BorderedPanel.B_ETCH_IN);
				c2.setLayout(new BorderLayout(5,5));
				c2.add(new Canvas(),BorderLayout.NORTH);
				c2.add(new Canvas(),BorderLayout.SOUTH);
				c2.add(new Canvas(),BorderLayout.EAST);
				c2.add(new Canvas(),BorderLayout.WEST);
				Panel controls = new Panel(new GridLayout(1,0,5,5));
				Bdisplay = new Button("Open in browser");
				Bdisplay.addActionListener(this);
				Bdeselect = new Button("Deselect images");
				Bdeselect.addActionListener(this);
				Bremove = new Button("Remove images");
				Bremove.addActionListener(this);
				Bclose =  new Button("Close window");
				Bclose.addActionListener(this);
				controls.add(new Label("Functionality not available!"));
				controls.add(Bdisplay);
				controls.add(Bdeselect);
				controls.add(Bremove);
				controls.add(new Panel());
				controls.add(Bclose);

				c2.add(controls,BorderLayout.CENTER);
				add(c2,BorderLayout.NORTH);
				add(images,BorderLayout.CENTER);
		}
	
		public void actionPerformed(ActionEvent e){
		}
	
}
