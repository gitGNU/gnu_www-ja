// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;

/**
 * 
 * @author  Zoran Pecenovic
 * @version $Id: $
 */
public class BorderedPanel extends Panel {
    static final public int B_OUT = 0;
    static final public int B_IN = 1;
    static final public int B_ETCH_OUT = 2;
    static final public int B_ETCH_IN = 3;
    static final public int B_CUP = 4;
    static final public int B_OUT_LIGHT = 5;
    static final public int B_IN_LIGHT = 6;
    static final public int B_NONE =7;

    private int bType = B_NONE;
		protected String title;

    public BorderedPanel() {
				super();
    }
		
    public BorderedPanel(int Border) {
				bType=Border;
    }

    public BorderedPanel(int Border,String Title) {
				super();
				bType=Border;
				title=Title;
    }

    public Insets getInsets(){
				int tof = (title!=null)?10:0;
				return new Insets(4+tof,4,4,4);
    }
		
    public void setBorderType(int type){
				bType=type;
				repaint();
    }

		public void setCaption(String Title){
				title=Title;
				repaint();
		}

		public static Color brighten(Color in){
				float hsv[] = Color.RGBtoHSB(in.getRed(),
																		 in.getGreen(),
																		 in.getBlue(),
																		 null);
				hsv[2] = (1.0f/3.0f)+2*hsv[2]-hsv[2]*hsv[2];
				if(hsv[2]>1.0) hsv[2] = 1.0f;
				Color ret = Color.getHSBColor(hsv[0],hsv[1],hsv[2]);
				return ret;
				
		}
		
		public static Color darken(Color in){
				float hsv[] = Color.RGBtoHSB(in.getRed(),
																		 in.getGreen(),
																		 in.getBlue(),
																		 null);
				hsv[2] = (2.0f*hsv[2]*hsv[2])/3.0f;
				if(hsv[2]<0.0) hsv[2] = 0.0f;
				return Color.getHSBColor(hsv[0],hsv[1],hsv[2]);
		}
		
    public void paint(Graphics g){
				int th = g.getFontMetrics().getHeight();
				int w = getSize().width-1;
				int h = getSize().height-1;
				Color l = brighten(getBackground());
				Color d = darken(getBackground());
				int tof = (title==null)?0:4;
				switch(bType) {
				case B_OUT_LIGHT :
						g.setColor(getBackground());
						g.setColor(l);
						g.draw3DRect(0,tof,w-1,h-tof-1,true);
						break;
				case B_IN_LIGHT :
						g.setColor(getBackground());
						g.draw3DRect(0,tof,w-1,h-tof-1,false);
						break;
				case B_OUT:
						g.setColor(l);
						g.drawLine(0,tof,w,0);
						g.drawLine(1,1+tof,w-1,0);
						g.drawLine(0,tof,0,h-tof);
						g.drawLine(1,1+tof,0,h-tof-1);
						g.setColor(d);
						g.drawLine(w,h-tof,w,0);
						g.drawLine(w-1,h-tof-1,w-1,1);
						g.drawLine(w,h-tof,0,h-tof);
						g.drawLine(w-1,h-tof-1,1,h-tof-1);
						break;
				case B_IN:
						g.setColor(d);
						g.drawLine(0,tof,w,0);
						g.drawLine(1,1+tof,w-1,1);
						g.drawLine(0,tof,0,h-tof);
						g.drawLine(1,1+tof,1,h-tof-1);
						g.setColor(l);
						g.drawLine(w,h-tof,w,0);
						g.drawLine(w-1,h-tof-1,w-1,1);
						g.drawLine(w,h-tof,0,h-tof);
						g.drawLine(w-1,h-tof-1,1,h-tof-1);
						break;
				case B_CUP:
						g.setColor(l);
						g.drawLine(0,tof,0,h-tof);
						g.setColor(d);
						g.drawLine(0,h-tof,w,h-tof);
						g.drawLine(w,h-tof,w,0);
						break;
				case B_ETCH_OUT:
						g.setColor(d);
						g.drawRect(1,1+tof,w-1,h-tof-1);
						g.setColor(l);
						g.drawRect(0,tof,w-1,h-tof-1);
						break;
				case B_ETCH_IN:
						g.setColor(l);
						g.drawRect(1,1+tof,w-1,h-tof-1);
						g.setColor(d);
						g.drawRect(0,tof,w-1,h-tof-1);
						break;
				default: //else nothing should be drawn
						break;
				}
				if(title !=null) {
						int tw = g.getFontMetrics().stringWidth(title);
						g.setColor(getBackground());
						g.fillRect(4,0,tw+5,th);
						g.setColor(Color.black);
						g.drawString(title,7,th-5);
				}
				//super.paint(g.create(2,8,w-2,h-10));
    }
    /*
     * --- overwritten methods of class 'java.awt.Panel' ---
     */

}
