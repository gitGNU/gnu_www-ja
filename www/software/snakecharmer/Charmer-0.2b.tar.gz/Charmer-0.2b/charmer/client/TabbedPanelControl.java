// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;
import java.awt.event.*;
 

public class TabbedPanelControl 
		implements MouseListener
{


		//----------------------------------------Private attributes
		// controlled component
		private TabbedPanel tabbedPanel;
		
		// currently selected tab
		String selected = "";

		// last selected tab
		String lastSelected = "";

		public TabbedPanelControl(TabbedPanel component){
				tabbedPanel = component;
		}
				
		public void changeTabControl(String tabName) {
				// keep track of previously selected tab to unhighlight...
				lastSelected = selected;
				selected = tabName;				
		}

		public boolean isFull() {	
				return false; //using Vector now... (maxTabs <= countTabs);	
		}


		public void mouseClicked(MouseEvent e) {
				// display the invoked tab panel
				if(e.getComponent() instanceof TabLabel) {
						tabbedPanel.showTab(((TabLabel)e.getComponent()).getName());
				}
		}

		public void mouseEntered(MouseEvent e) {
				// change tab's caption appearance
				if(e.getComponent() instanceof TabLabel) {
						TabLabel tabLabel = ((TabLabel)e.getComponent());
						if(!tabLabel.isSelected()){
								Color c = tabbedPanel.getBackground();
								tabLabel.setBackground(c.brighter());
						}
				}		
		}

		public void mouseExited(MouseEvent e) {
				// reset tab's caption appearance
				if(e.getComponent() instanceof TabLabel) {
						TabLabel tabLabel = ((TabLabel)e.getComponent());
						tabLabel.setBackground(tabbedPanel.getBackground());
				}
		
		}

		public void mousePressed(MouseEvent e) {}
		public void mouseReleased(MouseEvent e) {}
}
