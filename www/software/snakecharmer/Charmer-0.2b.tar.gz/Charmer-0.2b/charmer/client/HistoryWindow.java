// -*- mode: java -*- 
/* 

   SnakeCharmer, and MRML complient JAVA interface for CBIRs
   Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Graphics;


public class HistoryWindow 
    extends Panel
    implements ActionListener,ItemListener
{
    TextArea text;
    java.awt.List events;
    public Hashtable dict;
    Button viewims,close;
    int addremove = 0;
    int searches = 0;
    int resets = 0;
    int others = 0;
    public int results = 0;
    Charmer parent;
    DisplayList images;
    ActiveVector currims;
    int memuse = 0;
    int minresults=0;
    final int MAX_MEM = 512*1024; //Max 1.5MB of history data...
    public HistoryWindow(Charmer parent){
	setLayout(new BorderLayout(5,5));
	currims = new ActiveVector(100,100);
	text = new TextArea(10,50);
	text.setEditable(false);
	events = new java.awt.List(20);
	events.addActionListener(this);
	events.addItemListener(this);
	dict = new Hashtable(100);
	BorderedPanel p = new BorderedPanel(BorderedPanel.B_ETCH_IN);
	p.setLayout(new FlowLayout(FlowLayout.LEFT));
	p.add(new Label("Double-click an event to show its description."));
	viewims = new Button(" View Query");
	viewims.addActionListener(this);
	p.add(viewims);
	close = new Button(" Close ");
	close.addActionListener(this);
	p.add(close);
	BorderedPanel p2 = new BorderedPanel(BorderedPanel.B_ETCH_IN);
	p2.setLayout(new BorderLayout(2,2));
	p2.add(events,BorderLayout.WEST);

	images = new DisplayList(parent.mf,parent.mf,currims,5,96,96);
	TabbedPanel tp = new TabbedPanel();
	Panel pz = new Panel(new BorderLayout());
	pz.add(text,BorderLayout.CENTER);
	tp.addTab("text","Text",pz);
	tp.addTab("images","Images",images);
	tp.showTab("text");
	p2.add(tp,BorderLayout.CENTER);
	p2.add(new Canvas(),BorderLayout.EAST);
	add(p,BorderLayout.NORTH);
	add(p2,BorderLayout.CENTER);
	this.parent=parent;
    }

    public void addEvent(int type,String description){
	String title;
	if(type == 0) {
	    title = "search"+searches;
	    searches++;
	} else if(type == 1) {
	    title = "add/remove"+addremove;
	    addremove++;
	} else if(type == 2) {
	    title = "reset"+resets;
	    resets++;
	} else if(type == 3) {
	    title = "results"+results;
	    parent.doFromString(description,title,parent.getResults());
	    results++;
	} else {
	    title = "other"+others;
	    others++;
	}
				//System.out.println("History takes up :"+memuse+" bytes");
	memuse += 2*title.length()+description.length();
	if(memuse > MAX_MEM) {
	    while(memuse>MAX_MEM/2) {
		String key = events.getItem(0);
		if(key!=null) {
		    try {
			events.remove(0);
		    }catch(Exception ex){}
		    String s = (String)dict.remove(key);
		    if(s!=null)
			memuse -= 2*key.length()+s.length();
		}
	    }
	    //System.out.println("PrunedHistory takes up :"+memuse+" bytes");
						
	}
	dict.put(title,description);
	events.addItem(title);
	events.select(events.getItemCount()-1);
	text.setText(description);
				//doLayout();
	repaint();
    }
    
    public void previous(){
	if(events.getItemCount()>0){
	    int id = events.getSelectedIndex();
	    if(id>0) id--;
	    while( ! events.getItem(id).startsWith("results") && id>0) id--;
	    events.select(id);
	    String key = events.getSelectedItem();
	    String description = (String)dict.get(key);
	    text.setText(description);	  
	    if(key.startsWith("results")) {
		parent.doFromString(description,key,parent.getResults());
	    }				
	}
    }
    
    public void following(){
	if(events.getItemCount()>0){
	    int id = events.getSelectedIndex();
	    if(id==events.getItemCount()-1) return;
	    do{ id++; } while( ! events.getItem(id).startsWith("results") && id<(events.getItemCount()-1));
	    if(id==(events.getItemCount()-1)) id--;
	    events.select(id);
	    String key = events.getSelectedItem();
	    String description = (String)dict.get(key);
	    text.setText(description);	  
	    if(key.startsWith("results")) {
		parent.doFromString(description,key,parent.getResults());
	    }				
	}
    }
    
    public void actionPerformed(ActionEvent e){
	String key = events.getSelectedItem();
	String description = (String)dict.get(key);
	if((e.getSource() == viewims  || e.getSource() == events) 
	   && key.startsWith("results")) {
	    text.setText(description);
	    parent.doFromString(description,key,currims);
	    images.recreateDisplay();
	}
    }
    
    public void itemStateChanged(ItemEvent e){
	String key = events.getSelectedItem();
	String description = (String)dict.get(key);
	text.setText(description);	  
	if(key.startsWith("results")) {
	    parent.doFromString(description,key,currims);
	    images.recreateDisplay();
	}
    }
}
