// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.Vector;


public class ActiveGraph
    extends BorderedPanel
    implements MouseMotionListener,MouseListener
{

	String rYlabel=null;

	// Constructors

    public ActiveGraph(){
		super(3);
		Construct(300,300,0);
    }

    public ActiveGraph(int w, int h, 
					   int axes_type //0=orbital , 1=grid					   
					   ){
		super(3);
		Construct(w,h,axes_type);
    }


		// Labeling 
    public void setTitle(String label){
				if(title != null)
						title.setText(label);
				else {
						title=new Label(label,Label.CENTER);
						add(title,BorderLayout.NORTH);
				}
    }
		
    public void setXLabel(String label){
				if(Xlabel != null) Xlabel.setText(label);
				else {
						Xlabel=new Label(label,Label.CENTER);
						add(Xlabel,BorderLayout.SOUTH);
						validate();
				}
    }
		
    public void setYLabel(String label, Component scomp){
				if(isShowing()){			
						Image yim = rotateText(label,this);
						int iw = yim.getWidth(this);
						int ih = yim.getHeight(this);
						if(Ylabel != null) remove(Ylabel);
						this.Ylabel = new DrawnButton(yim,iw,ih,0,null,null);
						add(this.Ylabel,BorderLayout.WEST);	    
						rYlabel=null;
						validate();
				} else {
						rYlabel = label;
				}
    }
		

	// Add new / remove  data 
    public void addPoints(int graph, //Which function
						  double x[],
						  double y[],
						  Object ref[] // Can be null
						  ){
		GP.addPoints(graph,x,y,ref);
    }

    public void addPoint(int graph, 
						 double x,
						 double y,
						 Object ref){
		GP.addPoint(graph,x,y,ref);
    }

	public void removeAllPoints(int graph){
		GP.removeAllPoints(graph);
	}

	//retrieve points
	public Vector getPoints(int graph){
		return GP.data[graph];
	}
	
	//refresh
	public void refresh(){
		GP.recreateDisplay(true);
		GP.repaint();
	}

	public void paint(Graphics g) {
		if(rYlabel != null) setYLabel(rYlabel,this);
		super.paint(g);
	}

	// Listener Manipulation
    public void addPointListener(PointListener l){
		if(l!=null) listener=l;
    }

    public void removePointListener(){
		listener=null;
    }


	// Event handlers

    public void mouseDragged(MouseEvent e) {}
    public void mousePressed(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}

    public void mouseClicked(MouseEvent ev) {
		Point w = ev.getPoint();
		GPoint gp = GP.selectPoint(w,true);
		if(gp!=null && listener != null) {
			listener.pointClicked(gp);
		}
    }

	private GPoint selected=null;
    public void mouseMoved(MouseEvent ev) {
				if(listener==null) return;
				Point w = ev.getPoint();
				GPoint gp = GP.selectPoint(w,false);
				if(gp==null){
						listener.pointSelected(null);
				}else if(gp!=selected){
						listener.pointSelected(gp);
				}
				selected=gp;
    }


	//-------------------------------- PRIVATE

	// hack stupid JAVA's inability to draw rotated text!!!
	private Image rotateText(String t,Component scomp){
		FontMetrics fm = scomp.getGraphics().getFontMetrics();
		int w = fm.getHeight()+5;
		int h = fm.stringWidth(t)+2;
		Image memimage = scomp.createImage(h,w);
		Graphics dg = memimage.getGraphics();
		dg.setColor(getBackground());
		dg.fillRect(0,0,h,w);
		dg.setColor(getForeground());
		dg.drawString(t,1,fm.getMaxAscent()+2);
		int pixels[] = new int[h*w];
		int rpixels[] = new int[w*h];
		PixelGrabber pg = new PixelGrabber(memimage,0,0,h,w,pixels,0,h);
		try{
			pg.grabPixels();
		} catch(InterruptedException ie) {}
		int k=0;
		for(int x=0; x<w; x++)
			for(int y=h-1; y>=0; y--,k++)
				rpixels[y*w+x] = pixels[k];
		Image retimage = 
			scomp.createImage(new MemoryImageSource(w, h, rpixels, 0, w));
		dg.dispose();
		memimage.flush();
		pixels=null;
		rpixels=null;
		return retimage;
    }

	public void setLineTo(boolean lt){
		GP.setLineTo(lt);
	}

    private void Construct(int w, int h, int at)
    {
		setFont(tf);
		GP = new GraphPanel(w,h,at);
		GP.addMouseMotionListener(this);
		GP.addMouseListener(this);
		setLayout(new BorderLayout());
		add(GP,BorderLayout.CENTER);
		add(new Panel(),BorderLayout.EAST); //just for layout reasons
		setTitle("ActiveGraph");
		setXLabel("X axis");
    }


	// Instance-data
    Label title;
    Label Xlabel;
    String YlabelString;
    DrawnButton Ylabel;
    public GraphPanel GP;
    Font tf = new Font("Helvetica",Font.PLAIN,11);
    PointListener listener=null;

}
