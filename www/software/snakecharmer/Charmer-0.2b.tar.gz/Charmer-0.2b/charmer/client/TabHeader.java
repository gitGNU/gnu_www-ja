// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

public class TabHeader extends java.awt.Panel {

		//-------------------------------------------------Constants
		// Empty tab caption.
		private final static String EMPTY_TAB = "~#empty";
	

		//----------------------------------------Private attributes
		// control for this component
		private TabbedPanelControl tabControl;
 	
		// tab control labels to invoke selected tab
		private Vector tabLabels;

		// tab header background color (default value)
		private Color headerBgColor = Color.lightGray;
		// active caption color
		private Color activeTabTextColor = Color.black;
		// inactive caption color (defualt value)
		private Color inactiveTabTextColor = Color.lightGray;
		// active tab background color (defualt value)
		private Color activeTabColor = Color.lightGray;
			// inactive tab background color (defualt value)
		private Color inactiveTabColor = Color.gray;

		// tab caption font (defualt value)
		private Font tabTextFont = new Font("Dialog",Font.BOLD,11);
	
		// the Layout info
		private GridBagLayout gbl = new GridBagLayout();
		private GridBagConstraints gbc = new GridBagConstraints();


		public TabHeader() {				
				initialize();
		}

		//Highlights the selected tab's caption
		public int changeSelection() {

				// gets tab number associated to tab name
				int oldTab = getTabNumber(tabControl.lastSelected);
				int newTab = getTabNumber(tabControl.selected);

				// deselect old tab (if found)
				if(oldTab!=-1) {
						((TabLabel)tabLabels.elementAt(oldTab)).setSelected(false);
				}
	
				// select new tab (if found)
				if(newTab!=-1) {
						((TabLabel)tabLabels.elementAt(newTab)).setSelected(true);
				}
				return newTab;
		}

		
		private int getTabNumber(String name) {

				// search tab by name
				for(int i=0;i<tabLabels.size();i++){
						TabLabel t = (TabLabel)tabLabels.elementAt(i);
						if(t.getName().compareTo(name)==0) return i;
				}
				return -1;	
		}

		public void addTabLabel(String name,String caption){
				TabLabel t = new TabLabel(caption);
				t.setName(name);
				t.setFont(tabTextFont);
				t.setAlignment(TabLabel.CENTER);
				t.setForeground(getForeground());
				t.addMouseListener(tabControl);		
				//gbl.setConstraints(t,gbc);
				add(t,gbc);
				tabLabels.addElement(t);
		}

		private void initialize() 
		{
				setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
				gbc.gridy=0;
				gbc.anchor = GridBagConstraints.WEST;
				// create the components for tab captions
				tabLabels = new Vector(10);
				//Spacing panel on the right of the tabs
				/*Panel p = new Panel();
					gbc.fill=GridBagConstraints.HORIZONTAL;
					gbc.gridwidth=GridBagConstraints.REMAINDER;
					gbc.weightx=1.0;
					gbl.setConstraints(p,gbc);
				add(p);*/
		}
		

		public void setCaption(String name, String newCaption) {
				// get tab number by name
				int tab = getTabNumber(name);

				// if tab not found try with the first empty one
				if(tab==-1)
						tab = getTabNumber(EMPTY_TAB);
				
				// if found then set caption
				if(tab!=-1) {
						// if name is currently EMPTY_TAB identify it by the
						// new specified caption
						if(((TabLabel)tabLabels.elementAt(tab)).getName().equals(EMPTY_TAB))
								((TabLabel)tabLabels.elementAt(tab)).setName(name);
						((TabLabel)tabLabels.elementAt(tab)).setText(newCaption);
				}
		}

		
		public void setControl(TabbedPanelControl eventListener) {
				tabControl = eventListener;				
				for(int i=0; i<tabLabels.size(); i++)
						((TabLabel)tabLabels.elementAt(i)).addMouseListener(eventListener);		
		}

		public void paint(Graphics g){
				//Small beauty hack
				g.setColor(BorderedPanel.brighten(getBackground()));
				g.drawLine(0,getSize().height-1,getSize().width-1,getSize().height-1);
		}
}
