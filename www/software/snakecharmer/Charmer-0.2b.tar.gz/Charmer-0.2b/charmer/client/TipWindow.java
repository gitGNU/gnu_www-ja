// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;
import java.util.StringTokenizer;
public class TipWindow
extends Window
{
    String stip = null;
    DrawnButton itip =null;
    Panel complex = null;
    private static final Color bcg = new Color(200,200,240);
    private static final Font tfont = new Font("Helvetica",Font.PLAIN,10);
    
    
    public TipWindow(Frame fr, Object tip){
	super(fr);
	setBackground(bcg);
	if(tip instanceof String) {
	    stip=(String)tip;
	    FontMetrics fm = getToolkit().getFontMetrics(tfont);
	    StringTokenizer st = new StringTokenizer(stip,"\n",false);
	    int l = st.countTokens();
	    int H = l*fm.getHeight()+4;		
	    int W = 0;
	    for(int i=0; i<l; i++) {
		W = Math.max(fm.stringWidth(st.nextToken()),W);
	    }
	    setSize(W+6,H);
	} else if(tip instanceof Image) {
	    setLayout(null);
	    Image im = (Image)tip;
	    itip=new DrawnButton((Image)tip,71,71,0,null,null);
	    add(itip);
	    setSize(75,75);
	    itip.setLocation(2,2);
	} else if(tip instanceof Panel) {
	    setLayout(new BorderLayout());
	    complex = (Panel)tip;
	    add(complex,BorderLayout.CENTER);
	    pack();
	}
	fr.requestFocus();
    }
    
    public void paint(Graphics g){
	if(complex != null) {
	    Dimension d = complex.getSize();
	    setSize(d.width+4,d.height+4);
	    setLayout(null);
	    complex.setLocation(2,2);
	    validate();
	}
	Dimension r = getSize();
	g.setColor(getBackground().brighter().brighter());
	g.drawLine(0,0,0,r.height-1);
	g.drawLine(0,0,r.width-1,0);
	g.setColor(getBackground().darker().darker());
	g.drawLine(r.width-1,r.height-1,0,r.height-1);
	g.drawLine(r.width-1,r.height-1,r.width-1,0);
	g.setColor(getForeground());
	if(stip != null) {
	    g.setFont(tfont);
	    StringTokenizer st = new StringTokenizer(stip,"\n",false);
	    int fh = g.getFontMetrics().getHeight();	    
	    int l = st.countTokens();
	    for(int i=0; i<l; i++) {
		g.drawString(st.nextToken(),2,(i+1)*fh-1);
	    }
	}
	paintComponents(g);
    }

}


