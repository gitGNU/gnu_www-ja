// -*- mode: java -*- 
/* 

    SnakeCharmer, and MRML complient JAVA interface for CBIRs
    Copyright (C) 1998-1999 Zoran Pecenovic & LCAV, EPF Lausanne

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
package charmer.client;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.net.URL;
import java.util.*;

public class TAG 
    extends BorderedPanel
    implements PointListener,ItemListener
{
    final int ASIZE = 500;
    DrawnButton db=null,dbq=null;
    Label tl,namel;
    Choice cy,cx;
    public ActiveGraph g=null;
    Charmer loader;
    TipListener mf;
    
    private BorderedPanel createControls(){
				BorderedPanel P = new BorderedPanel(BorderedPanel.B_ETCH_IN);
				GridBagLayout gbl = new GridBagLayout();
				GridBagConstraints gbc = new GridBagConstraints();
				gbc.fill = GridBagConstraints.HORIZONTAL;
				gbc.insets = new Insets(2,2,2,2);
				P.setLayout(gbl);
				cx = new Choice();
				cx.setBackground(getBackground());
				cx.add("Color");
				cx.add("Layout");
				cx.add("Texture");
				cx.add("Shapes");
				cx.addItemListener(this);
				cy = new Choice();
				cy.setBackground(getBackground());
				cy.add("Color");
				cy.add("Layout");
				cy.add("Texture");
				cy.add("Shapes");
				cy.addItemListener(this);
				cy.select(1);

				Label t = new Label("X:",Label.LEFT);
				gbc.gridwidth=1;
				gbc.weightx=0.0;
				gbl.setConstraints(t,gbc);
				P.add(t);
				gbc.gridwidth=GridBagConstraints.REMAINDER;
				gbc.weightx=1.0;
				gbl.setConstraints(cx,gbc);
				P.add(cx);
				gbc.gridwidth=1;
				gbc.weightx=0.0;

				t = new Label("Y:",Label.LEFT);
				gbl.setConstraints(t,gbc);
				P.add(t);
				gbc.gridwidth=GridBagConstraints.REMAINDER;
				gbc.weightx=1.0;
				gbl.setConstraints(cy,gbc);
				P.add(cy);
				gbc.gridwidth=1;
				gbc.weightx=0.0;
				return P;
    }


    public TAG(Charmer loader, TipListener mframe){
				super(BorderedPanel.B_NONE);
				mf=mframe;
				this.loader=loader;
				setLayout(new BorderLayout(5,5));
				g = new ActiveGraph(300,300,0);
				g.setLineTo(false);
				g.addPointListener(this);
				add(g,BorderLayout.CENTER);
				db = new DrawnButton(null,194,194,1,null,null);
				db.setBorderType(BorderedPanel.B_ETCH_IN);
				db.setFont(new Font("Dialog",Font.PLAIN,10));
				dbq = new DrawnButton(null,194,194,1,null,null);
				dbq.setBorderType(BorderedPanel.B_ETCH_IN);
				dbq.setFont(new Font("Dialog",Font.PLAIN,10));
				dbq.setLabel("query image");
				Panel P = new Panel(new BorderLayout(3,3));
				P.add(createControls(),BorderLayout.NORTH);
				P.add(db,BorderLayout.CENTER);
				P.add(dbq,BorderLayout.SOUTH);

				add(P,BorderLayout.EAST);
				g.setTitle("Distribution of results relative to query.");
				g.setXLabel("Color");
				g.setYLabel("Layout",loader);
    }
	
    public void pointClicked(GPoint gp){}
    public void pointSelected(GPoint gp){
				if(loader.getQuery().size()==1)
						dbq.changeLabel(((QueryObject)loader.getQuery().elementAt(0)).image);
				else {
						dbq.setBackground(Color.darkGray);
				}
				if(gp==null){
						mf.displayTip(g.GP,null,new Point(0,0));
						db.changeLabel(null);
				} else {
						QueryObject qo = (QueryObject)gp.data;
						if(qo.image == null && qo.location!= null) {
						    System.out.println("GettingImage");
						    System.out.println(qo.location);
						    qo.image = loader.getImage(qo.location);
						}else{
						    System.out.println("NOT GETTING IMAGE:");
						    System.out.println(qo.location);
						}
						mf.displayTip(g.GP,qo.image,new Point(gp.xp,gp.yp));
						db.changeLabel(qo.image);
						db.setLabel(qo.fname);
				}
    }
		
    public void setVisible(boolean show){
				super.setVisible(show);
				GPoint qp =(GPoint)g.getPoints(0).firstElement();
				dbq.changeLabel( ((QueryObject)qp.data).image );
    }

    public void itemStateChanged(ItemEvent ie){
				if(g.getPoints(0).size()<1) return;
				if(ie.getSource()==cx) {
						g.setXLabel(cx.getSelectedItem());
						Enumeration e = g.getPoints(0).elements();
						while(e.hasMoreElements()) {
								GPoint gp = (GPoint)e.nextElement();
								if(cx.getSelectedIndex()==0)
										gp.x = (((QueryObject)gp.data).cdist+1);
								else if(cx.getSelectedIndex()==1)
										gp.x = (((QueryObject)gp.data).ldist+1);
								else if(cx.getSelectedIndex()==2)
										gp.x = (((QueryObject)gp.data).tdist+1);
						}
						g.refresh();
				} else if(ie.getSource()==cy) {
						g.setYLabel(cy.getSelectedItem(),loader);			
						Enumeration e = g.getPoints(0).elements();
						while(e.hasMoreElements()) {
								GPoint gp = (GPoint)e.nextElement();
								if(cy.getSelectedIndex()==0)
										gp.y = (((QueryObject)gp.data).cdist+1);
								else if(cy.getSelectedIndex()==1)
										gp.y = (((QueryObject)gp.data).ldist+1);
								else if(cy.getSelectedIndex()==2)
										gp.y = (((QueryObject)gp.data).tdist+1);
						}
						g.refresh();
				}		
    }
}
