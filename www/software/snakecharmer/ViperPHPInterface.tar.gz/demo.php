<html>
<!--
// PHP MRML Client to the GIFT system written by Nicolas Chabloz
// Copyright (C) 2002 CUI, University of Geneva
// 
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
// 
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
//  02111-1307  USA
-->
<head>
<title>Viper PHP demo interface</title>
</head>
<body bgcolor="#FFFFFF" background="http://viper.unige.ch/lib/images/viper_bg.gif">
<center>
<table width="50%" border="0"><tr><td><img src="http://viper.unige.ch/lib/images/viper_logo.gif" width="96" height="61"></td>
<td><div align="center"><font size="+3">Online Demo</font></div></td>
<td><div align="right"><img src="http://viper.unige.ch/lib/images/viper_logo.gif" width="96" height="61"></div></td></tr>
<tr><td></td><td align="center">Read this <a href="http://viper.unige.ch/disclaimer/" target="new">disclaimer</a> first</td><td></td></tr>
</table>
<hr>

<?
//url of this  php
$phpurl="http://viper.unige.ch/demo/php/demo.php";
//add the client
include("Client.php");
?>


<hr>
<address>
Interface developped by Nicolas Chabloz (send comments to <a href="mailto:marchand.AT.cui.unige.ch">the Viper team</a>) &copy; 2001 - <a href="http://viper.unige.ch">Viper</a>
 - <a href="http://viper.unige.ch/disclaimer/">Disclaimer</a> - <a href="http://viper.unige.ch/demo/php/ViperPHPInterface.tar.gz">Download this interface</a></address>
</body>
</html>

