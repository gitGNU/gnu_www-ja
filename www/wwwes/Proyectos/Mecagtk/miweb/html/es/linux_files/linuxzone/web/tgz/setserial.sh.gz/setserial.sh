#!/bin/bash

clear

echo "******************************************************************"
echo "*                      setserial.sh v0.1                         *"
echo "*           Configuracion de la linea serial (modem)             *"
echo "*                                                                *"
echo "* Este script da informacion sobre los dispositivos serie del    *"
echo "* sistema y permite cambiar algunos parametros de forma sencilla *"
echo "*                                                                *"
echo "* Debe ser ejecutado como root                                   *"
echo "* Se basa en el uso del comando setserial.                       *"
echo "*                                                                *"
echo "* Para mas informacionteneis el man setserial y el Serial-HOWTO  *"
echo "*                                                                *"
echo "* Por Daniel Molina                                              *"
echo "* Web: http://www.geocities.com/soho/lofts/3682/hack             *"
echo "* Mail: dmolinap@geocities.com                                   *"
echo "******************************************************************"

#sleep 5

clear

A=
B=
C=
D=
E=
I=
P=
V=

echo
echo El nombre del dispositivo ke controla una linea serial depende del
echo puerto ke utiliza. 
echo
echo Los nombres de dispositivos mas comunes son:
echo 
echo "Dispositivo -> Puerto -> Configuracion base"
echo "/dev/ttyS0      COM1     port 0x03f8, irq 4"
echo "/dev/ttyS1      COM2     port 0x02f8, irq 3"
echo "/dev/ttyS2      COM3     port 0x03e8, irq 4"
echo "/dev/ttyS3      COM4     port 0x02e8, irq 3"
echo
echo -n "Ke dispositivo kieres configurar? (Ejemplo: /dev/ttyS1): "
read A

clear

#if [ $A="" ]; then {
#	export A=/dev/ttyS0
#}
#fi

echo Dispositivo seleccionado $A
echo 

if [ -r $A ]; then {
	echo Las lineas seriales son usadas por modems y ratones
	echo Aunke tambien pueden no ser usadas por ningun dispositivo
	echo
	echo -n "El dispositivo $A es un (m)odem, un (r)aton o (n)ada? (m/r/n): " 
	read B
	clear
	if [ $B = "m" ]; then {
		echo Dispositivo seleccionado: Modem en $A
		if [ -L /dev/modem ]; then
			echo
		else {
			echo
			echo "Link /dev/modem no encontrado"
			echo Los programas suelen usar este link para 
			echo acceder al modem y es algo muy recomendable
			echo
			echo -n "Crear el link /dev/modem -> $A ahora? (s/n): "
			read C
			if [ $C = "s" ]; then 
				echo "Creando link /dev/modem -> $A" ; ln -sf $A /dev/modem
			else
				echo Has elegido no crear el link
			fi
		}
		fi
	}
	elif [ $B = "r" ]; then { 
		echo Dispositivo seleccionado: Raton en $A
                if [ -L /dev/mouse ]; then
                        echo
                else {
                        echo
                        echo "Link /dev/mouse no encontrado"
                        echo Los programas suelen usar este link para
                        echo acceder al raton y es algo muy recomendable
                        echo
                        echo -n "Crear el link /dev/mouse -> $A ahora? (s/n): "
                        read C
                        if [ $C = "s" ]; then 
                                echo "Creando link /dev/mouse -> $A" ; ln -sf $A /dev/mouse
                        else
                                echo Has elegido no crear el link
			fi
                }
                fi
	
	}
        elif [ $B = "n" ]; then {
                echo Dispositivo seleccionado: Linea no usada en $A
	
	}
	else
		echo "Debes seleccionar m (modem), r (raton) o n (nada)"
 	fi
	
	echo Informacion detallada del dispositivo:
	setserial $A -a
	echo
	echo -n "Quieres cambiar algun parametro? (s/n): "
	read D
 
	if [ $D = "s" ]; then

echo
echo "La configuracion basica de cada puerto serie es:"
echo
echo "Dispositivo -> Puerto -> Configuracion base"
echo "/dev/ttyS0      COM1     port 0x03f8, irq 4"
echo "/dev/ttyS1      COM2     port 0x02f8, irq 3"
echo "/dev/ttyS2      COM3     port 0x03e8, irq 4"
echo "/dev/ttyS3      COM4     port 0x02e8, irq 3"

		echo
		echo -n "Valor para IRQ (Ejemplo 3): "
		read I
		#if [ $I = ]; then {
	        #I=5
		#}
		#fi
		echo -n "Valor para Port (Ejemplo 0x02f8): "
		read P
		#if [ $P = ]; then {
	        #P=
		#}
		#fi
		echo -n "Valor para Velocidad (Ejemplo 115200): "
		read V
		#if [ $V = ]; then {
	        #V=115200
		#}
		#fi
		echo
		echo "Valores seleccionados: $A -> IRQ $I Puerto $P Velocidad $V"
		echo
			echo -n "Correcto? (s/n): "
			read E
			if [ $E = "s" ]; then
				setserial $A irq $I port $P baud_base $V
				echo
				echo Nueva configuracion:
				setserial $A
echo
echo "NOTA: Si kieres ke estos cambios sean permanentes a�ade la linea"
echo "setserial $A irq $I port $P baud_base $V" 
echo "a algun archivo de arranke (por ejemplo /etc/rc.d/rc.local en Red Hat)"
echo
			fi
	fi

}
else
	echo El dispositivo indicado no existe 
fi

