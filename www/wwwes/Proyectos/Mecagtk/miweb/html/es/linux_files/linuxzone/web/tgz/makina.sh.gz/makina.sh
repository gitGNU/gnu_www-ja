#!/bin/bash

clear #Para empezar limpiamos la pantalla un pokito ...

#Ahora mostramos los creditos y tal ...

echo "**********************************************************"
echo "*   Este script muestra informacion basica del sistema   *"
echo "*                                                        *"
echo "* Por Daniel Molina                                      *"
echo "* Puedes copiarlo siempre ke se cite el nombre del autor *"
echo "* e-mail: dmolinap@geocities.com                         *"
echo "* Web http://www.geocities.com/soho/lofts/3682           *"
echo "**********************************************************"

sleep 3s #Retardo pa asegurarme ke los lees ... ;)

#Y vamos al lio ...

echo ""
echo -n "Procesador: .......... "
uname -m
echo -n "Sistema operativo: ... "
uname -s
echo -n "Version del kernel: .. "
uname -r
echo -n "Host: ................ "
uname -n
echo 