#!/bin/bash
clear #Para empezar limpiamos la pantalla un pokito ...

#Ahora mostramos los creditos y tal ...

echo "**********************************************************"
echo "*       Este script facilita el control de usuarios      *"
echo "*                                                        *"
echo "* Necesitas tener los comandos w, netstat y grep         *"
echo "*                                                        *"
echo "* Por Daniel Molina                                      *"
echo "* Puedes copiarlo siempre ke se cite el nombre del autor *"
echo "* e-mail: dmolinap@geocities.com                         *"
echo "* Web http://www.geocities.com/soho/lofts/3682           *"
echo "**********************************************************"

sleep 5 #Retardo pa asegurarme ke los lees ... ;)

#Y vamos al lio ...

while test !1 	#Hacemos ke se ejecute hasta la saciedad
do
	clear

	echo Usuarios conectados ...
	w -h	#Ke usuarios tengo enchufados?
	echo

	echo Usuarios conectados por telnet ...
	who | grep ttyp #Ke usuarios usan las ttypX?
	echo

	echo Conexiones por TCP/IP ...
	netstat | grep tcp	#Conexiones tcp
	echo

	echo Ultimos mensajes del sistema ...
	tail -n2 /var/log/messages
	echo

	echo -n "Hora local: "
	date 	#Ke hora es?
	echo
	
	sleep 30	#Se actualiza cada X segundos
done
